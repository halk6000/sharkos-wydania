#!/usr/bin/python3
"""SharkOS — konta i ekran wyboru konta (jak w Windows), usługa systemowa (root) na 127.0.0.1:7381.

Role: root = grupa sudo (pełna kontrola; zmiany systemu po odblokowaniu kodem / sudo), admin = grupa
sharkos-admin (wszystko oprócz edycji systemu), user = konto z ograniczeniami (także w terminalu).

  GET  /v1/konta                  → konta ludzi (UID 1000–59999): login, nazwa, rola, aktualne
  POST /v1/zaloguj {konto,haslo}  → hasło z /etc/shadow; dobre → sesja kiosku przełącza się na to konto
  POST /v1/wyloguj                → powrót do ekranu wyboru konta
  POST /v1/nowe-konto {konto,nazwa,haslo,rola,zatwierdza,zatwierdza_haslo}
                                  → zakłada konto; zatwierdza konto z prawem do tej roli (root: root; admin/user: root lub admin)
Ekran wyboru konta: sesja kiosku jako systemowy „sharkos-greeter” (nakładka w trybie #tryb=logowanie).
Tryb (SHARKOS_WYBOR_KONTA w /etc/sharkos/kiosk.conf): auto (ekran, gdy są ≥2 konta) | zawsze | nigdy.
Hasła nie są nigdzie zapisywane ani logowane. Po 5 złych hasłach na konto — 2 min przerwy.
"""
from __future__ import annotations

import argparse
import grp
import json
import os
import pwd
import re
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

GREETER = "sharkos-greeter"
GRUPA_ADMIN = "sharkos-admin"
DROPIN = Path(os.environ.get("SHARKOS_KONTA_DROPIN", "/etc/systemd/system/sharkos-kiosk.service.d/10-user.conf"))
KONF = Path(os.environ.get("SHARKOS_KONTA_KONF", "/etc/sharkos/kiosk.conf"))
SHADOW = Path(os.environ.get("SHARKOS_KONTA_SHADOW", "/etc/shadow"))
LOGIN_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")
GRUPY_UZYTKOWNIKA = ["audio", "video", "plugdev", "netdev", "cdrom"]
MAX_BODY = 4096


class Blad(Exception):
    def __init__(self, status: int, msg: str):
        super().__init__(msg)
        self.status, self.msg = status, msg


def czlonkowie(grupa: str) -> set[str]:
    try:
        g = grp.getgrnam(grupa)
    except KeyError:
        return set()
    return set(g.gr_mem) | {p.pw_name for p in pwd.getpwall() if p.pw_gid == g.gr_gid}


def rola(konto: str) -> str:
    if konto in czlonkowie("sudo"):
        return "root"
    if konto in czlonkowie(GRUPA_ADMIN):
        return "admin"
    return "user"


def konta() -> list[dict]:
    out = []
    for p in pwd.getpwall():
        if 1000 <= p.pw_uid < 60000 and not p.pw_shell.endswith(("nologin", "false")) and p.pw_name != GREETER:
            out.append({"konto": p.pw_name, "nazwa": (p.pw_gecos.split(",")[0] or p.pw_name), "rola": rola(p.pw_name)})
    return sorted(out, key=lambda k: k["konto"])


def hash_konta(konto: str) -> str:
    for linia in SHADOW.read_text().splitlines():
        pola = linia.split(":")
        if pola and pola[0] == konto and len(pola) > 1:
            return pola[1]
    return ""


def haslo_ok(konto: str, haslo: str, crypt=None) -> bool:
    """Hasło z /etc/shadow sprawdzone crypt() systemu (perl — Python 3.13 nie ma modułu crypt)."""
    if not LOGIN_RE.match(konto or "") or not isinstance(haslo, str) or len(haslo) > 512:
        return False
    h = hash_konta(konto)
    if not h or h[0] in "!*":
        return False
    if crypt is None:
        r = subprocess.run(["perl", "-e", "my $p=<STDIN>; chomp $p; print crypt($p, $ARGV[0]) // ''", h],
                           input=haslo + "\n", capture_output=True, text=True, timeout=10)
        wynik = r.stdout
    else:
        wynik = crypt(haslo, h)
    import hmac
    return bool(wynik) and hmac.compare_digest(wynik, h)


def aktualne() -> str:
    try:
        m = re.search(r"^User=(\S+)", DROPIN.read_text(), re.M)
        return m.group(1) if m else ""
    except OSError:
        return ""


def ustaw_kiosk(konto: str) -> None:
    DROPIN.parent.mkdir(parents=True, exist_ok=True)
    DROPIN.write_text(f"[Service]\nUser={konto}\n")


def tryb_wyboru() -> str:
    try:
        m = re.search(r"^SHARKOS_WYBOR_KONTA=(\w+)", KONF.read_text(), re.M)
        return m.group(1) if m and m.group(1) in ("auto", "zawsze", "nigdy") else "auto"
    except OSError:
        return "auto"


class Konta:
    def __init__(self, run=subprocess.run, crypt=None, clock=time.time, restart=None):
        self.run = run
        self.crypt = crypt
        self.clock = clock
        self.bledy: dict[str, list[float]] = {}
        self.restart = restart or self._restart_kiosku
        self.lock = threading.Lock()

    def _restart_kiosku(self) -> None:
        def pozniej():
            time.sleep(1.0)                    # odpowiedź HTTP zdąży wrócić do nakładki
            subprocess.run(["systemctl", "daemon-reload"], capture_output=True)
            subprocess.run(["systemctl", "restart", "sharkos-kiosk.service"], capture_output=True)
        threading.Thread(target=pozniej, daemon=True).start()

    def _sprawdz(self, konto: str, haslo: str) -> None:
        teraz = self.clock()
        with self.lock:
            b = [t for t in self.bledy.get(konto, []) if teraz - t < 120]
            self.bledy[konto] = b
            if len(b) >= 5:
                raise Blad(429, "Za dużo prób — odczekaj 2 minuty")
        if not haslo_ok(konto, haslo, self.crypt):
            with self.lock:
                self.bledy.setdefault(konto, []).append(teraz)
            raise Blad(403, "Złe konto albo hasło")

    def lista(self) -> dict:
        return {"konta": konta(), "aktualne": aktualne(), "tryb": tryb_wyboru()}

    def zaloguj(self, b: dict) -> dict:
        konto = str(b.get("konto", ""))
        if konto not in {k["konto"] for k in konta()}:
            raise Blad(404, "Nie ma takiego konta")
        self._sprawdz(konto, str(b.get("haslo", "")))
        ustaw_kiosk(konto)
        self.restart()
        return {"ok": True, "konto": konto, "rola": rola(konto)}

    def wyloguj(self, b: dict) -> dict:
        ustaw_kiosk(GREETER)
        self.restart()
        return {"ok": True}

    def nowe(self, b: dict) -> dict:
        konto, nazwa = str(b.get("konto", "")).strip(), str(b.get("nazwa", "")).strip()[:60]
        haslo, r = str(b.get("haslo", "")), str(b.get("rola", "user"))
        if not LOGIN_RE.match(konto) or konto in (GREETER, "root"):
            raise Blad(400, "Login: małe litery, cyfry, _ i -, zaczyna się od litery (do 32 znaków)")
        if r not in ("user", "admin", "root"):
            raise Blad(400, "rola: user, admin albo root")
        if len(haslo) < 6:
            raise Blad(400, "Hasło: co najmniej 6 znaków")
        try:
            pwd.getpwnam(konto)
            raise Blad(409, "Takie konto już jest")
        except KeyError:
            pass
        zatw = str(b.get("zatwierdza", ""))
        if r == "root" and rola(zatw) != "root":
            raise Blad(403, "Konto root może założyć tylko root")
        if rola(zatw) not in ("root", "admin"):
            raise Blad(403, "Nowe konto zatwierdza administrator albo root")
        self._sprawdz(zatw, str(b.get("zatwierdza_haslo", "")))
        grupy = list(GRUPY_UZYTKOWNIKA) + ([GRUPA_ADMIN] if r == "admin" else []) + (["sudo"] if r == "root" else [])
        istniejace = [g for g in grupy if self._grupa_jest(g)]
        komendy = [["useradd", "-m", "-s", "/bin/bash", "-c", nazwa or konto, "-G", ",".join(istniejace), konto]]
        for k in komendy:
            p = self.run(k, capture_output=True, text=True, timeout=30)
            if p.returncode != 0:
                raise Blad(500, f"useradd: {(p.stderr or '').strip()[:200]}")
        p = self.run(["chpasswd"], input=f"{konto}:{haslo}\n", capture_output=True, text=True, timeout=30)
        if p.returncode != 0:
            raise Blad(500, "Nie ustawiłem hasła")
        return {"ok": True, "konto": konto, "rola": r}

    def ustaw_tryb(self, b: dict) -> dict:
        tryb = str(b.get("tryb", ""))
        if tryb not in ("auto", "zawsze", "nigdy"):
            raise Blad(400, "tryb: auto, zawsze albo nigdy")
        zatw = str(b.get("zatwierdza", ""))
        if rola(zatw) not in ("root", "admin"):
            raise Blad(403, "Zmienia to administrator albo root")
        self._sprawdz(zatw, str(b.get("zatwierdza_haslo", "")))
        try:
            tekst = KONF.read_text()
        except OSError:
            tekst = ""
        linia = f"SHARKOS_WYBOR_KONTA={tryb}"
        tekst = re.sub(r"^SHARKOS_WYBOR_KONTA=.*$", linia, tekst, flags=re.M) if re.search(
            r"^SHARKOS_WYBOR_KONTA=", tekst, re.M) else tekst.rstrip("\n") + ("\n" if tekst else "") + \
            "# ekran wyboru konta: auto (gdy ≥2 konta) | zawsze | nigdy\n" + linia + "\n"
        KONF.parent.mkdir(parents=True, exist_ok=True)
        KONF.write_text(tekst)
        return {"ok": True, "tryb": tryb}

    @staticmethod
    def _grupa_jest(g: str) -> bool:
        try:
            grp.getgrnam(g)
            return True
        except KeyError:
            return False


def make_handler(k: Konta):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):
            pass

        def _send(self, status: int, d: dict):
            body = json.dumps(d, ensure_ascii=False).encode()
            self.send_response(status)
            o = self.headers.get("Origin")
            if o in ("null", "file://"):
                self.send_header("Access-Control-Allow-Origin", o)
                self.send_header("Vary", "Origin")
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _guard(self) -> bool:
            port = self.server.server_address[1]
            if (self.headers.get("Host") or "") not in (f"127.0.0.1:{port}", f"localhost:{port}"):
                self._send(403, {"error": "Niedozwolony Host"})
                return False
            if self.headers.get("Origin") not in (None, "null", "file://"):
                self._send(403, {"error": "Niedozwolone pochodzenie"})
                return False
            return True

        def do_OPTIONS(self):
            if not self._guard():
                return
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin") or "null")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Content-Length", "0")
            self.end_headers()

        def do_GET(self):
            if not self._guard():
                return
            if self.path.rstrip("/") == "/v1/konta":
                return self._send(200, k.lista())
            self._send(404, {"error": "Nie ma takiego adresu"})

        def do_POST(self):
            if not self._guard():
                return
            akcje = {"/v1/zaloguj": k.zaloguj, "/v1/wyloguj": k.wyloguj, "/v1/nowe-konto": k.nowe,
                     "/v1/tryb": k.ustaw_tryb}
            fn = akcje.get(self.path.rstrip("/"))
            if not fn:
                return self._send(404, {"error": "Nie ma takiego adresu"})
            try:
                n = int(self.headers.get("Content-Length") or 0)
                if n > MAX_BODY:
                    raise Blad(413, "Za duże zapytanie")
                b = json.loads(self.rfile.read(n) or b"{}")
                if not isinstance(b, dict):
                    raise Blad(400, "Treść musi być obiektem JSON")
                self._send(200, fn(b))
            except Blad as e:
                self._send(e.status, {"error": e.msg})
            except ValueError:
                self._send(400, {"error": "Zły JSON"})
            except Exception as e:  # jeden błąd nie wywraca usługi
                self._send(500, {"error": f"Błąd wewnętrzny: {type(e).__name__}"})
    return H


def wybierz_przy_starcie() -> str:
    """Konto sesji kiosku przy starcie: ekran wyboru (greeter) albo od razu konto."""
    ludzie = konta()
    tryb = tryb_wyboru()
    obecne = aktualne()
    if tryb == "zawsze" or (tryb == "auto" and len(ludzie) >= 2):
        try:
            pwd.getpwnam(GREETER)
            return GREETER
        except KeyError:
            pass
    if (obecne == GREETER or not obecne) and ludzie:
        return ludzie[0]["konto"]
    return obecne


def przed_startem(reload=lambda: subprocess.run(["systemctl", "daemon-reload"], capture_output=True)) -> str:
    """sharkos-konta-start.service (przed kioskiem). Gdy konto się zmienia — zapis i przeładowanie systemd."""
    nowe = wybierz_przy_starcie()
    if nowe and nowe != aktualne():
        ustaw_kiosk(nowe)
        reload()
    return nowe


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="SharkOS — konta i ekran wyboru konta")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("serve")
    s.add_argument("--port", type=int, default=7381)
    sub.add_parser("przed-startem")
    sub.add_parser("lista")
    a = ap.parse_args(argv)
    if a.cmd == "przed-startem":
        print(przed_startem())
        return 0
    if a.cmd == "lista":
        print(json.dumps(Konta().lista(), ensure_ascii=False, indent=1))
        return 0
    httpd = ThreadingHTTPServer(("127.0.0.1", a.port), make_handler(Konta()))
    httpd.daemon_threads = True
    httpd.serve_forever()
    return 0


if __name__ == "__main__":
    sys.exit(main())
