# shark-sysd — prawdziwe dane systemu dla nakładki SharkOS

Mała usługa HTTP (Python 3, tylko biblioteka standardowa), która czyta `/proc` i systemd i podaje dane Menedżerowi zadań w `shell/index.html`. Nasłuchuje **wyłącznie** na `127.0.0.1:7378` (inny adres niż pętla zwrotna jest odrzucany przy starcie).

## Adresy

| Metoda | Adres | Co zwraca |
|---|---|---|
| GET | `/v1/health` | `{"ok": true, "service": "shark-sysd", "version": "…"}` |
| GET | `/v1/sys` | CPU (% całości, na rdzeń, model, rdzenie/wątki, load), pamięć i swap, dysk (zajętość `/` i `/home`, obciążenie %, odczyt/zapis B/s), sieć (odbiór/wysyłka B/s, bez `lo`), uptime |
| GET | `/v1/processes?limit=60&sort=cpu&mine=0&kernel=1` | procesy: PID, nazwa, polecenie, stan, CPU % (całej maszyny), pamięć RSS, właściciel, nice, `start_time`, `own`, `kernel` |
| GET | `/v1/services?scope=system\|user` | jednostki systemd (usługi i timery): nazwa, opis, stan; `available:false`, gdy systemd nie działa |
| POST | `/v1/processes/<pid>/signal` | `{"signal":"TERM\|KILL\|STOP\|CONT","start_time":N}` |
| POST | `/v1/processes/<pid>/renice` | `{"nice":0..19,"start_time":N}` |

Wartości chwilowe (CPU %, B/s) to różnica między dwoma odczytami: pierwsze zapytanie czeka ~0,25 s, kolejne liczą względem poprzedniego (wynik jest pamiętany 0,4 s, więc częste odpytywanie nie obciąża systemu).

## Bezpieczeństwo akcji
- **Token sesji**: przy starcie usługa losuje token i zapisuje go w `$XDG_RUNTIME_DIR/shark-sysd/token` (katalog 0700, plik 0600; usuwany przy zatrzymaniu). Każdy POST wymaga nagłówka `X-Shark-Token`. Odczyty (GET) tokenu nie wymagają.
- **Tylko własne procesy**: usługa działa jako jednostka *użytkownika* systemd (bez roota) i dodatkowo sprawdza, czy rzeczywisty UID procesu = UID usługi. PID 1 i sama usługa są nietykalne.
- **`start_time`**: jeśli podany, musi się zgadzać z `/proc/<pid>/stat` — chroni przed zabiciem innego programu, który dostał zwolniony numer PID (odpowiedź 409).
- **renice**: bez uprawnień można tylko obniżyć priorytet (podnieść nice). Próba podniesienia priorytetu kończy się 403 z wyjaśnieniem.
- **Ochrona przeglądarki**: nagłówek `Host` musi wskazywać `127.0.0.1`/`localhost` (ochrona przed DNS rebinding); `Origin` musi być `null` lub `file://` (nakładka otwarta z pliku) albo dodany przez `--allow-origin`. Inne strony WWW dostają 403.
- Sygnały ograniczone do TERM, KILL, STOP, CONT; treść zapytania do 4 KB.

## Jak nakładka dostaje token
Program uruchamiający sesję kiosku pyta usługę o adres z tokenem w części `#` (nie trafia on do żadnego serwera ani historii zapytań HTTP):
```sh
URL=$(python3 /usr/lib/sharkos/shark-sysd/shark_sysd.py shell-url)
cage -- chromium --kiosk --app="$URL"
```
Nakładka zapamiętuje token w `sessionStorage` i usuwa go z paska adresu. Bez tokenu dane są widoczne, a akcje kończą się komunikatem.

## Nakładka (`shell/index.html`)
- Co 1 s pyta `/v1/sys`, a gdy Menedżer zadań jest otwarty — co ~2 s `/v1/processes` (60 najaktywniejszych, bez wątków jądra).
- Znaczek w oknie zmienia się z „dane przykładowe” na zielony „dane na żywo”.
- Po 3 nieudanych zapytaniach wraca do danych przykładowych; wtedy sprawdza usługę co 10 s.
- „Zakończ zadanie” → TERM, „Wstrzymaj / wznów” → STOP/CONT, „Niższy priorytet” → nice +5. Cudze procesy: tylko podgląd.
- Zakładka Usługi pokazuje prawdziwą listę systemd; gdy systemd jest niedostępny — komunikat i dane przykładowe. „Restartuj usługę” w trybie na żywo jeszcze nie działa (wymaga uprawnień administratora — do zaprojektowania, np. polkit).
- Okna samej nakładki („Aplikacje”) to jedna przeglądarka, więc w trybie na żywo mają „—” zamiast liczb.

## Instalacja
Najprościej pakietem `sharkos` (`packaging/README.md`) — instaluje i włącza jednostkę dla wszystkich kont. Ręcznie:
```sh
sudo install -Dm644 shark_sysd.py /usr/lib/sharkos/shark-sysd/shark_sysd.py
sudo install -Dm644 systemd/shark-sysd.service /usr/lib/systemd/user/shark-sysd.service
systemctl --user daemon-reload && systemctl --user enable --now shark-sysd
curl -s http://127.0.0.1:7378/v1/health
```

## Testy
```sh
python3 -m pytest services/shark-sysd
```

## Co sprawdzono (7.11.2026, kontener w chmurze, Python 3.13)
- **15 testów pytest**: parsowanie sztucznego `/proc` (nazwy procesów z nawiasami i spacjami, pomijanie partycji/`loop`/`lo`), liczenie różnic CPU/dysku/sieci, ponownie użyty PID, parsowanie `systemctl` (atrapa), brak systemd, reguły akcji, token 0600, odmowa nasłuchu poza pętlą zwrotną, serwer HTTP na 127.0.0.1 (CORS, `Host`, 401/403/409), prawdziwy proces potomny: renice do 7 i zakończenie TERM, start procesu usługi, `shell-url` i sprzątanie tokenu po SIGTERM.
- Odczyty na prawdziwym `/proc` kontenera (CPU, pamięć, dyski `vd*`, procesy).
- Nakładka w Chromium bez okna (Playwright): bez usługi — dane przykładowe, brak błędów skryptu; z usługą — „dane na żywo”, prawdziwe kafelki i procesy, „Niższy priorytet” (nice 0 → 5) i „Zakończ zadanie” na procesie testowym (proces zakończony), powrót do danych przykładowych po zatrzymaniu usługi; widok 400×800 bez przewijania w poziomie.
- `systemd-analyze verify` jednostki (w trybie systemowym, bo w kontenerze nie ma menedżera użytkownika).

## Nieprzetestowane
- Działanie jako `systemctl --user` w prawdziwym Debianie 13 i lista usług z działającego systemd (kontener nie ma systemd jako PID 1 — tu `/v1/services` zwraca `available:false`).
- Uruchomienie w VM, sesja kiosku cage + Chromium, przekazanie tokenu przez `shell-url` w prawdziwym starcie sesji.
- Zachowanie przy `hidepid` na `/proc`, na fizycznych dyskach NVMe i przy wielu interfejsach sieciowych.

## Dyski, pendrive'y i pliki (od 0.3.2~rc2)
- `GET /v1/dyski` (token): partycje z `lsblk` z rodzajem `systemowy` / `windows` / `usb` / `inny`. Ukryte są partycje techniczne (EFI, MSR, Windows RE, swap, zram).
- `POST /v1/dyski/montuj {"sciezka", "zapis"}`, `/odmontuj`, `/wysun` (tylko USB). Wykonuje to `udisksctl` jako zwykły użytkownik, bez hasła dzięki regule polkit `packaging/files/50-sharkos-dyski.rules`: aktywna lokalna sesja, grupa sudo, wyłącznie montowanie, odmontowanie i wysunięcie.
- **Dyski wewnętrzne** (Windows) montują się domyślnie **tylko do odczytu**. Zapis tylko na wyraźne `zapis: true`, które nakładka wysyła po potwierdzeniu użytkownika. Po hibernacji lub szybkim uruchamianiu Windowsa usługa zwraca czytelny komunikat.
- **Pendrive'y montują się same:** wątek co 3 s, zdarzenia przez `GET /v1/zdarzenia?od=N`. Wyłącza je `SHARK_SYSD_AUTOMOUNT=0`.
- `GET /v1/pliki?sciezka=&ukryte=` (token): zawartość katalogu, tylko w katalogu domowym oraz w `/media`, `/run/media` i `/mnt`. Dowiązania wychodzące poza te miejsca są odrzucane.
- Nakładka, okno Pliki: Katalog domowy, Ten komputer i lista „Urządzenia”. Prawy przycisk na dysku daje menu: Otwórz, Zamontuj (tylko odczyt), Zamontuj z zapisem…, Odmontuj, Wysuń.
