# shark-assistantd — asystent AI dla nakładki SharkOS

Mała usługa HTTP (Python 3.11+, tylko biblioteka standardowa), przez którą rekin w `shell/index.html` rozmawia z Claude (Anthropic) albo GPT (OpenAI). Nasłuchuje **wyłącznie** na `127.0.0.1:7377` (inny adres niż pętla zwrotna jest odrzucany przy starcie). Klucze API zna tylko usługa — interfejs nigdy ich nie dostaje.

## Adresy (kontrakt z `shell/README.md`)

| Metoda | Adres | Co robi |
|---|---|---|
| GET | `/v1/health` | `{"ok": true, "providers": {"claude": {"configured", "has_key", "model", "enabled"}, "openai": {…}}}` — bez kluczy |
| POST | `/v1/ask` | `{"provider":"claude\|openai","model":"…","system":"…","messages":[{"role":"user","content":"…"}]}` → `200 {"text":"…","provider":"…","model":"…","ms":N}` |

Błędy mają postać `{"error": "komunikat po polsku"}`, np. 400 (złe zapytanie), 403 (model spoza `allowed_models`, obce `Origin`/`Host`), 429 (limit pytań lub limit u dostawcy), 502 (zły klucz, błąd dostawcy, brak połączenia), 503 (brak klucza/modelu, dostawca niedostępny), 504 (przekroczony limit czasu). Nakładka pokazuje ten komunikat i odpowiada wtedy z wbudowanego skryptu.

Dostawcy:
- **claude** — Messages API: `POST https://api.anthropic.com/v1/messages`, nagłówki `x-api-key` i `anthropic-version: 2023-06-01`, polecenie systemowe w polu `system`; z odpowiedzi brane są tylko bloki `text`.
- **openai** — Chat Completions: `POST https://api.openai.com/v1/chat/completions`, `Authorization: Bearer …`, polecenie systemowe jako pierwsza wiadomość `system`, limit długości przez `max_completion_tokens`.

## Konfiguracja — `/etc/sharkos/assistant.toml`
Wzór: [`assistant.toml.example`](assistant.toml.example). Utworzenie pustego szablonu z prawami 0600:
```sh
sudo python3 /usr/lib/sharkos/shark-assistantd/shark_assistantd.py --config /etc/sharkos/assistant.toml init-config
sudoedit /etc/sharkos/assistant.toml        # wpisz api_key i model
sudo python3 /usr/lib/sharkos/shark-assistantd/shark_assistantd.py --config /etc/sharkos/assistant.toml check-config
sudo systemctl restart shark-assistantd
```
- Plik musi mieć prawa `0600` (lub `0400`) — przy luźniejszych usługa **nie wystartuje** i powie, jak to poprawić.
- `[claude]` / `[openai]`: `api_key`, `model` (wymagane), opcjonalnie `allowed_models` (lista modeli, które nakładka może wybrać sama; pusta = dowolny), `enabled = false`, `base_url` (tylko `https://`; `http://` wyłącznie dla 127.0.0.1 — do testów).
- `[general]`: `timeout` (s, domyślnie 25), `max_history` (10), `max_tokens` (1024), `rate_per_minute` (20), `max_parallel` (2), `system`, `allow_client_system` (czy nakładka może podać własne polecenie systemowe), `default_provider`.
- Nazwy modeli zmieniają się — w szablonie celowo są puste; trzeba wpisać aktualną nazwę z dokumentacji dostawcy.
- Brak pliku nie wywraca samej usługi (`/v1/health` pokaże `"config": "brak pliku"`), ale jednostka systemd wymaga, żeby plik istniał (`AssertPathExists`) — pakiet (zadanie 3) ma instalować pusty szablon.

## Bezpieczeństwo
- **Klucze**: tylko w pliku 0600. Pod systemd plik trafia do usługi przez `LoadCredential=` (prywatny `$CREDENTIALS_DIRECTORY`), a usługa działa jako `DynamicUser` bez dostępu do `/etc/sharkos`, katalogów domowych i urządzeń. Klucz nie pojawia się w `/v1/health`, w `check-config` ani w dzienniku; jeśli dostawca odeśle go w komunikacie błędu, zostaje zamieniony na `[klucz ukryty]`.
- **Treść rozmów nie trafia do dziennika** (brak logowania zapytań; tryb `SHARK_ASSISTANTD_DEBUG=1` loguje tylko linie zapytań HTTP).
- **Ochrona przeglądarki**: `Host` musi wskazywać `127.0.0.1`/`localhost` (DNS rebinding), `Origin` musi być `null` lub `file://` (nakładka z pliku) albo dodany przez `--allow-origin`.
- **Ochrona rachunku**: limit pytań na minutę, maks. 2 równoczesne zapytania, krótka historia (ostatnie 10 wiadomości, każda przycięta do 4000 znaków), treść zapytania do 64 KB, odpowiedź do 1024 tokenów.
- **Znane ograniczenie**: usługa nie wymaga tokenu, więc każdy *lokalny* program na tym komputerze może zadać pytanie na koszt właściciela klucza (strony WWW nie — blokuje je `Origin`). Dla komputera jednej osoby to akceptowalne; limit na minutę ogranicza szkody. Do rozważenia: token sesji jak w `shark-sysd`.

## Historia rozmowy
Usługa jest bezstanowa — historię trzyma nakładka i wysyła ją w `messages`. Usługa porządkuje ją przed wysłaniem: pomija puste wiadomości, skleja kolejne wiadomości tej samej roli, obcina do `max_history`, usuwa wiadomości `assistant` z początku (Messages API wymaga startu od `user`) i wymaga, żeby ostatnia była od użytkownika.

## Nakładka (`shell/index.html`) — zmiany
- Limit czasu odpowiedzi podniesiony z 6 s do 30 s (usługa ma 25 s na dostawcę).
- Komunikat błędu usługi (np. „Brak klucza API dla openai…”) jest pokazywany zamiast ogólnego „nie mogę połączyć się”.
- Ustawienia → Asystent AI → **Testuj** czyta `/v1/health` i mówi, czy wybrany dostawca jest gotowy (i jaki model), czy brakuje klucza lub modelu.

## Instalacja
Najprościej pakietem `sharkos` (`packaging/README.md`) — postinst tworzy pusty `/etc/sharkos/assistant.toml` (0600) i włącza usługę. Ręcznie:
```sh
sudo install -Dm644 shark_assistantd.py /usr/lib/sharkos/shark-assistantd/shark_assistantd.py
sudo install -Dm644 systemd/shark-assistantd.service /usr/lib/systemd/system/shark-assistantd.service
sudo python3 /usr/lib/sharkos/shark-assistantd/shark_assistantd.py --config /etc/sharkos/assistant.toml init-config
sudo systemctl daemon-reload && sudo systemctl enable --now shark-assistantd
curl -s http://127.0.0.1:7377/v1/health
```

## Testy
```sh
python3 -m pytest services/shark-assistantd
```

## Co sprawdzono (7.11.2026, kontener w chmurze, Python 3.13)
- **39 testów pytest** z atrapą serwerów Anthropic i OpenAI na 127.0.0.1: format zapytań obu API (ścieżki, nagłówki, `system`, `max_tokens`/`max_completion_tokens`), odczyt odpowiedzi (w tym pomijanie bloków innych niż `text`), porządkowanie i skracanie historii, `allowed_models`, blokada polecenia systemowego z nakładki, mapowanie błędów 401/429/500/zła odpowiedź, limit czasu (1 s), brak połączenia, brak klucza/modelu, limit na minutę, prawa pliku (0644/0640 odrzucone, 0600/0400 przyjęte), walidacja konfiguracji, `$CREDENTIALS_DIRECTORY`, `init-config` (0600, bez nadpisywania), `check-config` bez kluczy, serwer HTTP (CORS, preflight, `Host`, `Origin`, 400/404/413), wycinanie klucza z błędu, odmowa nasłuchu na 0.0.0.0, start procesu usługi i zakończenie SIGTERM, odmowa startu przy pliku 0644.
- Usługa uruchomiona na 127.0.0.1:7377 w kontenerze: `curl` na `/v1/health` i `/v1/ask` (z atrapą dostawcy).
- Nakładka w Chromium bez okna (Playwright), 1440×900 i 400×800: odpowiedź Claude przez usługę, komunikat „brak klucza” dla GPT z powrotem do skryptu, przycisk **Testuj** w Ustawieniach, zachowanie bez usługi (skrypt awaryjnie), brak błędów skryptu, brak przewijania w poziomie.
- Prawdziwy `api.anthropic.com` z fałszywym kluczem: zapytanie doszło, odpowiedź 401 zamieniona na „Claude odrzucił klucz API”. Potwierdza połączenie TLS i obsługę błędu — **nie** potwierdza poprawnej odpowiedzi z prawdziwym kluczem.
- `systemd-analyze verify` jednostki bez uwag; `systemd-analyze security --offline`: ocena 3.0 „OK”.

## Nieprzetestowane
- Prawdziwa rozmowa z Claude i z OpenAI (brak kluczy w chmurze; `api.openai.com` jest tu zablokowany przez serwer pośredniczący, więc nawet test z fałszywym kluczem nie był możliwy).
- Działanie jednostki w prawdziwym Debianie 13: `LoadCredential=` + `DynamicUser=`, `MemoryDenyWriteExecute=` z Pythonem, DNS przy ograniczonych `RestrictAddressFamilies`, start po `network-online.target`.
- VM, sesja kiosku cage + Chromium, praca bez sieci przy starcie systemu.
