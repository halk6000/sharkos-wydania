# SharkOS

Własny system operacyjny: na start nakładka na czysty Debian 13, docelowo zmodyfikowane jądro i optymalizacje. Cel: automatyczny instalator bez obsługi (poza wyborem dysku), pulpit z rekinem-asystentem, uruchamianie aplikacji Windows / Android / Java.

| Folder | Co zawiera | Stan |
|---|---|---|
| `installer/preseed` | automatyczna instalacja Debiana (wariant VM i PC): GPT, EFI + btrfs z podwolumenami `@`, `@home`, `@var-log`, zstd | 20 testów + hook btrfs na prawdziwym btrfs (loop, busybox); instalacja w VM nietestowana |
| `vm` | skrypty QEMU dla Windows: podgląd, test instalatora (preseed + hook btrfs + pakiet SharkOS w initrd), uruchomienie | nieuruchamiane na Windows |
| `shell` | nakładka graficzna (pulpit, okna, rekin) — `index.html` | test w Chrome (headless) |
| `tools/shark-cleaner` | sprzątanie po Node.js z kwarantanną | 13 testów |
| `tools/shark-store` | wspólny magazyn zależności Wine/Proton/Java/Android | 10 testów |
| `services/shark-sysd` | dane systemu dla nakładki (CPU, RAM, dysk, sieć, procesy, systemd) na 127.0.0.1:7378 | 15 testów + test nakładki w Chromium; bez testu w VM |
| `services/shark-assistantd` | rekin-asystent przez Claude / OpenAI na 127.0.0.1:7377, klucze tylko w `/etc/sharkos/assistant.toml` (0600) | 39 testów z atrapą API + test nakładki w Chromium; bez prawdziwego klucza i VM |
| `packaging` | pakiet `sharkos_*.deb` (nakładka + sesja kiosku cage/chromium, wszystkie usługi i jednostki systemd), `install-sharkos.sh` jako hook `late_command` | 29 testów + instalacja w chroot (Ubuntu 24.04); bez Debiana 13, kiosku i VM |
| `system/tuning` | strojenie etap 1: zram (zstd), sysctl (swappiness, dirty, `max_map_count`), planista I/O, limity journald, `preempt=full`, tryb gry (cgroups v2) — `sharkos-tuning.sh wlacz/wylacz/stan`; plan własnego jądra (etap 2) | 28 testów + sysctl i zram na żywo w kontenerze; bez VM, nie włączane automatycznie |
| `experiments/codex-v0.3` | import roboczych prac Codexa v0.3 (orkiestracja QEMU, podpisane aktualizacje, testy w gościu: Wine/Java/Android/gra/audio) — do przeglądu, nie do uruchamiania na fizycznych dyskach | 4 testy hosta (14 przypadków) OK w chmurze; reszta wymaga VM — nieuruchamiana |
| `docs` | **raport z nocy 7/8.11** (`RAPORT-NOCY-2026-11-08.md`: co zrobione, jak przetestowane, od czego zacząć w VM), dziennik przekazania prac, stan wersji 0.2, plan nocy, **kryteria gotowości** przed fizycznym komputerem (`KRYTERIA-GOTOWOSCI.md`: 47 testów z poleceniem i oczekiwanym wynikiem, brama, karta wyników) | 69 testów spójności listy; samych kryteriów nikt jeszcze nie wykonał w VM |

**Nic nie było jeszcze uruchomione w VM ani na Windowsie** — kolejność testów: `docs/RAPORT-NOCY-2026-11-08.md` (sekcja 3) i `docs/KRYTERIA-GOTOWOSCI.md`.

Wersje laboratoryjne 0.1/0.2 i obrazy maszyn wirtualnych są poza repo (zob. `.gitignore`). Prace Codexa nad v0.3 są w `experiments/codex-v0.3` (import 8.11, bez obrazów i kluczy) — plan integracji w raporcie, sekcja 5–6.

Testy: `python3 -m pytest tools services packaging installer docs system` (222 OK + 1 pominięty z `shellcheck`, `lintian`, `btrfs-progs`, `busybox`, `systemd-zram-generator`, `udev`) · pakiet: `sh packaging/build-deb.sh`
