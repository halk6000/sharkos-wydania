# shark-shell — nakładka graficzna SharkOS — SZKIC v0.1

Jeden plik `index.html` (HTML + CSS + JS, bez bibliotek). Działa w każdej przeglądarce. Docelowo to pulpit SharkOS uruchamiany w trybie kiosku.

## Co już jest
- **Osobne okna**: przeciąganie, zmiana rozmiaru, minimalizacja do docka, maksymalizacja (2× klik w pasek), fokus. Wygląd: czarne tło, czerwony obrys, smukły biały pasek tytułu.
- **Pulpit**: górny pasek (sieć, dźwięk, powiadomienia, zegar, szukaj), ikony, dock, menu startowe z wyszukiwaniem, `Ctrl+Shift+Esc` otwiera Menedżera zadań.
- **Instalator**: 4 etapy, **czerwony pasek postępu z białą, niewypełnioną częścią**, aktualny moduł, czas, komunikaty rekina, opcjonalny głos (synteza mowy pl-PL).
- **Menedżer zadań**: Procesy / Wydajność (wykresy na żywo) / Uruchamianie / Usługi, szybkie akcje. Demonstracyjny proces `video_boost` co jakiś czas zużywa dużo CPU, a rekin wtedy ostrzega.
- **Panel zasobów**: Win / APK / Java, daj/odejmij zasoby, priorytet, Tryb gry (rekin się chowa), Testuj (piaskownica). Każdy typ ma **własną instrukcję i kreator uruchamiania**: .exe (Wine / Proton / maszyna z Windows + piaskownica), .apk (osobna maszyna z Androidem, uprawnienia domyślnie wyłączone), .jar (wybór wersji Javy i limitu RAM).
- **Pliki, Ustawienia** i **uproszczony Terminal**: przyciski najczęstszych poleceń, polskie nazwy poleceń (`pliki`, `system`, `otwórz`, `sprzątaj`, `rekin`…) z linuksowymi odpowiednikami (`ls`, `uname`…) wraz z wyjaśnieniem, Tab podpowiada, przy literówce „Czy chodziło o…”.
- **Rekin w bąblu** — klatki z arkuszy póz użytkownika (`sprites/<tryb>-01…12.webp`, 256×256, przezroczyste tło; nakładka wczytuje je jako pliki). Zestawy po 12 póz: `terminal` (praca, terminal), `search` (nauka, szukanie), `resources` (wykresy, suwaki), `game` (słuchawki, pad), `test` (laboratorium), `launch` (Windows / Android / Java, rakieta), `help` (rozmowa). Animowany, przeciągany, zawsze na wierzchu (poza trybem gry).
  - 1 klik: rozmowa · 2 kliki: 90% przezroczystości (kolejne 2: powrót) · 3 kliki: Menedżer zadań.
  - Tryby (2–4 klatki): instalacja, szukanie, terminal, zasoby, gra, testuj, uruchamianie Win/APK/Java, pomoc, alarm, sukces.
  - Sesja administratora: pęk złotych kluczy przy bąblu.
  - **Płynność:** każda zmiana pozy to krótkie „pyknięcie” bańki (skala 0,95 → 1,03 → 1, 260 ms), bez przenikania dwóch póz; pozy w pętli co 700 ms (spoczynek co 1,3 s).
  - **Spoczynek (`nuda`):** po 45 s bez ruchu myszy i klawiatury rekin czeka, wzdycha, ziewa, wyjmuje paletkę, gra w ping-ponga, śmieje się i odpoczywa (etapy 1–10 animacji „Instalacja”, potem pętla odpoczynku). Ruch myszy albo klawisz go budzi.
  - **Sceny sytuacyjne** (raz, każda klatka ze swoim czasem, potem powrót):
    - `uruchom-win`, `uruchom-apk`, `uruchom-java`: przegląda systemy, zatrzymuje się na właściwym, ładowanie, rakieta, ✓. Gra po „Uruchom” w kreatorze Panelu zasobów.
    - `doradca`: dymki „…” i „?”, wykres, lista kroków, ✓. Pojawia się przy pytaniach „jak…”, „gdzie…”, „pomoc”.
    - `nauka`: czapka i książka, pomysł. Pojawia się przy „naucz mnie”, „jak się używa”.
    - Nowe sceny dopisuje się w `SEQ` jako `{scena:[[klatka, ms], …], potem:"tryb"}`.
  - Podmiana grafik: nowy arkusz 3 × 4 póz z przezroczystym tłem → `python3 tools/sprite-rekina.py terminal=arkusz.webp` (inne tryby tak samo, kilka naraz). Kod się nie zmienia.

## Animacja „Instalacja” (rekin w bańce, 12 etapów)
`media/rekin-instalacja.webp` to arkusz 24 × 12 klatek (24 kl./s, 12 s): czekanie, wzdychanie, ziewanie, pomysł,
paletka, ping-pong, śmiech, odpoczynek, pasek postępu, ✓. Klatki narysował użytkownik (paczka z ChatGPT). Przejścia
między pozami są zastąpione „pyknięciem” bańki, bez półprzezroczystego nakładania dwóch póz.
- **Tryb `install`:** etapy 1–11 w pętli. Działa w oknie Instalatora i w bańce rekina, gdy trwa instalacja.
- **Tryb `koniec`:** pasek postępu i ✓, potem pętla etapu 12. Działa na końcu instalacji i na ekranie „Instalacja zakończona”.
- Przy wyłączonych animacjach albo `prefers-reduced-motion` widać jedną nieruchomą klatkę.
- **Nowe klatki** (np. 256 px, te same nazwy `klatka_001…288.png`): `python3 tools/animacja-instalacji.py paczka.zip`.
  Skrypt nadpisze arkusz, a kod się nie zmienia, bo rozmiar klatki wynika z arkusza.

## Ekran „Instalacja zakończona” (pierwszy start)
Przy starcie nakładka pyta `shark-sysd` o `GET /v1/install` (znaczniki instalatora z `/var/lib/sharkos`: data, wersja pakietu, btrfs, hasło domyślne). Po świeżej instalacji raz pokazuje okno z animacją rekina (etap 12 arkusza `media/rekin-instalacja.webp`: pasek postępu i ✓), dźwiękiem `media/instalacja-zakonczona.wav` (wygenerowany, bez cudzych praw) i przypomnieniem o zmianie hasła (`passwd` na tty2; przycisk „Już zmieniłem” wyłącza przypomnienie). Kiosk uruchamia chromium z `--autoplay-policy=no-user-gesture-required`, żeby dźwięk zagrał sam. Bez `shark-sysd` (zwykła przeglądarka) — jak dotąd podgląd instalatora. Sprawdzone w VM 8.11.2026.

## Asystent AI — wymienny dostawca
Ustawienia → Asystent AI: **Skrypt (offline)** · **Claude** · **GPT**.
Interfejs nigdy nie trzyma kluczy API. Rozmowa idzie przez lokalną usługę **`shark-assistantd`** (`services/shark-assistantd`, klucze w `/etc/sharkos/assistant.toml`):
```
POST http://127.0.0.1:7377/v1/ask   {"provider":"claude|openai","model":"…","system":"…","messages":[{"role":"user","content":"…"}]}
  → 200 {"text":"odpowiedź"}
GET  http://127.0.0.1:7377/v1/health → 200
```
Gdy usługa nie odpowiada lub zwraca błąd (np. brak klucza), rekin pokazuje komunikat usługi i odpowiada ze skryptu. Limit czasu odpowiedzi: 30 s. **Testuj** w Ustawieniach mówi, czy wybrany dostawca ma klucz i model (z `/v1/health`).

## Prawdziwe dane systemu — `shark-sysd`
Menedżer zadań pyta usługę `shark-sysd` (`http://127.0.0.1:7378`, opis w `services/shark-sysd/README.md`). Gdy odpowiada, znaczek okna zmienia się na zielony „dane na żywo”: CPU/RAM/dysk/sieć, procesy i usługi systemd są prawdziwe, a „Zakończ zadanie”, „Wstrzymaj / wznów” i „Niższy priorytet” działają na własnych procesach użytkownika (z tokenem sesji z adresu `index.html#sysd-token=…`). Gdy usługa nie odpowiada — dane przykładowe jak dotąd.

## Okno agenta — Home + Enter (`shark-agentd`)
Home trzymany + Enter (albo ikona w docku) otwiera okno agenta w stylu Codexa: rozmowa z Claude Code albo
Codex CLI na koncie użytkownika, przez usługę `shark-agentd` (`http://127.0.0.1:7379`, opis w
`services/shark-agentd/README.md`, token z adresu `index.html#…&agent-token=…`). Na dole dwie ikonki:
Claude i OpenAI — kliknięcie wybiera dostawcę i model. Widać polecenia z wynikami, zmiany plików, zwijane
rozmyślania i karty „Pozwól raz / Odmów” dla rzeczy niebezpiecznych. Bez usługi okno mówi, że agent nie działa.

## Co jest na niby (oznaczone w oknach „dane przykładowe”)
Bez `shark-sysd`: zużycie CPU/RAM/dysku/sieci i listy procesów. Zawsze: aplikacje Win/APK/Java, postęp instalacji, pliki, restart usług.

## Uruchomienie w SharkOS (propozycja, do testu w VM)
- Sesja Wayland w trybie kiosku, np. `cage -- chromium --kiosk --app=file:///usr/share/sharkos/shell/index.html`.
- Czcionki są teraz pobierane z Google Fonts. W systemie trzeba je spakować lokalnie (Exo 2, Figtree, JetBrains Mono — licencja OFL), żeby pulpit działał offline.
- Prawdziwe okna aplikacji (Blender, przeglądarka, gry) potrzebują kompozytora Wayland. Ta nakładka pokazuje wygląd i zachowanie. Docelowo jej styl przenosi się na motyw kompozytora (np. labwc/wayfire) i panel, a rekin zostaje osobną warstwą „zawsze na wierzchu”.

## Sprawdzone
Chrome bez okna (headless), 1440×900 i 400×800: brak błędów skryptu, brak przewijania w poziomie na telefonie. Działają: otwieranie okien, 3 kliki → menedżer zadań, 2 kliki → przezroczystość, polecenia terminala, przełączenie dostawcy na Claude bez usługi (powrót do skryptu). Menedżer zadań z działającym `shark-sysd` na 127.0.0.1 (prawdziwe dane, akcje na procesie testowym) i bez niego (dane przykładowe) — szczegóły w `services/shark-sysd/README.md`.
