# shark-store — wspólny magazyn zależności (Win / Android / Java)

Status: prototyp, **10/10 testów** (pytest, także test zabezpieczenia przed zapisem jako zwykły użytkownik). Nie testowany w VM SharkOS.

## Problem
Każdy prefiks Wine ma własną kopię setek DLL, Proton i Wine dublują biblioteki (Vulkan, czcionki), kolejne wersje Javy przynoszą te same czcionki i dane ICU, obrazy Androida mają wspólne części. Na dysku to te same bajty po kilka razy.

## Rozwiązanie
- Każdy plik trafia do magazynu **raz**, pod nazwą swojej sumy SHA-256 (`objects/ab/cdef…`), tylko do odczytu.
- Każda zależność ma własny **manifest z typem** (`wine`, `proton`, `java`, `android`, `runtime`, `lib`), nazwą i wersją: `manifests/<typ>/<nazwa>.json`. System nadal widzi ją jako konkretny typ zależności, a w odtworzonym katalogu leży znacznik `.shark-dependency.json`.
- Odtwarzanie drzewa (`deploy`): **reflink** (kopia copy-on-write na btrfs/XFS, bezpieczna nawet przy zapisie) → **hardlink** do obiektu tylko do odczytu → zwykła kopia.
- `stats` pokazuje, ile miejsca oszczędza współdzielenie, także **między typami**. `verify` sprawdza sumy, `gc` sprząta nieużywane obiekty.

```
shark-store import wine   wine-9      9.0    /opt/wine-9
shark-store import proton proton-9    9.0-3  /opt/proton-9
shark-store import java   openjdk-21  21.0.5 /usr/lib/jvm/java-21
shark-store deploy wine wine-9 ~/.local/share/sharkos/wine/gra-x
shark-store stats
```

## Decyzje i zasady
- **Biblioteki systemowe** (Mesa, Vulkan, czcionki, ICU) najlepiej brać z pakietów Debiana raz dla całego systemu. Magazyn służy temu, czego Debian nie współdzieli: prefiksom Wine/Proton, pobranym JDK, obrazom Androida.
- **Dane użytkownika i zapisy gier nie trafiają do magazynu.** Tylko pliki programów (zależności), bo te się nie zmieniają.
- Przy dowiązaniach twardych zmiana jednego pliku zmieniłaby go wszędzie, dlatego obiekty są tylko do odczytu. Aktualizacja to nowy import (`--replace`) i nowy `deploy`. Stare obiekty sprząta `gc`.
- **Zalecenie dla instalatora:** system plików **btrfs** z kompresją zstd. Daje reflinki (pełne bezpieczeństwo przy zapisie), dodatkową oszczędność z kompresji i migawki do wycofywania aktualizacji. Obecny preseed używa domyślnego ext4, więc działa tryb hardlink.

## Do zrobienia
- [ ] Integracja z launcherem (panel „Aplikacje i zasoby”): przy pierwszym uruchomieniu .exe/.apk/.jar odtwarzać runtime z magazynu.
- [ ] Prefiksy Wine: importować `drive_c/windows` jako `lib`, zostawiając rejestr i dane aplikacji poza magazynem.
- [ ] Pomiar na prawdziwych runtime'ach (Wine + Proton + 2 wersje JDK) w VM: realna oszczędność w GB.
- [ ] Przełączenie preseed na btrfs (osobna receptura partycjonowania) i test w VM.
