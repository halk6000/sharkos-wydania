# Migawki systemu przed aktualizacją (AKT-05)

Przed każdą zmianą pakietów (apt) SharkOS robi migawkę systemu (`@`) tylko do odczytu. Gdy aktualizacja coś zepsuje, w menu GRUB-a wybierasz **„SharkOS — przywróć system z migawki” → data**, a system startuje w stanie sprzed aktualizacji. `/home` i `/var/log` to osobne podwolumeny, więc Twoje pliki i logi zostają.

Od wersji pakietu **0.3.1** wszystko to jest w pakiecie `sharkos` i jest **domyślnie włączone**; `install-sharkos.sh` robi dodatkowo pierwszą migawkę `…-po-instalacji` (punkt „tak jak po instalacji”, nie jest usuwana automatycznie).

| Element | Plik |
|---|---|
| polecenie | `/usr/sbin/sharkos-migawka utworz [opis] \| lista \| przywroc <nazwa> \| sprzataj` |
| hak apt | `/etc/apt/apt.conf.d/80sharkos-migawka` (`DPkg::Pre-Invoke`; błąd migawki nie blokuje aktualizacji; po apt `update-grub`) |
| menu GRUB | `/etc/grub.d/41_sharkos_migawki` (10 najnowszych; **jądro i initramfs z migawki**, więc moduły pasują także po aktualizacji jądra) |
| przywracanie przy starcie | `initramfs-tools`: hook + `local-premount/sharkos-przywroc` (`sharkos.przywroc=` → podmiana `@` przed zamontowaniem `/`) |
| ustawienia | `/etc/sharkos/migawki.conf` (`MAX=5`, `MIN_ODSTEP=120`, `WLACZONE=tak`) |

Wyłączenie automatycznych migawek: `WLACZONE=nie` w `/etc/sharkos/migawki.conf`. Na systemie bez pakietu `sharkos`: `sudo sh system/snapshots/sharkos-snapshots.sh wlacz|wylacz` (przy zainstalowanym pakiecie skrypt odmawia).

Zasady: automatyczne migawki nazywają się `…-apt`, trzymamy 5 najnowszych; ręczne (`utworz przed-czyms`) nie są usuwane automatycznie. Przywrócenie zachowuje poprzedni stan jako `@przed-przywroceniem-…` (przy przywracaniu z menu GRUB-a czas w nazwie jest w UTC — initramfs nie zna strefy), żeby dało się wrócić; usuń go ręcznie, gdy wszystko działa (`sudo mount -o subvolid=5 /dev/… /mnt && sudo btrfs subvolume delete /mnt/@przed-przywroceniem-…`). Gdy utworzenie nowego `@` się nie uda, zmiana jest cofana i system startuje jak dawniej.

W menu są tylko migawki, których initramfs umie przywracać (zrobione po włączeniu mechanizmu). Starsze przywraca się z działającego systemu: `sudo sharkos-migawka przywroc <nazwa>` i restart. Po przywróceniu menu GRUB-a pochodzi z chwili migawki — nowsze pozycje wrócą przy najbliższym apt (albo `sudo update-grub`).

## Sprawdzone
- **VM, 9.11.2026** (`E:\VM\sharkos-t11`, Debian 13, jądro 6.12.115, UEFI, TCG): aktualizacja pakietu 0.3.0~noc3 → 0.3.1~rc1 (82 s, initramfs z `sharkos-przywroc` i `btrfs`); `apt-get install cowsay` → migawka `…-apt` i pozycja w GRUB-ie (18 s razem); po zmianach w `/etc` i `/home` restart z pozycji „Przywróć: …” (`grub-reboot`): `cowsay` i zmiany w `/etc` cofnięte, plik w `/home` zachowany, `/` = `[/@]`, `@przed-przywroceniem-…` istnieje, `next_entry` wyczyszczony, kiosk i usługi `active`, brak jednostek `failed`.
- 14 testów na atrapach `btrfs`/`findmnt`: nazwy, jedna migawka na aktualizację, limit 5 tylko dla `apt`, brak działania poza btrfs przy apt, przywracanie i cofnięcie przy błędzie, instalacja plików, składnia `sh -n`.

## Nieprzetestowane
- przywracanie po aktualizacji **jądra** (mechanizm jest — jądro z migawki — ale nie było nowszego jądra do sprawdzenia), Secure Boot na prawdziwym PC, migawka `po-instalacji` w chroot instalatora (sprawdzi ją następna czysta instalacja, T-20).
