# shark-cleaner — sprzątanie po Node.js dla SharkOS — SZKIC

Status: **13/13 testów jednostkowych przechodzi** (pytest) + test na prawdziwym `/proc` w Linuksie. Nietestowany w VM SharkOS.

## Zasady bezpieczeństwa
- Domyślnie **tylko podgląd**; zmiany wyłącznie z `--apply`.
- `node_modules` rusza tylko w projekcie z `package.json`/lockfile, **nieużywanym od 30 dni** (liczy się kod projektu, nie samo `node_modules`).
- Pomija projekt, w którym jakiś proces ma katalog roboczy; cache npm/yarn/pnpm pomija, gdy działa jakikolwiek `node`/`npm`/`pnpm`/`yarn`.
- Nie podąża za dowiązaniami, nie liczy zagnieżdżonych `node_modules` podwójnie.
- Nic nie usuwa od razu: **kwarantanna** w `~/.local/share/shark-cleaner/`, przywracanie `restore <id>`, trwałe usunięcie po 7 dniach.
- Blokada przed równoległym uruchomieniem; raport `last-report.json`.

## Użycie
```
shark-cleaner scan              # co by sprzątnął
shark-cleaner scan --apply      # sprzątnij (do kwarantanny)
shark-cleaner list              # kwarantanna
shark-cleaner restore <id>      # przywróć
shark-cleaner purge --apply     # zwolnij miejsce od razu
```
Instalacja (usługa użytkownika + codzienny timer, najniższy priorytet): `sh install.sh`

## Do zrobienia
- [ ] Test w VM SharkOS (systemd --user, timer).
- [ ] Panel w interfejsie SharkOS pokazujący `last-report.json` (ile odzyskano, co jest w kwarantannie).
- [ ] Ewentualnie inne śmietniki: `~/.cache/pip`, stare logi Codexa, `/var/cache/apt`.
