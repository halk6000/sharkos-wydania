# Konta i ekran wyboru konta

Ekran wyboru konta działa jak w Windows: kafelki kont, hasło i „Nowe konto”.

| Rola | Konto w systemie | Co może |
|---|---|---|
| **root** | grupa `sudo` | pełna kontrola. Zmiany systemu i repozytoriów SharkOS po odblokowaniu: kod z akinoxmusic.pl (`pkexec sharkos-root kod …`) albo `sudo sharkos-root` |
| **admin** | grupa `sharkos-admin` | wszystko oprócz edycji systemu |
| **user** | bez tych grup | z ograniczeniami, także w terminalu (biała lista + zgody) |

`sharkos-konta` to usługa systemowa na 127.0.0.1:7381:
- `GET /v1/konta`;
- `POST /v1/zaloguj`, `/v1/wyloguj`, `/v1/nowe-konto`, `/v1/tryb`.

Hasła sprawdza z `/etc/shadow` (crypt systemu), nie zapisuje ich i nie loguje. Po 5 złych próbach na konto robi 2 minuty przerwy.

Nowe konto zatwierdza konto z uprawnieniami: admina albo usera zakłada admin lub root, a roota tylko root.

Ekran wyboru konta to sesja kiosku jako systemowe konto `sharkos-greeter` (nakładka z `#tryb=logowanie`, bez usług użytkownika). Po zalogowaniu `sharkos-konta` przełącza `User=` kiosku i go restartuje.

Tryb ustawia `SHARKOS_WYBOR_KONTA` w `/etc/sharkos/kiosk.conf`:
- `auto` (domyślnie): ekran wyboru, gdy są co najmniej 2 konta, a przy jednym automatyczne logowanie;
- `zawsze`;
- `nigdy`.

Decyzję przy starcie podejmuje `sharkos-konta-start.service`, przed kioskiem.

Awaryjnie zawsze działa konsola Ctrl+Alt+F3.
