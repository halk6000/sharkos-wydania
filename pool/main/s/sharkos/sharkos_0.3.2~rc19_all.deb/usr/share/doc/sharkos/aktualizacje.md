# Aktualizacje SharkOS

Pakiet `sharkos` aktualizuje się sam z publicznego repozytorium wydań
(`https://halk6000.github.io/sharkos-wydania/`, źródło `/etc/apt/sources.list.d/sharkos.sources`).
apt sprawdza podpis kluczem z pakietu (`/usr/share/keyrings/sharkos-archive-keyring.gpg`).

| Element | Co robi |
|---|---|
| `sharkos-aktualizacja.timer` | raz dziennie (i 5 min po starcie) uruchamia `sharkos-aktualizuj auto` |
| `/etc/sharkos/aktualizacje.conf` | `TRYB=automatycznie` (domyślnie) / `powiadom` / `wylacz` |
| `sharkos-aktualizuj sprawdz` | pobiera listę **tylko** z repozytorium SharkOS i zapisuje stan |
| `sharkos-aktualizuj instaluj` | instaluje nowszy pakiet `sharkos`. Przed zmianą apt robi migawkę systemu (menu GRUB-a → przywróć) |
| `/var/lib/sharkos/aktualizacja.json` | stan dla nakładki: `aktualna`, `dostepna`, `instaluje`, `zainstalowano`, `blad`, `wylaczone` |
| `shark-sysd` `GET /v1/aktualizacja`, `POST /v1/aktualizacja/sprawdz` i `/instaluj` | przyciski w nakładce. Uruchamiają stałe jednostki `sharkos-aktualizacja-sprawdz.service` / `-instaluj.service` |
| polkit `51-sharkos-aktualizacje.rules` | te dwie jednostki może uruchomić bez hasła tylko aktywna, lokalna sesja z grupy sudo |

Aktualizowany jest tylko pakiet `sharkos`, a nie pozostałe pakiety Debiana.

Nowa wersja działa po ponownym uruchomieniu, bo działające usługi i nakładka nie są przerywane w trakcie pracy.

Ręcznie:

```sh
sudo sharkos-aktualizuj sprawdz
sudo sharkos-aktualizuj instaluj
sharkos-aktualizuj stan
```
