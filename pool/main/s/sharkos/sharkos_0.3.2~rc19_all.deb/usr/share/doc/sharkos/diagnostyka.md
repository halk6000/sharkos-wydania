# Diagnostyka SharkOS

`sharkos-diagnostyka` zbiera stan grafiki i sesji kiosku do `/var/log/sharkos/diagnostyka.txt`:
- parametry jądra;
- moduły grafiki (nvidia / nouveau / simpledrm…), `nvidia_drm modeset`;
- karty z `lspci`, pakiety NVIDIA;
- ekrany i ich tryby;
- dziennik `sharkos-kiosk` i komunikaty `drm` z jądra.

`sharkos-diagnostyka.timer` robi raport 2 minuty po starcie, a potem co 2 minuty sprawdza pendrive'y. Gdy podłączony dysk ma folder **`SHARKOS-LOGI`** (zakłada go instalator SharkOS na pendrivie), trafia tam kopia `system-<data>-<rozruch>.txt`, raz na każdy rozruch. Na inne dyski nic nie jest zapisywane.

Ręcznie: `sudo sharkos-diagnostyka` (zapis) albo `sharkos-diagnostyka --pokaz` (na ekran).
