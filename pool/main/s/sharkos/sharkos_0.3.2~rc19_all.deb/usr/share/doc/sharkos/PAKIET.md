# SharkOS — pakiet .deb i instalacja integracji

Status: **pakiet buduje się i instaluje w chroot (Ubuntu 24.04), 29 testów pytest.** Sesja kiosku (cage + chromium) i pełna instalacja z preseed **nie były uruchomione** — brak VM i brak dostępu do mirrora Debiana w chmurze (szczegóły niżej).

## Pliki

| Plik | Do czego |
|---|---|
| `build-deb.sh` | buduje `build/sharkos_<wersja>_all.deb` przez `dpkg-deb --root-owner-group` (bez roota, powtarzalnie: czas z ostatniego commita) |
| `make-media.sh` | tworzy `build/media/sharkos/` (`install-sharkos.sh`, pakiet, `SHA256SUMS`) i `build/media/sharkos-payload.cpio` do doklejenia do initrd |
| `make-iso.sh` | **obraz ISO SharkOS** z oficjalnego netinst Debiana 13: dokłada `/preseed` i `/sharkos` oraz pozycje menu „Zainstaluj SharkOS” (domyślna, wariant PC) i „…w maszynie wirtualnej” (bez pytań, czyści `/dev/vda`); rozruch BIOS/UEFI odtwarzany 1:1 przez `xorriso -boot_image any replay`. `sh packaging/make-iso.sh debian-13.*-netinst.iso` → `build/sharkos-<wersja>-amd64.iso` + `.sha256`. Pakiet sharkos: nowszy z repozytorium SharkOS albo z nośnika (`/cdrom/sharkos`), system bazowy z mirrora Debiana |
| `make-mini-iso.sh` | **mały obraz instalatora (ok. 88 MB zamiast ok. 790 MB)**: Debianowy netboot `mini.iso` (pobierany i sprawdzany łańcuchem podpisu Debiana: InRelease → Release → SHA256SUMS) + w initrd: `/preseed`, `/sharkos` (pakiet ok. 1,3 MB jako zapas) i `/firmware` (domyślnie `firmware-realtek`, `firmware-iwlwifi`; `SHARKOS_FIRMWARE`). Te same pozycje menu co `make-iso.sh` („obok” tylko w UEFI). Instalacja **wymaga internetu**: cały Debian z `deb.debian.org`. `sh packaging/make-mini-iso.sh` → `build/sharkos-<wersja>-mini-amd64.iso` + `.sha256` |
| `apt-repo.sh` | **repozytorium apt** (statyczne pliki: `dists/stable`, `pool/`, podpis `InRelease`/`Release.gpg`) z pakietów `.deb`; podpis kluczem z `SHARKOS_APT_KEY` |
| `apt-klucz.sh` | jednorazowo: nowy klucz podpisu repozytorium (ed25519, 3 lata) → publiczny do `files/sharkos-archive-keyring.gpg`, prywatny do sekretu GitHuba |
| `install-sharkos.sh` | instaluje pakiet z zależnościami (`apt-get install ./…deb`, awaryjnie `dpkg -i` + `apt-get -f install`) i włącza kiosk; uruchamiany przez hook preseed albo ręcznie |
| `debian/` | `control.in`, `changelog` (wersja), `postinst`, `prerm`, `postrm`, `conffiles`, `copyright` |
| `files/` | `sharkos-kiosk.service`, `sharkos-kiosk` (włącz/wyłącz), `sharkos-kiosk-session` (start chromium), `kiosk.conf` |
| `tests/` | `python3 -m pytest packaging` |

## Co instaluje pakiet `sharkos`

| Ścieżka | Co |
|---|---|
| `/usr/share/sharkos/shell/` | nakładka `index.html` + `sprites/` |
| `/usr/bin/shark-cleaner`, `/usr/bin/shark-store` | narzędzia (shebang `/usr/bin/python3`) |
| `/usr/lib/sharkos/shark-sysd/`, `/usr/lib/sharkos/shark-assistantd/` | usługi; dowiązania `/usr/bin/shark-sysd`, `/usr/bin/shark-assistantd` |
| `/usr/lib/systemd/system/shark-assistantd.service` | usługa systemowa, **włączona** przez postinst |
| `/usr/lib/systemd/user/shark-sysd.service`, `shark-cleaner.{service,timer}` | jednostki użytkownika, **włączone globalnie** (`deb-systemd-helper --user`) dla każdego konta |
| `/usr/lib/systemd/system/sharkos-kiosk.service` | sesja kiosku na tty1 — tylko instalowana; włącza ją `sharkos-kiosk enable` |
| `/usr/bin/sharkos-kiosk`, `/usr/lib/sharkos/sharkos-kiosk-session` | włączanie kiosku i program startowy sesji |
| `/etc/sharkos/kiosk.conf` | ustawienia kiosku (conffile) |
| `/etc/sharkos/assistant.toml` | **nie** jest w pakiecie: postinst tworzy pusty szablon 0600 root:root tylko, gdy pliku nie ma; aktualizacja pakietu go nie nadpisuje, `purge` go usuwa |

Zależności: `python3`, `systemd`, `init-system-helpers`. Zalecane (instalowane domyślnie przez apt): `cage`, `chromium`, `fonts-jetbrains-mono`.
Program `shark-cleaner` w pakiecie leży w `/usr/bin` (ręczny `tools/shark-cleaner/install.sh` nadal kładzie go w `/usr/local/bin`); ścieżkę w jednostce poprawia `build-deb.sh`.

## Sesja kiosku
- `sharkos-kiosk.service` uruchamia `cage -s -- sharkos-kiosk-session` na tty1 jako zwykły użytkownik (`PAMName=sharkos-kiosk` → `/etc/pam.d/sharkos-kiosk` → sesja logind → startuje menedżer użytkownika, a z nim `shark-sysd`; własny plik PAM bez `pam_unix` w `account`, bo `login` odrzucał konto z wymuszoną przez instalator zmianą hasła). Zastępuje `getty@tty1`; po 5 awariach w 2 min oddaje tty1 zwykłemu logowaniu.
- `sudo sharkos-kiosk enable [konto]` zapisuje `User=` w `/etc/systemd/system/sharkos-kiosk.service.d/10-user.conf`, włącza jednostkę i ustawia `graphical.target` (jeśli trzeba — `disable` cofa tylko to, co sam zmienił). Bez tego pliku jednostka się nie uruchomi, więc kiosk nigdy nie działa jako root. Konto domyślne: pierwsze z UID ≥ 1000 i powłoką logowania.
- `sharkos-kiosk-session` czeka do 10 s na token `shark-sysd`, składa adres `file:///usr/share/sharkos/shell/index.html#sysd-token=…` i uruchamia `chromium --kiosk --app=… --ozone-platform=wayland` z profilem w `~/.local/state/sharkos/chromium`. Bez tokenu nakładka startuje na danych przykładowych.

## Hook instalatora (preseed)
`late_command` w `installer/preseed/sharkos-common.cfg` szuka katalogu `sharkos/` z `install-sharkos.sh`:
1. na nośniku: `/cdrom/sharkos` (skopiuj tam `build/media/sharkos/`),
2. w initrd instalatora: `/sharkos` (doklej `build/media/sharkos-payload.cpio` do initrd).

Znaleziony katalog kopiuje do `/target/var/lib/sharkos/media` i uruchamia `in-target sh …/install-sharkos.sh` (przez `sh`, bo ISO9660 gubi bit `x`). Log: `/var/log/sharkos-install.log` (pierwsza linia `source: …`, przy błędzie `FAILED rc=N`). Wynik: `/var/lib/sharkos/integration-done`. Brak katalogu → `/var/lib/sharkos/integration-pending`. Błąd integracji nie przerywa instalacji Debiana.

```sh
sh packaging/make-media.sh                  # → packaging/build/media/
sudo sh packaging/install-sharkos.sh        # ręcznie na gotowym Debianie 13 (zbuduje pakiet)
sudo sh install-sharkos.sh --no-kiosk       # opcje: --user KONTO, --no-recommends, --deb PLIK, --dry-run
```

## Co sprawdzono (8.11.2026 ok. 00:00–00:20, kontener w chmurze)
- **29 testów pytest** (`packaging/tests`): pola `control`, lista plików, prawa i właściciel `root/root`, brak `/usr/local` i brak `assistant.toml` w pakiecie, shebangi, poprawiona ścieżka `shark-cleaner`, zgodność `md5sums`, **powtarzalność budowy** (identyczny SHA-256), `lintian` bez błędów, `sh -n` + `shellcheck` wszystkich skryptów, `systemd-analyze verify` jednostki kiosku (z podstawionym `cage`), `sharkos-kiosk enable/disable/status` na sztucznym drzewie (`systemctl --root`), odmowa dla root/UID < 1000/braku konta, adres nakładki z tokenem i bez, brak chromium, `make-media.sh` (sumy, cpio newc), `install-sharkos.sh --dry-run`, **hook `late_command` wykonany w busybox sh** z atrapą `in-target` (nośnik, initrd, brak katalogu, błąd skryptu), scalony preseed vm/pc przez `debconf-set-selections -c`.
- `lintian`: brak błędów; ostrzeżenia: brak stron `man` (5 programów) i `privacy-breach-generic` — nakładka pobiera czcionki z Google Fonts (znany problem, zob. `shell/README.md`).
- **Instalacja w chroot Ubuntu 24.04** (debootstrap; mirror Debiana jest w tej chmurze zablokowany): ścieżka jak w instalatorze (kopia do `/var/lib/sharkos/media`, uruchomienie w chroot bez działającego systemd, `--no-recommends`) → pakiet zainstalowany, `assistant.toml` 0600, dowiązania włączające `shark-assistantd`, `shark-sysd`, `shark-cleaner.timer`, `sharkos-kiosk` dla `shark`; ponowna instalacja zachowuje zmieniony `assistant.toml`; `sharkos-kiosk disable` cofa zmiany, `dpkg -r` maskuje usługi (jak debhelper), `dpkg -P` usuwa konfigurację, klucze i dowiązania (magazyn `/var/lib/sharkos/store` zostaje celowo); instalacja z wyłączoną siecią (apt update nieudany) przechodzi, gdy zależności są w systemie. W chroot jako `shark`: `shark-sysd serve` odpowiada na 127.0.0.1:7378, `sharkos-kiosk-session` (tryb próbny) składa adres z prawdziwym tokenem.

## Nieprzetestowane (czeka na VM z Debianem 13)
- [ ] Instalacja na **Debianie 13**: dostępność i wersje `cage`, `chromium`, `fonts-jetbrains-mono`, `init-system-helpers` (testowano na Ubuntu 24.04 bez pakietów zalecanych).
- [ ] Sesja kiosku po rozruchu: czy cage dostaje dostęp do GPU/wejścia przez logind (konto w grupach `video`/`render`?), czy chromium działa w Wayland, czy `file://` → `http://127.0.0.1` nie jest blokowane w tej wersji chromium.
- [ ] Start `shark-sysd` przez menedżer użytkownika w sesji kiosku i działanie akcji z tokenem.
- [ ] Hook w prawdziwym instalatorze: `/cdrom/sharkos` na ISO oraz `/sharkos` z doklejonego cpio. `vm/SharkVM.ps1` od zadania 4 dokleja `packaging\build\media\sharkos-payload.cpio`, jeśli istnieje (zmiana nieuruchomiona — brak Windowsa/`pwsh`); bez niego w teście VM powstanie `integration-pending`.
- [ ] Czcionki lokalnie (bez Google Fonts) i strony `man`.

## Repozytorium apt (aktualizacje przez `apt upgrade`)

Pakiet `sharkos` zawiera źródło `/etc/apt/sources.list.d/sharkos.sources` (URI `https://halk6000.github.io/sharkos-wydania/`, `Suites: stable`) i klucz publiczny `/usr/share/keyrings/sharkos-archive-keyring.gpg` (odcisk `EA96944A47EDDFD1ADF5CD59485B81707D3FDADA`, z `files/sharkos-archive-keyring.fpr`). Źródło jest **wyłączone** (`Enabled: no`), dopóki repozytorium nie zostanie opublikowane.

Publikacja (jednorazowo, robi to właściciel repozytorium):
1. **Sekret:** GitHub → repozytorium → *Settings → Secrets and variables → Actions → New repository secret*: nazwa `SHARKOS_APT_KEY`, wartość = cała zawartość pliku `sharkos-apt-prywatny.asc` (klucz wygenerowany 8.11.2026 leży lokalnie w `E:\SharkOS-VM\apt-klucz\`). Potem zrób kopię offline i usuń plik z dysku. **Nigdy nie commituj klucza prywatnego.**
2. **Gdzie:** kod zostaje w prywatnym `halk6000/sharkos`. Publiczne jest tylko repozytorium wydań **`halk6000/sharkos-wydania`**: obrazy ISO w Releases i repozytorium apt na gałęzi `gh-pages` (Pages: *Deploy from a branch → gh-pages*). Publikowane jest tylko to, co i tak jest w ISO (pakiet `.deb`, indeksy, podpis, klucz publiczny).
3. **Wydanie:** podnieś wersję w `debian/changelog`, `git tag v0.3.2 && git push --tags` → workflow `.github/workflows/apt-repo.yml` uruchamia testy, buduje pakiet i podpisuje repozytorium (artefakt `repo-apt`, bez dostępu do innych repozytoriów). Potem na swoim komputerze: `.\packaging\opublikuj-repo-apt.ps1` (pobiera artefakt, sprawdza podpis i sumy, wypycha na `gh-pages` repozytorium wydań; `-Podglad` = bez wypychania). Obrazy ISO: `gh release create v0.3.2 -R halk6000/sharkos-wydania *.iso *.sha256`.
4. **Włączenie u użytkowników:** w kolejnej wersji pakietu zmień w `files/sharkos.sources` na `Enabled: yes` (conffile — dpkg zaktualizuje go, jeśli użytkownik go nie zmieniał). Na już zainstalowanym systemie ręcznie: `sudo sed -i 's/^Enabled: no/Enabled: yes/' /etc/apt/sources.list.d/sharkos.sources && sudo apt update`.

**Instalator też z niego korzysta:** `make-media.sh` kładzie obok pakietu plik `REPO` (adres z `files/sharkos.sources`) i klucz. `install-sharkos.sh` dodaje na czas instalacji tymczasowe źródło (`sharkos-instalator.sources`, `Signed-By` = ten klucz). Jeśli repozytorium ma **nowszą** wersję z poprawnym podpisem, instaluje ją; w przeciwnym razie (brak sieci, 404, obcy podpis, ta sama albo starsza wersja) bierze pakiet z nośnika. Wybór trafia do `/var/lib/sharkos/integration-done` (`zrodlo=repozytorium|nosnik`), podgląd daje `install-sharkos.sh --pokaz-zrodlo`. Dopóki repozytorium nie jest opublikowane, instalator zawsze bierze kopię z nośnika.

Sprawdzone 8.11.2026 w SharkOS (VM): repozytorium zbudowane `apt-repo.sh`, podpisane, serwowane przez HTTP → `apt-get update` weryfikuje `InRelease` kluczem z pakietu, `apt-cache policy sharkos` widzi wersję z repozytorium; testy `tests/test_apt_repo.py` (prawdziwe apt, odrzucenie obcego klucza). Publikacja na GitHub Pages — jeszcze nie (wymaga kroków 1–3).