# shark-agentd — okno agenta SharkOS (Home + Enter)

Skrót **Home + Enter** (Home trzymany, potem Enter) otwiera w nakładce okno agenta w stylu Codexa.
Rozmowa idzie przez prawdziwe programy dostawców, uruchamiane na koncie użytkownika:

| Ikonka na dole okna | Program | Logowanie |
|---|---|---|
| Claude (pomarańczowa gwiazdka) | Claude Code: `claude -p … --output-format stream-json` | konto Claude (`claude auth login`) |
| OpenAI (sześciokąt) | Codex CLI: `codex exec --json …` | konto ChatGPT (`codex login --device-auth`, kod na telefon) |

Kliknięcie ikonki otwiera listę modeli danego dostawcy (lista w ustawieniach, można też wpisać inną nazwę).
Każdy dostawca ma własną rozmowę; **Nowa rozmowa** zaczyna od zera.

W oknie widać: odpowiedzi, zwijane **Rozmyślanie**, każde polecenie z wynikiem i kodem wyjścia,
zmiany plików, listę zadań (Codex), koszt i czas tury (Claude).

## Logowanie bez haseł w SharkOS
Instalator systemu niczego nie pyta. Przy pierwszym użyciu okno pokazuje kartę
**Zainstaluj** (program trafia do `~/.local/bin`, bez hasła administratora) i **Zaloguj**.
Logowanie robi sam program dostawcy: okno pokazuje jego wyjście, link do strony logowania
i pole na kod. Hasło wpisujesz tylko na stronie dostawcy (albo potwierdzasz na telefonie) —
SharkOS go nie widzi i nie zapisuje. Tokeny trzymają programy dostawców w swoich plikach
(`~/.claude/`, `~/.codex/`), jak na każdym innym komputerze. Każde konto w SharkOS loguje się osobno.

## Bezpieczeństwo
- Polecenia, testy i edycja plików w katalogu domowym idą **bez pytania**.
- **Strażnik** (`straznik.py`, hook PreToolUse Claude Code) zatrzymuje rzeczy niebezpieczne:
  dyski i partycje, rozruch i firmware, `sudo`, konta i hasła, wyłączanie zabezpieczeń,
  rekursywne usuwanie dużych katalogów, `git push` / `reset --hard`, skrypty z internetu
  prosto do powłoki, publikację pakietów, odczyt tokenów i kluczy, zapis poza katalogiem domowym.
  Okno pokazuje wtedy kartę **Pozwól raz / Pozwól na zadanie / Odmów**.
  - „Raz” dotyczy dokładnie tego jednego polecenia (skrót SHA-256), jest jednorazowe i wygasa po 10 minutach.
  - „Na zadanie” dotyczy tego samego rodzaju ryzyka i tego samego programu (np. wszystkie `sudo apt`; przy zapisie: ten sam katalog). Obowiązuje do „Nowej rozmowy”, najdłużej 2 h.
- **Terminal nakładki** (`/v1/shell`) to prawdziwy `bash` na koncie użytkownika, w pseudoterminalu.
  - Polecenia z białej listy strażnika (`straznik.ocen_terminal`: tylko odczyt, np. `ls`, `cd`, `grep`, `git status`, `systemctl status`) działają od razu.
  - Reszta pyta tymi samymi trzema przyciskami. Zapis do pliku (`>`), podstawianie poleceń i opcje zapisu (`find -delete`, `sed -i`) też pytają.
  - Programy pełnoekranowe (`nano`, `htop`…) odsyłają do konsoli Ctrl+Alt+F3.
- **Codex** działa w swojej piaskownicy `workspace-write` (zapis tylko w katalogu roboczym i /tmp,
  sieć włączona). Hooka strażnika Codex nie ma — polecenia z listy strażnika okno oznacza ostrzeżeniem.
- **Migawka systemu** przed każdą nową rozmową (najwyżej co 30 min): `sudo -n sharkos-migawka utworz agent`.
  Plik `/etc/sudoers.d/sharkos-agent` pozwala bez hasła wyłącznie na to jedno polecenie.
  Migawki „agent” są w menu GRUB-a od razu, trzymane jest 5 ostatnich.
- Sesja agenta **nie zna hasła sudo** — zmian systemowych agent sam nie zrobi.
- Usługa słucha tylko na `127.0.0.1:7379`, wymaga tokenu sesji (`X-Shark-Token`, plik 0600
  w `$XDG_RUNTIME_DIR/shark-agentd/token`, do nakładki przez część `#` adresu), sprawdza `Host`
  i `Origin` (jak shark-sysd).
- **Granica:** strażnik chroni przed pomyłką modelu, nie przed celowym obejściem — agent działa
  z uprawnieniami tego samego konta. Twarde granice to brak hasła sudo i migawka systemu.
  Katalog domowy (`@home`) nie jest objęty migawką systemu.

## Ustawienia
`~/.config/sharkos/agent.toml` — wzór: [`agent.toml.example`](agent.toml.example).
Po zmianie: `systemctl --user restart shark-agentd`. Stan programów: `shark-agentd status`.

## Adresy
| Metoda | Adres | Co robi |
|---|---|---|
| GET | `/v1/health` | bez tokenu: `{"ok": true}` |
| GET | `/v1/status[?odswiez=1]` | czy Claude Code / Codex są zainstalowane i zalogowane, modele |
| POST | `/v1/agent` | `{provider, prompt, model?, session_id?, cwd?}` → `{run_id}` |
| GET | `/v1/runs/<id>?after=N` | nowe zdarzenia przebiegu (okno odpytuje co 0,45 s) |
| POST | `/v1/runs/<id>/stop` · `/input` · `/interrupt` | zatrzymanie · tekst dla programu · Ctrl+C (SIGINT) |
| POST | `/v1/approve` · `/v1/deny` | „Pozwól raz” / „na zadanie” (`scope`: `raz`/`zadanie`, wznawia rozmowę) · „Odmów” |
| POST | `/v1/task/end` | nowa rozmowa: zgody „na zadanie” agenta wygasają |
| POST | `/v1/shell` | `{session, command, consent?}` → `{run_id, cwd}` albo `{zgoda_wymagana, powod, klucz, niebezpieczne}` |
| POST | `/v1/shell/task-end` | `{session}`: koniec zadania w terminalu |
| POST | `/v1/login/<p>` · `/v1/install/<p>` | logowanie / instalacja w pseudoterminalu |

Zdarzenia: `start`, `text`, `thinking`, `tool`, `tool_result`, `file`, `plan`, `approval`,
`snapshot`, `warning`, `error`, `log`, `output`, `link`, `done`.

## Testy
```sh
python3 -m pytest services/shark-agentd
```
Atrapy `claude` i `codex` w testach wypisują zdarzenia w formacie prawdziwych programów.

## Nieprzetestowane
- Prawdziwe Claude Code i Codex na koncie użytkownika (logowanie, rozmowa, hook strażnika
  w prawdziwym Claude Code) — test T-26 na docelowym komputerze.
- Nazwy poleceń logowania (`claude auth login`, `codex login --device-auth`) i pliku wydania
  Codexa dla Linuksa — ustawialne w `agent.toml`, jeśli dostawca je zmieni.
