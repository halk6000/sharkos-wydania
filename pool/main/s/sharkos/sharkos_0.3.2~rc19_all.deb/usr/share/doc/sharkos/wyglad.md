# Wygląd SharkOS: nazwa systemu, GRUB, ekran startowy

W pakiecie `sharkos` od 0.3.1~rc2.

| Element | Plik | Działanie |
|---|---|---|
| nazwa systemu | `/usr/lib/sharkos/sharkos-os-release` → `/usr/lib/os-release` | `NAME="SharkOS"`, `PRETTY_NAME="SharkOS <wersja> (Debian 13 trixie)"`, `VARIANT_ID=sharkos`. **`ID=debian` zostaje** — programy i skrypty instalacyjne, które sprawdzają dystrybucję, dalej widzą Debiana. Plik Debiana jest przekierowany (`dpkg-divert`) do `/usr/lib/os-release.debian`; wyzwalacz dpkg składa nowy plik po każdej aktualizacji `base-files`. Usunięcie pakietu przywraca oryginał. |
| tło GRUB-a | `/usr/share/sharkos/grub/tlo.png`, `/etc/default/grub.d/sharkos.cfg` | ciemnogranatowy gradient z rekinem w bańce; dodaje `splash` do parametrów jądra |
| ekran startowy | `/usr/share/plymouth/themes/sharkos/` (moduł `script`) | rekin w bańce „pływa”, napis SharkOS, trzy pulsujące kropki; komunikaty (fsck) i pytanie o hasło szyfrowanego dysku |
| ikona systemu | `/usr/share/pixmaps/sharkos.png` | `LOGO=sharkos` w os-release |

Motyw plymouth ustawia się **raz** (znacznik `/var/lib/sharkos/plymouth-motyw-ustawiony`); później wybór administratora (`plymouth-set-default-theme`) jest szanowany. Gdy `plymouth` instaluje się po `sharkos` (Recommends), motyw ustawia wyzwalacz.

Menu GRUB-a pokazuje „SharkOS GNU/Linux” bez osobnego ustawienia: Debian 13 ma w `/etc/default/grub` `GRUB_DISTRIBUTOR` wzięty z `NAME` w os-release. Skutek uboczny: najbliższy `grub-install` (np. przy aktualizacji pakietu GRUB-a) wgrywa bootloader do `\EFI\sharkos` i dodaje wpis NVRAM „sharkos” na początku kolejności; `\EFI\debian` i `\EFI\BOOT` zostają jako zapas.

## Sprawdzone w VM (9.11.2026, `E:\VM\sharkos-t11`)
- aktualizacja 0.3.1~rc1 → rc2: `hostnamectl` → „SharkOS 0.3.1~rc2 (Debian 13 trixie)”, przekierowanie os-release w `dpkg-divert --list`; `apt-get install --reinstall base-files` → wyzwalacz sharkos składa plik ponownie, nazwa zostaje;
- zrzuty ekranu z rozruchu (VmRunner): menu GRUB-a z tłem i pozycjami „SharkOS GNU/Linux” oraz „SharkOS — przywróć system z migawki”, potem ekran plymouth z rekinem, napisem i kropkami; rozruch 44 s (TCG), kiosk i usługi `active`;
- `grub-install` z nazwą SharkOS → `\EFI\sharkos` + wpis `Boot0004* sharkos`; restart z tego wpisu (`BootCurrent: 0004`) — system działa.
- Bez sprawdzenia: Secure Boot na prawdziwym PC (shim podpisany przez Microsoft; nazwa katalogu nie powinna mieć znaczenia), pytanie o hasło szyfrowanego dysku w motywie.

Grafika: logo z dawnego `shell/sprites/help-1.webp` (rekin projektu; od 10.11.2026 w historii git, w nakładce są nowe zestawy póz); tło wygenerowane skryptem (gradient + logo), bez cudzych praw.
