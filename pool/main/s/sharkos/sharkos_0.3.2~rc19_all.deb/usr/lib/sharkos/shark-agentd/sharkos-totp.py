#!/usr/bin/python3
"""SharkOS — jednorazowe kody roota (TOTP, RFC 6238: HMAC-SHA1, 6 cyfr, okres 120 s).

Ten sam sekret ma panel administratora na akinoxmusic.pl (albo aplikacja Aegis / 2FAS), który pokazuje kod.
Wywołuje go sharkos-root (jako root):
  sharkos-totp sparuj           nowy sekret → /etc/sharkos/root-totp (0600), wypisuje go i link otpauth://
  sharkos-totp sprawdz KOD      0 = kod dobry (raz: ten sam kod drugi raz nie przejdzie), 1 = zły, 3 = blokada
  sharkos-totp stan             czy sparowano
Ochrona: po 5 złych kodach w 10 min — blokada 10 min. Okno czasu: bieżący i poprzedni okres (zegar ±2 min).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import socket
import struct
import sys
import time
from pathlib import Path

OKRES = 120
CYFRY = 6
SEKRET = Path(os.environ.get("SHARKOS_TOTP_SEKRET", "/etc/sharkos/root-totp"))
STAN = Path(os.environ.get("SHARKOS_TOTP_STAN", "/var/lib/sharkos/root-totp.json"))
MAX_BLEDOW, OKNO_BLEDOW, BLOKADA = 5, 600, 600


def kod(sekret_b32: str, licznik: int) -> str:
    klucz = base64.b32decode(sekret_b32.upper() + "=" * (-len(sekret_b32) % 8))
    h = hmac.new(klucz, struct.pack(">Q", licznik), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    liczba = (struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % (10 ** CYFRY)
    return str(liczba).zfill(CYFRY)


def _stan() -> dict:
    try:
        return json.loads(STAN.read_text())
    except (OSError, ValueError):
        return {}


def _zapisz_stan(s: dict) -> None:
    STAN.parent.mkdir(parents=True, exist_ok=True)
    tmp = STAN.with_suffix(".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(s, f)
    os.replace(tmp, STAN)


def normalizuj_sekret(s: str) -> str:
    """Sekret Base32 (RFC 4648) wklejony ze strony: bez spacji, myślników i „=”, wielkie litery, ≥ 16 znaków (80 bitów)."""
    s = "".join(c for c in str(s).upper() if c not in " -=\t\n")
    if not s or any(c not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567" for c in s) or len(s) < 16:
        raise ValueError("Sekret: Base32 (litery A–Z i cyfry 2–7), co najmniej 16 znaków")
    base64.b32decode(s + "=" * (-len(s) % 8))
    return s


def sparuj(sekret: str | None = None) -> int:
    """Bez argumentu — nowy sekret do wpisania na stronie; z argumentem — sekret wygenerowany przez akinoxmusic.pl."""
    try:
        s = normalizuj_sekret(sekret) if sekret else base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 2
    SEKRET.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(SEKRET, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(s + "\n")
    os.chmod(SEKRET, 0o600)
    _zapisz_stan({})
    host = socket.gethostname()
    if sekret:
        print("Sparowano z sekretem ze strony akinoxmusic.pl. Sprawdź: wpisz bieżący kod ze strony.")
        print(f"  (sekret kończy się na …{s[-4:]})")
        return 0
    print("Sekret roota SharkOS (wpisz go w panelu akinoxmusic.pl albo w aplikacji Aegis / 2FAS):")
    print(f"  {s}")
    print(f"  otpauth://totp/SharkOS:{host}?secret={s}&issuer=SharkOS&period={OKRES}&digits={CYFRY}&algorithm=SHA1")
    print(f"Kod ma {CYFRY} cyfr i zmienia się co {OKRES // 60} minuty. Poprzedni sekret przestał działać.")
    return 0


def sprawdz(podany: str, teraz: float | None = None) -> int:
    teraz = time.time() if teraz is None else teraz
    try:
        sekret = SEKRET.read_text().strip()
    except OSError:
        print("Root nie jest sparowany: sudo sharkos-root sparuj", file=sys.stderr)
        return 2
    s = _stan()
    if s.get("blokada_do", 0) > teraz:
        print(f"Za dużo złych kodów — spróbuj za {int(s['blokada_do'] - teraz) // 60 + 1} min", file=sys.stderr)
        return 3
    podany = "".join(c for c in str(podany) if c.isdigit())
    licznik = int(teraz // OKRES)
    for c in (licznik, licznik - 1):
        if len(podany) == CYFRY and hmac.compare_digest(kod(sekret, c), podany):
            if c <= s.get("ostatni", -1):
                print("Ten kod został już użyty — poczekaj na następny", file=sys.stderr)
                return 1
            _zapisz_stan({"ostatni": c})
            return 0
    bledy = [t for t in s.get("bledy", []) if teraz - t < OKNO_BLEDOW] + [teraz]
    nowy = {"ostatni": s.get("ostatni", -1), "bledy": bledy}
    if len(bledy) >= MAX_BLEDOW:
        nowy = {"ostatni": s.get("ostatni", -1), "blokada_do": teraz + BLOKADA}
    _zapisz_stan(nowy)
    print("Zły kod" + (" — zegar komputera nie jest zsynchronizowany (NTP), kody mogą się nie zgadzać"
                       if not _zegar_ok() else ""), file=sys.stderr)
    return 1


def _zegar_ok() -> bool:
    """Kod zależy od czasu: przy niezsynchronizowanym zegarze (> 2 min różnicy) nie przejdzie."""
    import subprocess
    try:
        r = subprocess.run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"], capture_output=True, text=True, timeout=5)
        return r.stdout.strip() != "no"
    except (OSError, subprocess.TimeoutExpired):
        return True


def main(argv: list[str]) -> int:
    if argv[:1] == ["sparuj"]:
        return sparuj(argv[1] if len(argv) > 1 else None)
    if argv[:1] == ["sprawdz"] and len(argv) == 2:
        return sprawdz(argv[1])
    if argv[:1] == ["stan"]:
        print("sparowano" if SEKRET.is_file() else "nie sparowano")
        return 0
    print(__doc__, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
