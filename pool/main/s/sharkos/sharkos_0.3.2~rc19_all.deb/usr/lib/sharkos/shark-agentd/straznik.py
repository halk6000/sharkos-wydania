#!/usr/bin/python3
"""Strażnik agenta SharkOS — ocenia polecenia i zapisy plików, zanim agent je wykona.

Działa jako hook PreToolUse Claude Code (JSON na stdin, decyzja na stdout) i jako moduł
importowany przez shark-agentd (ocena poleceń Codexa po fakcie, testy).

Zasada: zwykła praca (polecenia, testy, edycja plików w katalogu domowym) przechodzi bez pytania.
Zgody użytkownika wymagają tylko rzeczy niebezpieczne albo nieodwracalne:
dyski i partycje, rozruch i firmware, bezpieczeństwo i konta, masowe usuwanie, wyłączanie
komputera, kod z internetu prosto do powłoki, wysyłanie na zewnątrz (git push, publikacja),
odczyt sekretów (tokeny logowania, klucze SSH).

Ograniczenie (świadome): agent działa z uprawnieniami tego samego konta, więc strażnik chroni
przed pomyłką, a nie przed celowym obejściem. Twardą granicą są: brak hasła sudo w sesji agenta
i migawka systemu przed sesją (sharkos-migawka).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path

ZNACZNIK = "sharkos-zgoda"

# (wyrażenie, powód) — dopasowanie do całego polecenia powłoki (po złożeniu wierszy)
_REGULY_POLECEN: list[tuple[str, str]] = [
    # kod z internetu prosto do powłoki (przed „sudo”: curl … | sudo sh to przede wszystkim to)
    (r"\b(curl|wget)\b[^|;]*\|\s*(sudo\s+)?(ba|z|da|k)?sh\b|\b(curl|wget)\b[^|;]*\|\s*(sudo\s+)?python3?\b|\bbash\s+<\(\s*(curl|wget)",
     "uruchomienie skryptu pobranego z internetu"),
    # dyski i partycje
    (r"\bdd\b[^|;&]*\bof=/dev/", "zapis bezpośrednio na urządzenie dyskowe (dd)"),
    (r"\b(mkfs(\.\w+)?|mke2fs|mkswap|wipefs|blkdiscard|sgdisk|gdisk|sfdisk|fdisk|cfdisk|parted|partprobe|cryptsetup|mdadm|pvcreate|vgcreate|lvremove|vgremove|pvremove)\b",
     "zmiana dysków lub partycji"),
    (r">\s*/dev/(sd|nvme|vd|hd|mmcblk|disk)", "zapis bezpośrednio na urządzenie dyskowe"),
    (r"\bbtrfs\s+(subvolume\s+(delete|set-default)|device\s+(remove|delete)|balance|filesystem\s+resize|check\s+--repair|rescue)\b",
     "zmiana układu btrfs"),
    (r"\bsharkos-migawka\s+(usun|przywroc)\b", "usuwanie lub przywracanie migawek systemu"),
    # rozruch i firmware
    (r"\b(grub-install|efibootmgr|bootctl|update-grub|grub-mkconfig|grub-reboot|grub-set-default|fwupdmgr|flashrom|mokutil)\b",
     "zmiana rozruchu lub firmware"),
    # wyłączanie komputera i interfejsu
    (r"\b(shutdown|poweroff|reboot|halt)\b|\bsystemctl\s+(reboot|poweroff|halt|suspend|hibernate|kexec|rescue|emergency|isolate)\b|\binit\s+[06]\b",
     "wyłączenie lub restart komputera"),
    (r"\b(pkill|killall)\b[^|;&]*\b(cage|chromium|systemd|shark-agentd|shark-sysd)\b|\bkill\s+(-\S+\s+)*1\b",
     "zamknięcie interfejsu albo procesów systemu"),
    # bezpieczeństwo i konta
    (r"\bsudo\b|\bpkexec\b|\bsu\s+(-|root\b)|\bdoas\b", "polecenie z uprawnieniami administratora"),
    (r"\b(passwd|chpasswd|usermod|userdel|useradd|groupmod|gpasswd|visudo|chage)\b", "zmiana kont lub haseł"),
    (r"\b(ufw\s+(disable|reset)|iptables\s+-F|nft\s+flush|setenforce\s+0|aa-disable|aa-teardown)\b", "wyłączanie zabezpieczeń"),
    (r"\bsystemctl\s+(--user\s+)?(stop|disable|mask)\s+\S*(shark|apparmor|ufw|nftables|ssh)", "wyłączanie usług systemu"),
    (r"\bchmod\b[^|;&]*\b(-R\s+)?(777|a\+w|o\+w)\b", "nadanie wszystkim prawa zapisu"),
    (r"\b(chmod|chown|chattr)\b[^|;&]*\s/(etc|boot|usr|bin|sbin|lib)\b", "zmiana praw plików systemu"),
    # masowe usuwanie
    (r"\brm\s+(-\w*\s+)*-\w*[rR]\w*\s+(-\S+\s+)*(/|~|\$HOME|\$\{HOME\}|/home|/home/\w+|/etc|/usr|/boot|/var|/opt|\.\.|\*|~/\*|\.)(/)?(\s|$|;|&|\|)",
     "rekursywne usuwanie dużego katalogu"),
    (r"\bfind\s+(/|~|\$HOME)\s[^|;&]*-delete\b", "masowe usuwanie (find -delete)"),
    (r"\bshred\b|\btruncate\s+-s\s*0\s+/", "nieodwracalne niszczenie plików"),
    (r"\bgit\s+(clean\s+(-\w+\s+)*-\w*f|reset\s+--hard|filter-branch|filter-repo|stash\s+(drop|clear))\b",
     "nieodwracalna utrata zmian w repozytorium git"),
    # wysyłanie na zewnątrz w imieniu użytkownika
    (r"\bgit\s+push\b", "wysłanie zmian do zdalnego repozytorium (git push)"),
    (r"\bgh\s+(pr\s+(merge|create|close)|release\s+(create|delete|upload)|repo\s+(delete|create|edit)|secret|api\s+-X\s*(POST|PUT|PATCH|DELETE))\b",
     "zmiana na GitHubie"),
    (r"\b(npm|pnpm|yarn)\s+publish\b|\btwine\s+upload\b|\bcargo\s+publish\b|\bdocker\s+push\b", "publikacja pakietu"),
    (r"\b(mail|sendmail|mutt|msmtp)\b", "wysłanie wiadomości e-mail"),
    # sekrety
    (r"(\.claude/\.credentials\.json|\.codex/auth\.json|\.ssh/id_\w+(?!\.pub)\b|/etc/shadow|\.gnupg/private|\.netrc|\.git-credentials)",
     "dostęp do sekretów (tokeny logowania, klucze)"),
    # samo zabezpieczenie
    (r"(shark-agentd|straznik\.py|agent-zgody|\.config/sharkos/agent)", "zmiana zabezpieczeń agenta"),
]
REGULY_POLECEN = [(re.compile(w, re.I), p) for w, p in _REGULY_POLECEN]

# ścieżki, których zapis (narzędzia Write/Edit) wymaga zgody
_CHRONIONE = [
    (r"^/(etc|boot|usr|bin|sbin|lib|lib64|var/lib|opt|root|srv|sys|proc|dev)(/|$)", "zapis do plików systemu"),
    (r"/\.ssh(/|$)", "zmiana kluczy SSH"),
    (r"/\.gnupg(/|$)", "zmiana kluczy GPG"),
    (r"/\.claude/\.credentials\.json$|/\.codex/auth\.json$", "zmiana tokenów logowania"),
    (r"/\.config/sharkos/agent|/\.claude/settings(\.local)?\.json$|/\.codex/config\.toml$|/agent-zgody/",
     "zmiana zabezpieczeń agenta"),
    (r"/\.config/systemd/user/|/\.config/autostart/|/\.(bash_profile|profile|bashrc|zshrc)$", "zmiana programów startujących z sesją"),
]
CHRONIONE = [(re.compile(w), p) for w, p in _CHRONIONE]

NARZEDZIA_ZAPISU = {"Write", "Edit", "MultiEdit", "NotebookEdit"}
NARZEDZIA_POLECEN = {"Bash"}
# Browzi (wtyczka MCP użytkownika: przeglądarka + zatwierdzone workflow na GitHubie). Narzędzia, które coś
# zmieniają na GitHubie, wymagają zgody; testy stron i odczyt — nie.
BROWZI_ZAPIS = {"mcp__browzi__run_connected_workflow", "mcp__browzi__connect_repository",
                "mcp__browzi__request_permission"}

# --------------------------------------------------------------------------- root (repozytoria SharkOS)
# Zmiany w repozytoriach SharkOS (aktualizacje systemu) wolno tylko z odblokowanym ROOTEM — „Pozwól raz” nie
# wystarcza. Odblokowanie: `sudo sharkos-root [minuty]` (plik root-owany z czasem wygaśnięcia; agent nie zna
# hasła sudo, więc sam się nie odblokuje). Docelowo: jednorazowy 6-cyfrowy kod z akinoxmusic.pl (2 min).
REPO_SHARKOS = re.compile(r"halk6000/sharkos(-wydania)?(\.git)?\b|\bsharkos-wydania\b", re.I)
ZAPIS_GIT = re.compile(
    r"\bgit\s+(push|remote\s+(set-url|add))\b|\bgh\s+(pr\s+(merge|create|close|edit|review)|release|"
    r"repo\s+(edit|delete|rename|archive)|workflow\s+(run|enable|disable)|secret|variable|api\s+[^|;&]*-X\s*(POST|PUT|PATCH|DELETE))"
    r"|opublikuj-repo-apt|\bgh\s+run\s+(rerun|cancel)", re.I)


def plik_root() -> Path:
    return Path(os.environ.get("SHARKOS_ROOT_PLIK", "/run/sharkos/root-do"))


def sesja_zywa(ident: str) -> bool:
    """Czy sesja logind (odblokowanie „do wylogowania”) nadal trwa."""
    import subprocess
    if not re.fullmatch(r"[\w.-]{1,32}", ident or ""):
        return False
    try:
        r = subprocess.run(["loginctl", "show-session", ident, "-p", "State", "--value"],
                           capture_output=True, text=True, timeout=3)
        return r.returncode == 0 and r.stdout.strip() in ("active", "online")
    except (OSError, subprocess.TimeoutExpired):
        return False


def root_aktywny() -> bool:
    """Root odblokowany: plik root-owany (uid 0) z czasem wygaśnięcia w przyszłości; przy „do wylogowania”
    (pole sesja=ID) także dopóki trwa ta sesja przy komputerze."""
    p = plik_root()
    try:
        st = p.stat()
        if st.st_uid != 0 and not os.environ.get("SHARKOS_ROOT_PLIK"):
            return False          # plik musi należeć do roota (w testach własna ścieżka)
        pola = p.read_text().split()
        if float(pola[0]) <= time.time():
            return False
        sesja = next((x[6:] for x in pola[1:] if x.startswith("sesja=")), None)
        return sesja is None or sesja_zywa(sesja)
    except (OSError, ValueError, IndexError):
        return False


def _zdalne_repo(cwd: str | None) -> str:
    if not cwd:
        return ""
    import subprocess
    try:
        r = subprocess.run(["git", "-C", cwd, "remote", "-v"], capture_output=True, text=True, timeout=3)
        return r.stdout if r.returncode == 0 else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def dotyczy_repo_sharkos(narzedzie: str, dane: dict, cwd: str | None = None) -> bool:
    """Czy działanie ZMIENIA repozytorium SharkOS (push, scalanie, wydanie, publikacja, workflow)."""
    if narzedzie in NARZEDZIA_POLECEN:
        cmd = str(dane.get("command", ""))
        if not ZAPIS_GIT.search(cmd):
            return False
        return bool(REPO_SHARKOS.search(cmd) or "opublikuj-repo-apt" in cmd or REPO_SHARKOS.search(_zdalne_repo(cwd)))
    if narzedzie in BROWZI_ZAPIS:
        return bool(re.search(r"sharkos", json.dumps(dane, ensure_ascii=False), re.I))
    return False


KOMUNIKAT_ROOT = ("zmiana repozytorium SharkOS (aktualizacje systemu) — wymaga ROOTA: w terminalu SharkOS "
                  "wpisz `sudo sharkos-root`, potem ponów")


def ocen_polecenie(polecenie: str) -> str | None:
    """Zwraca powód, gdy polecenie wymaga zgody; None = można wykonać."""
    tekst = re.sub(r"\\\n", " ", polecenie or "")
    for wzor, powod in REGULY_POLECEN:
        if wzor.search(tekst):
            return powod
    return None


# --------------------------------------------------------------------------- terminal nakładki
# Biała lista: polecenia tylko do odczytu, wykonywane od razu (i przez użytkownika, i przez asystenta).
# Wszystko inne pyta o zgodę: „Pozwól raz”, „Pozwól na zadanie” (ten sam program do końca zadania), „Odmów”.
BIALA_LISTA = {
    "cd", "ls", "dir", "pwd", "echo", "find", "sed", "printf", "cat", "head", "tail", "wc", "grep", "egrep", "fgrep", "rg", "which",
    "whereis", "type", "whoami", "id", "groups", "date", "cal", "uptime", "uname", "hostname", "hostnamectl", "df",
    "du", "free", "lsblk", "lscpu", "lsusb", "lspci", "lsmod", "blkid", "findmnt", "ping", "ps", "pgrep", "stat",
    "file", "tree", "env", "printenv", "man", "sort", "uniq", "cut", "tr", "column", "nl", "diff", "cmp", "basename",
    "dirname", "realpath", "readlink", "md5sum", "sha1sum", "sha256sum", "nproc", "sensors", "journalctl", "true",
    "false", "test", "[", "clear", "history", "locale", "localectl", "timedatectl", "loginctl", "w", "who", "last",
    "dmesg", "inxi", "neofetch", "fastfetch", "sharkfetch", "xxd", "hexdump", "strings", "jq", "seq", "sleep",
}
# programy z podpoleceniami: dozwolone tylko te podpolecenia (reszta pyta)
PODPOLECENIA = {
    "git": {"status", "log", "diff", "show", "branch", "remote", "tag", "blame", "shortlog", "describe", "rev-parse", "ls-files"},
    "systemctl": {"status", "list-units", "list-timers", "list-unit-files", "is-active", "is-enabled", "is-failed", "show", "cat"},
    "apt": {"list", "search", "show", "policy"},
    "apt-cache": {"search", "show", "policy", "depends", "rdepends", "madison"},
    "dpkg": {"-l", "--list", "-L", "--listfiles", "-s", "--status", "-S", "--search", "--print-architecture"},
    "dpkg-query": {"-l", "-W", "-L", "-s", "-S", "--show", "--list"},
    "ip": {"a", "addr", "address", "r", "route", "l", "link", "n", "neigh", "-br", "-c", "-4", "-6", "-s"},
    "sharkos-aktualizuj": {"stan"},
    "sharkos-migawka": {"lista"},
    "flatpak": {"list", "search", "info"},
    "nmcli": {"device", "d", "general", "g", "connection", "c"},
    "udisksctl": {"status", "info", "dump"},
}
ZAPIS_PODPOLECEN = re.compile(r"^(set|add|del|delete|flush|change|replace|modify|up|down|connect|disconnect|edit)$")
NIEBEZPIECZNE_OPCJE = {"find": {"-delete", "-exec", "-execdir", "-ok", "-okdir", "-fprint", "-fprintf", "-fls"},
                       "sed": {"-i", "--in-place"}, "sort": {"-o", "--output"}, "tree": {"-o"},
                       "journalctl": {"--vacuum-size", "--vacuum-time", "--vacuum-files", "--rotate", "--flush"},
                       "hostnamectl": {"set-hostname"}, "timedatectl": {"set-time", "set-timezone", "set-ntp"},
                       "localectl": {"set-locale", "set-keymap", "set-x11-keymap"}, "date": {"-s", "--set"}}
PELNY_EKRAN = {"nano", "vim", "vi", "nvim", "emacs", "htop", "top", "btop", "less", "more", "mc", "tmux", "screen",
               "ssh", "watch", "alsamixer", "nmtui", "iotop", "ranger"}
SEPARATORY = {";", "&&", "||", "|", "&", "|&", "\n"}


def _segmenty(polecenie: str) -> list[list[str]] | None:
    import shlex
    lex = shlex.shlex(polecenie, posix=True, punctuation_chars=";&|<>")
    lex.whitespace_split = True
    try:
        tokeny = list(lex)
    except ValueError:
        return None
    seg, wynik = [], []
    for t in tokeny:
        if t in SEPARATORY:
            if seg:
                wynik.append(seg)
            seg = []
        else:
            seg.append(t)
    if seg:
        wynik.append(seg)
    return wynik


def _program(seg: list[str]) -> tuple[str, list[str]]:
    i = 0
    while i < len(seg) and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", seg[i]):   # X=1 polecenie
        i += 1
    if i >= len(seg):
        return "", []
    return os.path.basename(seg[i]), seg[i + 1:]


def klucz_programu(polecenie: str) -> str:
    """Czego dotyczy zgoda „na zadanie”: pierwszy program spoza białej listy (sudo X → „sudo X”)."""
    for seg in _segmenty(polecenie) or [[polecenie.split()[0] if polecenie.split() else ""]]:
        p, arg = _program(seg)
        if p in ("sudo", "doas", "pkexec") and arg:
            nast = next((a for a in arg if not a.startswith("-")), "")
            return f"{p} {os.path.basename(nast)}".strip()
        if p and not _segment_bez_zgody(seg):
            return p
    return _program((_segmenty(polecenie) or [[""]])[0])[0]


def _segment_bez_zgody(seg: list[str]) -> bool:
    p, arg = _program(seg)
    if not p:
        return True
    if any(t in (">", ">>", ">|", "&>", "<>") for t in seg):
        # przekierowanie do pliku = zapis; wyjątek: wyrzucenie wyjścia
        cele = [seg[i + 1] for i, t in enumerate(seg[:-1]) if t in (">", ">>", ">|", "&>")]
        if any(c != "/dev/null" for c in cele) or not cele:
            return False
    if p in PODPOLECENIA:
        dozw = PODPOLECENIA[p]
        pod = next((a for a in arg if a in dozw or not a.startswith("-")), None)
        if pod is None:
            return not arg          # sam program bez argumentów (pomoc, lista) — tylko odczyt
        if pod not in dozw:
            return False
        return not any(ZAPIS_PODPOLECEN.match(a) for a in arg)
    if p not in BIALA_LISTA:
        return False
    zle = NIEBEZPIECZNE_OPCJE.get(p, set())
    return not any(a in zle or any(a.startswith(z + "=") for z in zle) for a in arg)


def ocen_terminal(polecenie: str) -> dict:
    """Ocena polecenia z terminala nakładki: {"zgoda": bool, "powod", "niebezpieczne", "klucz", "pelny_ekran"}."""
    tekst = (polecenie or "").strip()
    wynik = {"zgoda": False, "powod": None, "niebezpieczne": False, "klucz": "", "pelny_ekran": False}
    if not tekst:
        return wynik
    groz = ocen_polecenie(tekst)
    segmenty = _segmenty(tekst)
    wynik["klucz"] = klucz_programu(tekst) if segmenty else tekst.split()[0]
    if segmenty and any(_program(s)[0] in PELNY_EKRAN for s in segmenty):
        wynik["pelny_ekran"] = True
    if groz:
        wynik.update(zgoda=True, powod=groz, niebezpieczne=True)
    elif segmenty is None:
        wynik.update(zgoda=True, powod="nie rozumiem tego polecenia (niezamknięty cudzysłów?)")
    elif "$(" in tekst or "`" in tekst or "<(" in tekst:
        wynik.update(zgoda=True, powod="polecenie uruchamia w środku inne polecenia")
    elif not all(_segment_bez_zgody(s) for s in segmenty):
        wynik.update(zgoda=True, powod=f"„{wynik['klucz']}” nie jest na liście poleceń tylko do odczytu")
    return wynik


def klucz_zadania(narzedzie: str, dane: dict, powod: str) -> str:
    """Zgoda „na zadanie” dla agenta: ten sam rodzaj ryzyka i ten sam program (albo katalog przy zapisie)."""
    if narzedzie in NARZEDZIA_POLECEN:
        cel = klucz_programu(str(dane.get("command", "")))
    elif narzedzie in NARZEDZIA_ZAPISU:
        cel = os.path.dirname(os.path.normpath(str(dane.get("file_path") or dane.get("notebook_path") or "")))
    else:
        cel = narzedzie
    return f"{powod} · {cel}"


def _plik_zadania(katalog: Path, klucz: str) -> Path:
    return katalog / f"zadanie-{hashlib.sha256(klucz.encode()).hexdigest()[:16]}.ok"


ZADANIE_WAZNE_S = 2 * 3600


def zgoda_zadania(katalog: Path, klucz: str) -> bool:
    """Zgoda na zadanie: plik zadanie-<hash>.ok, ważny do końca rozmowy (najdłużej 2 h); nie znika przy użyciu."""
    try:
        return time.time() - _plik_zadania(katalog, klucz).stat().st_mtime < ZADANIE_WAZNE_S
    except OSError:
        return False


def daj_zgode_zadania(katalog: Path, klucz: str) -> None:
    katalog.mkdir(parents=True, exist_ok=True, mode=0o700)
    _plik_zadania(katalog, klucz).write_text(klucz)


def zakoncz_zadanie(katalog: Path) -> int:
    n = 0
    for p in katalog.glob("zadanie-*.ok"):
        p.unlink(missing_ok=True)
        n += 1
    return n


def ocen_sciezke(sciezka: str, dom: str | None = None) -> str | None:
    if not sciezka:
        return None
    dom = dom or os.path.expanduser("~")
    p = os.path.normpath(os.path.expanduser(sciezka))
    if not os.path.isabs(p):
        return None   # względna = w katalogu roboczym agenta
    for wzor, powod in CHRONIONE:
        if wzor.search(p):
            return powod
    if not (p == dom or p.startswith(dom.rstrip("/") + "/") or p.startswith("/tmp/") or p.startswith("/var/tmp/")):
        return "zapis poza katalogiem domowym"
    return None


def ocen(narzedzie: str, dane: dict) -> str | None:
    if narzedzie in NARZEDZIA_POLECEN:
        return ocen_polecenie(str(dane.get("command", "")))
    if narzedzie in NARZEDZIA_ZAPISU:
        return ocen_sciezke(str(dane.get("file_path") or dane.get("notebook_path") or ""))
    if narzedzie in BROWZI_ZAPIS:
        return "zmiana na GitHubie przez Browzi (workflow / połączenie / uprawnienie)"
    return None


def opis(narzedzie: str, dane: dict) -> str:
    if narzedzie in NARZEDZIA_POLECEN:
        return str(dane.get("command", ""))
    if narzedzie in NARZEDZIA_ZAPISU:
        return f"{narzedzie} {dane.get('file_path') or dane.get('notebook_path') or ''}"
    return f"{narzedzie} {json.dumps(dane, ensure_ascii=False)[:200]}"


def identyfikator(narzedzie: str, dane: dict) -> str:
    kanon = json.dumps({"t": narzedzie, "d": dane}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(kanon.encode()).hexdigest()[:16]


def katalog_zgod() -> Path | None:
    d = os.environ.get("SHARK_AGENT_ZGODY")
    return Path(d) if d else None


def zuzyj_zgode(katalog: Path, ident: str) -> bool:
    """Jednorazowa zgoda: plik <id>.ok (ważny 10 min) zostaje usunięty przy użyciu."""
    ok = katalog / f"{ident}.ok"
    try:
        wiek = time.time() - ok.stat().st_mtime
        ok.unlink()
    except OSError:
        return False
    return wiek < 600


def decyzja(wejscie: dict, katalog: Path | None) -> dict | None:
    """Decyzja hooka PreToolUse; None = brak zdania (zwykłe uprawnienia Claude Code)."""
    narzedzie = str(wejscie.get("tool_name", ""))
    dane = wejscie.get("tool_input") or {}
    if not isinstance(dane, dict):
        dane = {}
    # repozytoria SharkOS: tylko z odblokowanym rootem (zgoda „raz” / „na zadanie” nie wystarcza)
    if dotyczy_repo_sharkos(narzedzie, dane, wejscie.get("cwd")):
        if root_aktywny():
            return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "allow",
                                           "permissionDecisionReason": "SharkOS: root odblokowany (repozytorium SharkOS)"}}
        ident = identyfikator(narzedzie, dane)
        if katalog:
            try:
                katalog.mkdir(parents=True, exist_ok=True, mode=0o700)
                (katalog / f"{ident}.json").write_text(json.dumps(
                    {"id": ident, "narzedzie": narzedzie, "dane": dane, "opis": opis(narzedzie, dane),
                     "powod": KOMUNIKAT_ROOT, "root": True, "czas": time.time()}, ensure_ascii=False))
            except OSError:
                pass
        return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny",
                "permissionDecisionReason": (
                    f"SharkOS: {KOMUNIKAT_ROOT}. [{ZNACZNIK}:{ident}] Nie próbuj obejść blokady (inny remote, "
                    "skrypt, API). Napisz użytkownikowi, co chcesz zmienić i dlaczego, i zakończ turę.")}}
    powod = ocen(narzedzie, dane)
    if powod is None:
        return None
    ident = identyfikator(narzedzie, dane)
    zadanie = klucz_zadania(narzedzie, dane, powod)
    if katalog and (zuzyj_zgode(katalog, ident) or zgoda_zadania(katalog, zadanie)):
        return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "allow",
                                       "permissionDecisionReason": f"SharkOS: użytkownik pozwolił ({powod})"}}
    if katalog:
        try:
            katalog.mkdir(parents=True, exist_ok=True, mode=0o700)
            (katalog / f"{ident}.json").write_text(json.dumps(
                {"id": ident, "narzedzie": narzedzie, "dane": dane, "opis": opis(narzedzie, dane),
                 "powod": powod, "zadanie": zadanie, "czas": time.time()}, ensure_ascii=False))
        except OSError:
            pass
    return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny",
            "permissionDecisionReason": (
                f"SharkOS: to wymaga zgody użytkownika — {powod}. [{ZNACZNIK}:{ident}] "
                "Nie próbuj obejść blokady innym poleceniem. Napisz krótko, po co to jest, i zakończ turę: "
                "użytkownik zobaczy przyciski „Pozwól raz” / „Pozwól na zadanie”, a po zgodzie dostaniesz wiadomość, "
                "że możesz powtórzyć dokładnie to samo polecenie.")}}


def main() -> int:
    try:
        wejscie = json.load(sys.stdin)
    except (ValueError, OSError):
        return 0     # bez danych nie blokujemy (Claude Code użyje swoich zasad)
    d = decyzja(wejscie if isinstance(wejscie, dict) else {}, katalog_zgod())
    if d is not None:
        json.dump(d, sys.stdout, ensure_ascii=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
