#!/usr/bin/python3
"""shark-assistantd — lokalna usługa łącząca rekina-asystenta SharkOS z modelem AI.

Nasłuchuje wyłącznie na pętli zwrotnej (domyślnie 127.0.0.1:7377):

  GET  /v1/health → {"ok": true, "providers": {"claude": {"configured": ..., "model": ...}, ...}}
  POST /v1/ask    {"provider": "claude|openai", "model": "…", "system": "…",
                   "messages": [{"role": "user", "content": "…"}]}
                  → 200 {"text": "odpowiedź", "provider": ..., "model": ...}

Klucze API leżą wyłącznie w pliku konfiguracji (domyślnie /etc/sharkos/assistant.toml,
prawa 0600). Interfejs nigdy ich nie widzi: usługa nie zwraca ich w żadnej odpowiedzi
i wycina je z komunikatów błędów. Pod systemd plik trafia do usługi przez
``LoadCredential=`` (katalog $CREDENTIALS_DIRECTORY), a sama usługa działa jako
nieuprzywilejowany użytkownik dynamiczny.

Dostawcy:
  claude — Anthropic Messages API (POST {base_url}/v1/messages)
  openai — OpenAI Chat Completions (POST {base_url}/v1/chat/completions)

Tylko biblioteka standardowa Pythona 3.11+ (tomllib).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import signal
import socket
import stat
import sys
import threading
import time
import tomllib
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

VERSION = "0.1.0"
DEFAULT_PORT = 7377
DEFAULT_CONFIG = Path("/etc/sharkos/assistant.toml")
CREDENTIAL_NAME = "assistant.toml"
LOOPBACK = {"127.0.0.1", "::1", "localhost"}
DEFAULT_ORIGINS = ("null", "file://")
MAX_BODY = 64 * 1024
MAX_UPSTREAM_BODY = 2 * 1024 * 1024
MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,99}$")
PROVIDERS = ("claude", "openai")
DEFAULT_SYSTEM = "Jesteś rekinem-asystentem systemu SharkOS. Odpowiadaj krótko, po polsku."
DEFAULT_BASE = {"claude": "https://api.anthropic.com", "openai": "https://api.openai.com"}
ANTHROPIC_VERSION = "2023-06-01"

DEFAULTS = {
    "timeout": 25.0,           # s, limit czasu jednego zapytania do dostawcy
    "max_history": 10,         # ile ostatnich wiadomości z rozmowy idzie do modelu
    "max_message_chars": 4000, # przycinanie pojedynczej wiadomości
    "max_system_chars": 2000,
    "max_tokens": 1024,        # limit długości odpowiedzi modelu
    "rate_per_minute": 20,     # ochrona przed nabiciem rachunku przez zapętlony program
    "max_parallel": 2,
    "allow_client_system": True,
}


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


# --------------------------------------------------------------------------- konfiguracja

class ConfigError(Exception):
    pass


def find_config(explicit: Path | None) -> Path:
    if explicit is not None:
        return explicit
    cred = os.environ.get("CREDENTIALS_DIRECTORY")
    if cred and (Path(cred) / CREDENTIAL_NAME).exists():
        return Path(cred) / CREDENTIAL_NAME
    return DEFAULT_CONFIG


def _w_credentials(path: Path) -> bool:
    cred = os.environ.get("CREDENTIALS_DIRECTORY")
    try:
        return bool(cred) and path.resolve().parent == Path(cred).resolve()
    except OSError:
        return False


def _check_mode(path: Path) -> None:
    st = path.stat()
    if not stat.S_ISREG(st.st_mode):
        raise ConfigError(f"{path} nie jest zwykłym plikiem")
    # systemd (LoadCredential=) zawsze podaje plik z prawami 0440 w prywatnym katalogu usługi
    # ($CREDENTIALS_DIRECTORY, dostępny tylko dla niej) — tam dopuszczamy odczyt grupy, nic więcej.
    dozwolone = 0o040 if _w_credentials(path) else 0
    if st.st_mode & 0o077 & ~dozwolone:
        raise ConfigError(
            f"{path} ma prawa {stat.S_IMODE(st.st_mode):04o} — klucze API muszą być dostępne tylko dla "
            f"właściciela. Popraw: sudo chmod 600 {path}")


def _num(section: dict, key: str, kind, lo, hi, default):
    v = section.get(key, default)
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise ConfigError(f"[general] {key}: oczekiwano liczby")
    v = kind(v)
    if not lo <= v <= hi:
        raise ConfigError(f"[general] {key}: dozwolony zakres {lo}–{hi}")
    return v


def parse_config(data: dict) -> dict:
    """Sprawdza i uzupełnia konfigurację. Zwraca słownik gotowy do użycia."""
    g = data.get("general", {})
    if not isinstance(g, dict):
        raise ConfigError("[general] musi być sekcją")
    cfg = {
        "timeout": _num(g, "timeout", float, 1, 300, DEFAULTS["timeout"]),
        "max_history": _num(g, "max_history", int, 1, 50, DEFAULTS["max_history"]),
        "max_message_chars": _num(g, "max_message_chars", int, 100, 50_000, DEFAULTS["max_message_chars"]),
        "max_system_chars": _num(g, "max_system_chars", int, 0, 20_000, DEFAULTS["max_system_chars"]),
        "max_tokens": _num(g, "max_tokens", int, 16, 32_000, DEFAULTS["max_tokens"]),
        "rate_per_minute": _num(g, "rate_per_minute", int, 1, 1000, DEFAULTS["rate_per_minute"]),
        "max_parallel": _num(g, "max_parallel", int, 1, 16, DEFAULTS["max_parallel"]),
        "allow_client_system": bool(g.get("allow_client_system", DEFAULTS["allow_client_system"])),
        "system": str(g.get("system", DEFAULT_SYSTEM)),
        "default_provider": g.get("default_provider"),
        "providers": {},
    }
    if cfg["default_provider"] is not None and cfg["default_provider"] not in PROVIDERS:
        raise ConfigError(f"[general] default_provider: dozwolone {', '.join(PROVIDERS)}")
    for name in PROVIDERS:
        sec = data.get(name, {})
        if not isinstance(sec, dict):
            raise ConfigError(f"[{name}] musi być sekcją")
        key = str(sec.get("api_key", "") or "").strip()
        model = str(sec.get("model", "") or "").strip()
        base = str(sec.get("base_url", DEFAULT_BASE[name])).rstrip("/")
        if model and not MODEL_RE.match(model):
            raise ConfigError(f"[{name}] model: niedozwolone znaki w nazwie modelu")
        u = urlparse(base)
        if u.scheme == "http":
            if u.hostname not in LOOPBACK:
                raise ConfigError(f"[{name}] base_url: http:// dozwolone tylko dla 127.0.0.1 (testy); użyj https://")
        elif u.scheme != "https" or not u.hostname:
            raise ConfigError(f"[{name}] base_url: oczekiwano adresu https://")
        allowed = sec.get("allowed_models", [])
        if not isinstance(allowed, list) or not all(isinstance(m, str) for m in allowed):
            raise ConfigError(f"[{name}] allowed_models: oczekiwano listy nazw")
        cfg["providers"][name] = {"api_key": key, "model": model, "base_url": base,
                                  "allowed_models": allowed, "enabled": bool(sec.get("enabled", True))}
    return cfg


def load_config(path: Path) -> dict:
    """Wczytuje plik. Brak pliku = brak skonfigurowanych dostawców (usługa działa, health to pokaże)."""
    if not path.exists():
        return parse_config({}) | {"path": str(path), "missing": True}
    _check_mode(path)
    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(f"{path}: błąd składni TOML: {e}") from None
    return parse_config(data) | {"path": str(path), "missing": False}


def redact(text: str, cfg: dict) -> str:
    for p in cfg["providers"].values():
        k = p.get("api_key")
        if k and len(k) >= 4:
            text = text.replace(k, "[klucz ukryty]")
    return text


# --------------------------------------------------------------------------- rozmowa

def normalize_messages(raw, max_history: int, max_chars: int) -> list[dict]:
    """Krótka, poprawna historia: role user/assistant na przemian, zaczyna i kończy się na user."""
    if not isinstance(raw, list) or not raw:
        raise ApiError(400, "Pole messages musi być niepustą listą wiadomości")
    msgs: list[dict] = []
    for m in raw[-200:]:
        if not isinstance(m, dict):
            raise ApiError(400, "Każda wiadomość musi być obiektem {role, content}")
        role, content = m.get("role"), m.get("content")
        if role not in ("user", "assistant"):
            raise ApiError(400, "Dozwolone role: user, assistant")
        if not isinstance(content, str):
            raise ApiError(400, "Treść wiadomości (content) musi być tekstem")
        content = content.strip()
        if not content:
            continue
        if len(content) > max_chars:
            content = content[:max_chars] + " […]"
        if msgs and msgs[-1]["role"] == role:          # sklejamy kolejne wiadomości tej samej roli
            msgs[-1]["content"] += "\n\n" + content
        else:
            msgs.append({"role": role, "content": content})
    if not msgs or msgs[-1]["role"] != "user":
        raise ApiError(400, "Ostatnia wiadomość musi pochodzić od użytkownika (role: user)")
    msgs = msgs[-max_history:]
    while msgs and msgs[0]["role"] != "user":         # Messages API wymaga startu od user
        msgs.pop(0)
    return msgs


_DIRECT = urllib.request.build_opener(urllib.request.ProxyHandler({}))
_DEFAULT_OPENER = urllib.request.build_opener()


def _post_json(url: str, headers: dict, payload: dict, timeout: float) -> dict:
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "Accept": "application/json",
                                          "User-Agent": f"shark-assistantd/{VERSION}", **headers})
    # adresy 127.0.0.1 (testy) omijają serwer pośredniczący z HTTPS_PROXY
    opener = _DIRECT if urlparse(url).hostname in LOOPBACK else _DEFAULT_OPENER
    try:
        with opener.open(req, timeout=timeout) as r:
            body = r.read(MAX_UPSTREAM_BODY + 1)
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            j = json.loads(e.read(65536) or b"{}")
            err = j.get("error")
            detail = (err.get("message") if isinstance(err, dict) else err) or ""
        except Exception:
            pass
        raise UpstreamError(e.code, str(detail)[:300]) from None
    except (TimeoutError, socket.timeout):
        raise ApiError(504, f"Dostawca nie odpowiedział w {timeout:g} s") from None
    except urllib.error.URLError as e:
        if isinstance(e.reason, (TimeoutError, socket.timeout)):
            raise ApiError(504, f"Dostawca nie odpowiedział w {timeout:g} s") from None
        raise ApiError(502, f"Brak połączenia z dostawcą: {e.reason}") from None
    except OSError as e:
        raise ApiError(502, f"Brak połączenia z dostawcą: {e}") from None
    if len(body) > MAX_UPSTREAM_BODY:
        raise ApiError(502, "Odpowiedź dostawcy jest za duża")
    try:
        return json.loads(body)
    except ValueError:
        raise ApiError(502, "Dostawca zwrócił odpowiedź, która nie jest JSON-em") from None


class UpstreamError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status = status
        self.detail = detail


def upstream_to_api(e: UpstreamError, provider: str) -> ApiError:
    name = "Claude" if provider == "claude" else "OpenAI"
    if e.status in (401, 403):
        return ApiError(502, f"{name} odrzucił klucz API (HTTP {e.status}). Sprawdź klucz w /etc/sharkos/assistant.toml.")
    if e.status == 429:
        return ApiError(429, f"{name}: przekroczony limit zapytań lub środków na koncie. Spróbuj za chwilę.")
    if e.status == 404:
        return ApiError(502, f"{name}: nie znaleziono modelu lub adresu (HTTP 404). Sprawdź nazwę modelu.")
    if e.status in (500, 502, 503, 529):
        return ApiError(503, f"{name} jest chwilowo niedostępny (HTTP {e.status}).")
    extra = f": {e.detail}" if e.detail else ""
    return ApiError(502, f"{name} zwrócił błąd HTTP {e.status}{extra}")


def ask_claude(p: dict, model: str, system: str, msgs: list[dict], cfg: dict) -> str:
    payload = {"model": model, "max_tokens": cfg["max_tokens"], "messages": msgs}
    if system:
        payload["system"] = system
    j = _post_json(p["base_url"] + "/v1/messages",
                   {"x-api-key": p["api_key"], "anthropic-version": ANTHROPIC_VERSION},
                   payload, cfg["timeout"])
    blocks = j.get("content") if isinstance(j, dict) else None
    if not isinstance(blocks, list):
        raise ApiError(502, "Nieoczekiwany format odpowiedzi Claude")
    return "".join(b.get("text", "") for b in blocks if isinstance(b, dict) and b.get("type") == "text").strip()


def ask_openai(p: dict, model: str, system: str, msgs: list[dict], cfg: dict) -> str:
    full = ([{"role": "system", "content": system}] if system else []) + msgs
    j = _post_json(p["base_url"] + "/v1/chat/completions",
                   {"Authorization": f"Bearer {p['api_key']}"},
                   {"model": model, "messages": full, "max_completion_tokens": cfg["max_tokens"]},
                   cfg["timeout"])
    try:
        content = j["choices"][0]["message"].get("content")
    except (KeyError, IndexError, TypeError, AttributeError):
        raise ApiError(502, "Nieoczekiwany format odpowiedzi OpenAI") from None
    if isinstance(content, list):  # część modeli zwraca listę fragmentów
        content = "".join(c.get("text", "") for c in content if isinstance(c, dict))
    return str(content or "").strip()


ASKERS = {"claude": ask_claude, "openai": ask_openai}


class RateLimiter:
    def __init__(self, per_minute: int, clock=time.monotonic):
        self.per_minute, self.clock, self.hits, self.lock = per_minute, clock, [], threading.Lock()

    def allow(self) -> bool:
        with self.lock:
            now = self.clock()
            self.hits = [t for t in self.hits if now - t < 60]
            if len(self.hits) >= self.per_minute:
                return False
            self.hits.append(now)
            return True


class App:
    def __init__(self, cfg: dict, origins=DEFAULT_ORIGINS, port: int = DEFAULT_PORT, askers=None, clock=time.monotonic):
        self.cfg = cfg
        self.origins = set(origins)
        self.port = port
        self.askers = askers or ASKERS
        self.rate = RateLimiter(cfg["rate_per_minute"], clock)
        self.slots = threading.BoundedSemaphore(cfg["max_parallel"])

    def allowed_hosts(self, port: int) -> set[str]:
        return {f"{h}:{port}" for h in ("127.0.0.1", "localhost", "[::1]")} | {"127.0.0.1", "localhost", "[::1]"}

    def health(self) -> dict:
        prov = {}
        for name, p in self.cfg["providers"].items():
            prov[name] = {"configured": bool(p["api_key"] and p["model"] and p["enabled"]),
                          "has_key": bool(p["api_key"]), "model": p["model"] or None, "enabled": p["enabled"]}
        return {"ok": True, "service": "shark-assistantd", "version": VERSION,
                "config": "brak pliku" if self.cfg.get("missing") else "wczytana",
                "default_provider": self.cfg["default_provider"], "providers": prov}

    def ask(self, body: dict) -> dict:
        cfg = self.cfg
        name = body.get("provider") or cfg["default_provider"]
        if name not in PROVIDERS:
            raise ApiError(400, f"Nieznany dostawca „{name}”. Dozwolone: {', '.join(PROVIDERS)}")
        p = cfg["providers"][name]
        if not p["enabled"]:
            raise ApiError(503, f"Dostawca {name} jest wyłączony w konfiguracji")
        if not p["api_key"]:
            raise ApiError(503, f"Brak klucza API dla {name}. Administrator wpisuje go w /etc/sharkos/assistant.toml.")
        model = body.get("model") or p["model"]
        if not isinstance(model, str) or not MODEL_RE.match(model):
            raise ApiError(400 if body.get("model") else 503,
                           "Zła nazwa modelu" if body.get("model") else f"Brak modelu dla {name} w konfiguracji")
        if body.get("model") and p["allowed_models"] and model not in p["allowed_models"] and model != p["model"]:
            raise ApiError(403, f"Model {model} nie jest dozwolony w konfiguracji")
        system = cfg["system"]
        if cfg["allow_client_system"] and isinstance(body.get("system"), str) and body["system"].strip():
            system = body["system"].strip()
        system = system[:cfg["max_system_chars"]]
        msgs = normalize_messages(body.get("messages"), cfg["max_history"], cfg["max_message_chars"])
        if not self.rate.allow():
            raise ApiError(429, "Za dużo pytań w ciągu minuty. Odczekaj chwilę.")
        if not self.slots.acquire(timeout=0.5):
            raise ApiError(429, "Asystent odpowiada już na inne pytania. Spróbuj za chwilę.")
        t0 = time.monotonic()
        try:
            text = self.askers[name](p, model, system, msgs, cfg)
        except UpstreamError as e:
            raise upstream_to_api(e, name) from None
        finally:
            self.slots.release()
        if not text:
            raise ApiError(502, "Model zwrócił pustą odpowiedź")
        return {"text": text, "provider": name, "model": model, "ms": int((time.monotonic() - t0) * 1000)}


def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        server_version = f"shark-assistantd/{VERSION}"
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):  # treści rozmów nie trafiają do dziennika
            if os.environ.get("SHARK_ASSISTANTD_DEBUG"):
                sys.stderr.write("shark-assistantd: " + (fmt % args) + "\n")

        def _origin_ok(self) -> tuple[bool, str | None]:
            origin = self.headers.get("Origin")
            return (origin is None or origin in app.origins), origin

        def _send(self, status: int, payload: dict | None, extra: dict | None = None):
            body = b"" if payload is None else json.dumps(payload, ensure_ascii=False).encode()
            self.send_response(status)
            ok, origin = self._origin_ok()
            if origin is not None and ok:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if payload is not None:
                self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if body and self.command != "HEAD":
                self.wfile.write(body)

        def _guard(self) -> bool:
            host = (self.headers.get("Host") or "").lower()
            if host not in app.allowed_hosts(self.server.server_address[1]):
                self._send(403, {"error": "Niedozwolony nagłówek Host (ochrona przed DNS rebinding)"})
                return False
            if not self._origin_ok()[0]:
                self._send(403, {"error": "Niedozwolone pochodzenie (Origin)"})
                return False
            return True

        def do_OPTIONS(self):
            if not self._guard():
                return
            self._send(204, None, {"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                                   "Access-Control-Allow-Headers": "Content-Type",
                                   "Access-Control-Allow-Private-Network": "true",
                                   "Access-Control-Max-Age": "600"})

        def do_GET(self):
            if not self._guard():
                return
            if urlparse(self.path).path.rstrip("/") != "/v1/health":
                return self._send(404, {"error": "Nie ma takiego adresu"})
            self._send(200, app.health())

        def do_POST(self):
            if not self._guard():
                return
            if urlparse(self.path).path.rstrip("/") != "/v1/ask":
                return self._send(404, {"error": "Nie ma takiego adresu"})
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                return self._send(400, {"error": "Zły Content-Length"})
            if length > MAX_BODY:
                return self._send(413, {"error": "Za długie zapytanie"})
            try:
                body = json.loads(self.rfile.read(length) or b"{}")
                if not isinstance(body, dict):
                    raise ValueError
            except ValueError:
                return self._send(400, {"error": "Treść musi być obiektem JSON"})
            try:
                self._send(200, app.ask(body))
            except ApiError as e:
                self._send(e.status, {"error": redact(e.message, app.cfg)})
            except Exception as e:  # jeden błąd nie wysypuje usługi
                self._send(500, {"error": redact(f"Błąd wewnętrzny: {type(e).__name__}: {e}", app.cfg)})

    return Handler


# --------------------------------------------------------------------------- start

EXAMPLE_CONFIG = """\
# Konfiguracja shark-assistantd — klucze API asystenta SharkOS.
# Plik musi mieć prawa 0600 (root:root). Edycja: sudoedit /etc/sharkos/assistant.toml
# Po zmianie: sudo systemctl restart shark-assistantd
# Nazwy modeli zmieniają się z czasem — sprawdź aktualne w dokumentacji dostawcy.

[general]
# default_provider = "claude"   # gdy nakładka nie poda dostawcy
timeout = 25                    # sekundy na jedną odpowiedź
max_history = 10                # ile ostatnich wiadomości trafia do modelu
max_tokens = 1024               # maksymalna długość odpowiedzi
rate_per_minute = 20            # limit pytań na minutę (ochrona rachunku)
# system = "Jesteś rekinem-asystentem systemu SharkOS. Odpowiadaj krótko, po polsku."
# allow_client_system = true    # false = nakładka nie może podmienić polecenia systemowego

[claude]
api_key = ""                    # klucz z console.anthropic.com
model = ""                      # np. nazwa modelu z dokumentacji Anthropic
# allowed_models = []           # modele, które nakładka może wybrać sama

[openai]
api_key = ""                    # klucz z platform.openai.com
model = ""                      # np. nazwa modelu z dokumentacji OpenAI
"""


def init_config(path: Path) -> int:
    if path.exists():
        print(f"shark-assistantd: {path} już istnieje — nie nadpisuję", file=sys.stderr)
        return 1
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(EXAMPLE_CONFIG)
    os.chmod(path, 0o600)
    print(f"shark-assistantd: utworzono {path} (0600). Wpisz klucz i model, potem zrestartuj usługę.")
    return 0


def serve(host: str, port: int, cfg: dict, origins) -> None:
    if host not in LOOPBACK:
        raise SystemExit(f"shark-assistantd: odmawiam nasłuchu na {host} — dozwolona jest tylko pętla zwrotna (127.0.0.1, ::1)")
    app = App(cfg, origins=origins, port=port)

    class Server(ThreadingHTTPServer):
        allow_reuse_address = True
        daemon_threads = True
        address_family = socket.AF_INET6 if ":" in host else socket.AF_INET

    httpd = Server((host, port), make_handler(app))
    ready = [n for n, p in app.health()["providers"].items() if p["configured"]]
    print(f"shark-assistantd {VERSION}: nasłuch na {host}:{httpd.server_address[1]}, konfiguracja {cfg['path']}"
          f"{' (brak pliku)' if cfg.get('missing') else ''}, gotowi dostawcy: {', '.join(ready) or 'brak'}", flush=True)

    def stop(*_):
        threading.Thread(target=httpd.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="shark-assistantd", description="Asystent AI dla nakładki SharkOS (tylko 127.0.0.1)")
    ap.add_argument("--config", type=Path, default=None,
                    help=f"plik konfiguracji (domyślnie $CREDENTIALS_DIRECTORY/{CREDENTIAL_NAME} albo {DEFAULT_CONFIG})")
    sub = ap.add_subparsers(dest="cmd")
    s = sub.add_parser("serve", help="uruchom usługę (domyślnie)")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=DEFAULT_PORT)
    s.add_argument("--allow-origin", action="append", default=None,
                   help="dodatkowe dozwolone Origin (domyślnie: null i file://)")
    sub.add_parser("check-config", help="sprawdź konfigurację (bez wypisywania kluczy)")
    sub.add_parser("init-config", help="utwórz pusty plik konfiguracji z prawami 0600")
    a = ap.parse_args(argv)
    cmd = a.cmd or "serve"
    path = find_config(a.config)
    if cmd == "init-config":
        return init_config(path)
    try:
        cfg = load_config(path)
    except (ConfigError, OSError) as e:
        print(f"shark-assistantd: {e}", file=sys.stderr)
        return 2
    if cmd == "check-config":
        h = App(cfg).health()
        print(f"Konfiguracja: {cfg['path']} ({h['config']})")
        for n, p in h["providers"].items():
            state = "gotowy" if p["configured"] else ("wyłączony" if not p["enabled"] else
                                                      "brak klucza" if not p["has_key"] else "brak modelu")
            print(f"  {n}: {state}" + (f", model {p['model']}" if p["model"] else ""))
        return 0
    origins = list(DEFAULT_ORIGINS) + (getattr(a, "allow_origin", None) or [])
    serve(getattr(a, "host", "127.0.0.1"), getattr(a, "port", DEFAULT_PORT), cfg, origins)
    return 0


if __name__ == "__main__":
    sys.exit(main())
