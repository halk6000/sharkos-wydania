#!/usr/bin/python3
"""Strażnik agenta SharkOS — ocenia polecenia i zapisy plików, zanim agent je wykona.

Działa jako hook PreToolUse Claude Code (JSON na stdin, decyzja na stdout) i jako moduł
importowany przez shark-agentd (ocena poleceń Codexa po fakcie, testy).

Zasada: zwykła praca (polecenia, testy, edycja plików w katalogu domowym) przechodzi bez pytania.
Zgody użytkownika wymagają tylko rzeczy niebezpieczne albo nieodwracalne:
dyski i partycje, rozruch i firmware, bezpieczeństwo i konta, masowe usuwanie, wyłączanie
komputera, kod z internetu prosto do powłoki, wysyłanie na zewnątrz (git push, publikacja),
odczyt sekretów (tokeny logowania, klucze SSH).

Ograniczenie (świadome): agent działa z uprawnieniami tego samego konta, więc strażnik chroni
przed pomyłką, a nie przed celowym obejściem. Twardą granicą są: brak hasła sudo w sesji agenta
i migawka systemu przed sesją (sharkos-migawka).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path

ZNACZNIK = "sharkos-zgoda"

# (wyrażenie, powód) — dopasowanie do całego polecenia powłoki (po złożeniu wierszy)
_REGULY_POLECEN: list[tuple[str, str]] = [
    # kod z internetu prosto do powłoki (przed „sudo”: curl … | sudo sh to przede wszystkim to)
    (r"\b(curl|wget)\b[^|;]*\|\s*(sudo\s+)?(ba|z|da|k)?sh\b|\b(curl|wget)\b[^|;]*\|\s*(sudo\s+)?python3?\b|\bbash\s+<\(\s*(curl|wget)",
     "uruchomienie skryptu pobranego z internetu"),
    # dyski i partycje
    (r"\bdd\b[^|;&]*\bof=/dev/", "zapis bezpośrednio na urządzenie dyskowe (dd)"),
    (r"\b(mkfs(\.\w+)?|mke2fs|mkswap|wipefs|blkdiscard|sgdisk|gdisk|sfdisk|fdisk|cfdisk|parted|partprobe|cryptsetup|mdadm|pvcreate|vgcreate|lvremove|vgremove|pvremove)\b",
     "zmiana dysków lub partycji"),
    (r">\s*/dev/(sd|nvme|vd|hd|mmcblk|disk)", "zapis bezpośrednio na urządzenie dyskowe"),
    (r"\bbtrfs\s+(subvolume\s+(delete|set-default)|device\s+(remove|delete)|balance|filesystem\s+resize|check\s+--repair|rescue)\b",
     "zmiana układu btrfs"),
    (r"\bsharkos-migawka\s+(usun|przywroc)\b", "usuwanie lub przywracanie migawek systemu"),
    # rozruch i firmware
    (r"\b(grub-install|efibootmgr|bootctl|update-grub|grub-mkconfig|grub-reboot|grub-set-default|fwupdmgr|flashrom|mokutil)\b",
     "zmiana rozruchu lub firmware"),
    # wyłączanie komputera i interfejsu
    (r"\b(shutdown|poweroff|reboot|halt)\b|\bsystemctl\s+(reboot|poweroff|halt|suspend|hibernate|kexec|rescue|emergency|isolate)\b|\binit\s+[06]\b",
     "wyłączenie lub restart komputera"),
    (r"\b(pkill|killall)\b[^|;&]*\b(cage|chromium|systemd|shark-agentd|shark-sysd)\b|\bkill\s+(-\S+\s+)*1\b",
     "zamknięcie interfejsu albo procesów systemu"),
    # bezpieczeństwo i konta
    (r"\bsudo\b|\bpkexec\b|\bsu\s+(-|root\b)|\bdoas\b", "polecenie z uprawnieniami administratora"),
    (r"\b(passwd|chpasswd|usermod|userdel|useradd|groupmod|gpasswd|visudo|chage)\b", "zmiana kont lub haseł"),
    (r"\b(ufw\s+(disable|reset)|iptables\s+-F|nft\s+flush|setenforce\s+0|aa-disable|aa-teardown)\b", "wyłączanie zabezpieczeń"),
    (r"\bsystemctl\s+(--user\s+)?(stop|disable|mask)\s+\S*(shark|apparmor|ufw|nftables|ssh)", "wyłączanie usług systemu"),
    (r"\bchmod\b[^|;&]*\b(-R\s+)?(777|a\+w|o\+w)\b", "nadanie wszystkim prawa zapisu"),
    (r"\b(chmod|chown|chattr)\b[^|;&]*\s/(etc|boot|usr|bin|sbin|lib)\b", "zmiana praw plików systemu"),
    # masowe usuwanie
    (r"\brm\s+(-\w*\s+)*-\w*[rR]\w*\s+(-\S+\s+)*(/|~|\$HOME|\$\{HOME\}|/home|/home/\w+|/etc|/usr|/boot|/var|/opt|\.\.|\*|~/\*|\.)(/)?(\s|$|;|&|\|)",
     "rekursywne usuwanie dużego katalogu"),
    (r"\bfind\s+(/|~|\$HOME)\s[^|;&]*-delete\b", "masowe usuwanie (find -delete)"),
    (r"\bshred\b|\btruncate\s+-s\s*0\s+/", "nieodwracalne niszczenie plików"),
    (r"\bgit\s+(clean\s+(-\w+\s+)*-\w*f|reset\s+--hard|filter-branch|filter-repo|stash\s+(drop|clear))\b",
     "nieodwracalna utrata zmian w repozytorium git"),
    # wysyłanie na zewnątrz w imieniu użytkownika
    (r"\bgit\s+push\b", "wysłanie zmian do zdalnego repozytorium (git push)"),
    (r"\bgh\s+(pr\s+(merge|create|close)|release\s+(create|delete|upload)|repo\s+(delete|create|edit)|secret|api\s+-X\s*(POST|PUT|PATCH|DELETE))\b",
     "zmiana na GitHubie"),
    (r"\b(npm|pnpm|yarn)\s+publish\b|\btwine\s+upload\b|\bcargo\s+publish\b|\bdocker\s+push\b", "publikacja pakietu"),
    (r"\b(mail|sendmail|mutt|msmtp)\b", "wysłanie wiadomości e-mail"),
    # sekrety
    (r"(\.claude/\.credentials\.json|\.codex/auth\.json|\.ssh/id_\w+(?!\.pub)\b|/etc/shadow|\.gnupg/private|\.netrc|\.git-credentials)",
     "dostęp do sekretów (tokeny logowania, klucze)"),
    # samo zabezpieczenie
    (r"(shark-agentd|straznik\.py|agent-zgody|\.config/sharkos/agent)", "zmiana zabezpieczeń agenta"),
]
REGULY_POLECEN = [(re.compile(w, re.I), p) for w, p in _REGULY_POLECEN]

# ścieżki, których zapis (narzędzia Write/Edit) wymaga zgody
_CHRONIONE = [
    (r"^/(etc|boot|usr|bin|sbin|lib|lib64|var/lib|opt|root|srv|sys|proc|dev)(/|$)", "zapis do plików systemu"),
    (r"/\.ssh(/|$)", "zmiana kluczy SSH"),
    (r"/\.gnupg(/|$)", "zmiana kluczy GPG"),
    (r"/\.claude/\.credentials\.json$|/\.codex/auth\.json$", "zmiana tokenów logowania"),
    (r"/\.config/sharkos/agent|/\.claude/settings(\.local)?\.json$|/\.codex/config\.toml$|/agent-zgody/",
     "zmiana zabezpieczeń agenta"),
    (r"/\.config/systemd/user/|/\.config/autostart/|/\.(bash_profile|profile|bashrc|zshrc)$", "zmiana programów startujących z sesją"),
]
CHRONIONE = [(re.compile(w), p) for w, p in _CHRONIONE]

NARZEDZIA_ZAPISU = {"Write", "Edit", "MultiEdit", "NotebookEdit"}
NARZEDZIA_POLECEN = {"Bash"}


def ocen_polecenie(polecenie: str) -> str | None:
    """Zwraca powód, gdy polecenie wymaga zgody; None = można wykonać."""
    tekst = re.sub(r"\\\n", " ", polecenie or "")
    for wzor, powod in REGULY_POLECEN:
        if wzor.search(tekst):
            return powod
    return None


def ocen_sciezke(sciezka: str, dom: str | None = None) -> str | None:
    if not sciezka:
        return None
    dom = dom or os.path.expanduser("~")
    p = os.path.normpath(os.path.expanduser(sciezka))
    if not os.path.isabs(p):
        return None   # względna = w katalogu roboczym agenta
    for wzor, powod in CHRONIONE:
        if wzor.search(p):
            return powod
    if not (p == dom or p.startswith(dom.rstrip("/") + "/") or p.startswith("/tmp/") or p.startswith("/var/tmp/")):
        return "zapis poza katalogiem domowym"
    return None


def ocen(narzedzie: str, dane: dict) -> str | None:
    if narzedzie in NARZEDZIA_POLECEN:
        return ocen_polecenie(str(dane.get("command", "")))
    if narzedzie in NARZEDZIA_ZAPISU:
        return ocen_sciezke(str(dane.get("file_path") or dane.get("notebook_path") or ""))
    return None


def opis(narzedzie: str, dane: dict) -> str:
    if narzedzie in NARZEDZIA_POLECEN:
        return str(dane.get("command", ""))
    if narzedzie in NARZEDZIA_ZAPISU:
        return f"{narzedzie} {dane.get('file_path') or dane.get('notebook_path') or ''}"
    return f"{narzedzie} {json.dumps(dane, ensure_ascii=False)[:200]}"


def identyfikator(narzedzie: str, dane: dict) -> str:
    kanon = json.dumps({"t": narzedzie, "d": dane}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(kanon.encode()).hexdigest()[:16]


def katalog_zgod() -> Path | None:
    d = os.environ.get("SHARK_AGENT_ZGODY")
    return Path(d) if d else None


def zuzyj_zgode(katalog: Path, ident: str) -> bool:
    """Jednorazowa zgoda: plik <id>.ok (ważny 10 min) zostaje usunięty przy użyciu."""
    ok = katalog / f"{ident}.ok"
    try:
        wiek = time.time() - ok.stat().st_mtime
        ok.unlink()
    except OSError:
        return False
    return wiek < 600


def decyzja(wejscie: dict, katalog: Path | None) -> dict | None:
    """Decyzja hooka PreToolUse; None = brak zdania (zwykłe uprawnienia Claude Code)."""
    narzedzie = str(wejscie.get("tool_name", ""))
    dane = wejscie.get("tool_input") or {}
    if not isinstance(dane, dict):
        dane = {}
    powod = ocen(narzedzie, dane)
    if powod is None:
        return None
    ident = identyfikator(narzedzie, dane)
    if katalog and zuzyj_zgode(katalog, ident):
        return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "allow",
                                       "permissionDecisionReason": f"SharkOS: użytkownik pozwolił ({powod})"}}
    if katalog:
        try:
            katalog.mkdir(parents=True, exist_ok=True, mode=0o700)
            (katalog / f"{ident}.json").write_text(json.dumps(
                {"id": ident, "narzedzie": narzedzie, "dane": dane, "opis": opis(narzedzie, dane),
                 "powod": powod, "czas": time.time()}, ensure_ascii=False))
        except OSError:
            pass
    return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny",
            "permissionDecisionReason": (
                f"SharkOS: to wymaga zgody użytkownika — {powod}. [{ZNACZNIK}:{ident}] "
                "Nie próbuj obejść blokady innym poleceniem. Napisz krótko, po co to jest, i zakończ turę: "
                "użytkownik zobaczy przycisk „Pozwól raz”, a po zgodzie dostaniesz wiadomość, że możesz powtórzyć "
                "dokładnie to samo polecenie.")}}


def main() -> int:
    try:
        wejscie = json.load(sys.stdin)
    except (ValueError, OSError):
        return 0     # bez danych nie blokujemy (Claude Code użyje swoich zasad)
    d = decyzja(wejscie if isinstance(wejscie, dict) else {}, katalog_zgod())
    if d is not None:
        json.dump(d, sys.stdout, ensure_ascii=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
