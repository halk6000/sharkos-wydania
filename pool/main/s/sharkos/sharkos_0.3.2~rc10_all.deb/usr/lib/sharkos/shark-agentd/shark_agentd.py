#!/usr/bin/python3
"""shark-agentd — okno agenta SharkOS (Home + Enter) rozmawia przez tę usługę z Claude Code i Codex CLI.

Usługa użytkownika (systemctl --user), nasłuch wyłącznie na 127.0.0.1:7379. Uruchamia prawdziwe
programy dostawców na koncie zalogowanej osoby:
  * Claude Code:  claude -p … --output-format stream-json  (logowanie: konto Claude użytkownika)
  * Codex CLI:    codex exec --json …                       (logowanie: konto ChatGPT użytkownika)
i zamienia ich zdarzenia na jeden prosty format dla nakładki: tekst, rozmyślanie, polecenie
i jego wynik, zmiana pliku, prośba o zgodę, koniec.

Hasła ani tokeny nie przechodzą przez usługę: logowanie robią same programy dostawców
(strona logowania / kod urządzenia — można potwierdzić na telefonie).

Bezpieczeństwo:
  * token sesji (X-Shark-Token) wymagany dla wszystkiego poza /v1/health; plik 0600
    w $XDG_RUNTIME_DIR/shark-agentd/token — czyta go sharkos-kiosk-session,
  * Host musi być pętlą zwrotną (DNS rebinding), Origin: null / file:// (nakładka z pliku),
  * Claude Code działa z hookiem straznik.py (niebezpieczne polecenia czekają na „Pozwól raz”),
  * Codex działa w piaskownicy workspace-write (zapis tylko w katalogu roboczym i /tmp),
  * przed nową rozmową — migawka systemu (sudo -n sharkos-migawka utworz agent, reguła sudoers
    z pakietu pozwala wyłącznie na to jedno polecenie).
"""
from __future__ import annotations

import argparse
import codecs
import hmac
import json
import os
import pty
import re
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    tomllib = None

sys.path.insert(0, str(Path(__file__).resolve().parent))
import straznik  # noqa: E402

VERSION = "0.1.0"
DEFAULT_PORT = 7379
LOOPBACK = {"127.0.0.1", "::1"}
DEFAULT_ORIGINS = ("null", "file://")
MAX_BODY = 256 * 1024
MAX_PROMPT = 100_000
MAX_OUT = 8000
MAX_EVENTS = 4000
MAX_RUNS = 30
STRAZNIK = Path(__file__).resolve().parent / "straznik.py"

SYSTEM_PROMPT = (
    "Pracujesz w systemie SharkOS (Debian 13) na komputerze użytkownika, w oknie agenta SharkOS. "
    "Odpowiadaj po polsku, krótko i konkretnie. Możesz uruchamiać polecenia, testy i edytować pliki w katalogu domowym. "
    "Rzeczy niebezpieczne (dyski, rozruch, konta, sudo, masowe usuwanie, git push, sekrety) blokuje strażnik SharkOS: "
    "gdy polecenie zostanie zablokowane, wyjaśnij po co jest i zakończ turę — użytkownik zdecyduje przyciskiem. "
    "Nie próbuj obchodzić blokady. Sesja agenta nie zna hasła sudo."
)
# bąbelek rekina na pulpicie: ta sama subskrypcja, ale tylko rozmowa (bez poleceń i zapisu plików)
SYSTEM_REKIN = (
    "Jesteś rekinem — asystentem w dymku na pulpicie systemu SharkOS (Debian 13). Odpowiadaj po polsku, "
    "krótko (1–4 zdania), przyjaźnie. Nie uruchamiasz poleceń i nie zmieniasz plików. Gdy trzeba coś zrobić "
    "na komputerze, podaj polecenie do terminala SharkOS albo odeślij do okna agenta (Home + Enter)."
)
REKIN_ZAKAZANE = ["Bash", "Write", "Edit", "MultiEdit", "NotebookEdit", "Task"]
BROWZI_URL = "https://browzi-codex.akinoxpl.workers.dev/mcp"

DOMYSLNE = {
    "general": {"workdir": "~", "snapshot": True, "snapshot_every_min": 30, "max_parallel": 2},
    "claude": {
        "name": "Claude", "command": "claude",
        "models": ["claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5", "claude-fable-5-1"],
        "default_model": "claude-sonnet-5-5",
        "login": ["auth", "login"], "status": ["auth", "status"],
        "install": "curl -fsSL https://claude.ai/install.sh | bash",
    },
    "openai": {
        "name": "OpenAI", "command": "codex",
        "models": ["gpt-6.1-sol"],
        "default_model": "",
        "login": ["login", "--device-auth"], "status": ["login", "status"],
        "install": (
            'set -e; d=$(mktemp -d); trap \'rm -rf "$d"\' EXIT; '
            "curl -fL --progress-bar -o \"$d/codex.tgz\" "
            "https://github.com/openai/codex/releases/latest/download/codex-x86_64-unknown-linux-musl.tar.gz; "
            'tar -xzf "$d/codex.tgz" -C "$d"; '
            # w archiwum jest jeden plik wykonywalny (dziś: codex-x86_64-unknown-linux-musl)
            'b=$(find "$d" -type f -name "codex*" ! -name codex.tgz | head -n 1); [ -n "$b" ]; '
            'install -Dm755 "$b" "$HOME/.local/bin/codex"; '
            '"$HOME/.local/bin/codex" --version'
        ),
    },
}
PROVIDERS = ("claude", "openai")
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(\x07|\x1b\\)|\x1b[@-Z\\-_]")
URL = re.compile(r"https://[^\s\"'<>\x1b]+")
ZNACZNIK_CWD = re.compile(r"\x1e([^\x1e\n]*)\x1e")   # katalog bieżący powłoki terminala (na końcu polecenia)


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def przytnij(tekst, n: int = MAX_OUT) -> str:
    s = tekst if isinstance(tekst, str) else json.dumps(tekst, ensure_ascii=False)
    return s if len(s) <= n else s[: n // 2] + f"\n… (pominięto {len(s) - n} znaków) …\n" + s[-n // 2:]


# --------------------------------------------------------------------------- konfiguracja

def wczytaj_konfig(sciezka: Path | None) -> dict:
    cfg = json.loads(json.dumps(DOMYSLNE))
    if sciezka and sciezka.is_file() and tomllib is not None:
        try:
            dane = tomllib.loads(sciezka.read_text())
        except (OSError, ValueError) as e:
            print(f"shark-agentd: zły plik {sciezka}: {e} — używam ustawień domyślnych", file=sys.stderr)
            dane = {}
        for sekcja, wartosci in dane.items():
            if sekcja in cfg and isinstance(wartosci, dict):
                cfg[sekcja].update(wartosci)
    return cfg


def domyslny_konfig() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return Path(base) / "sharkos" / "agent.toml"


def sciezka_wyszukiwania() -> str:
    dom = os.path.expanduser("~")
    extra = [f"{dom}/.local/bin", f"{dom}/.claude/local", f"{dom}/.npm-global/bin", "/usr/local/bin", "/usr/bin", "/bin"]
    czesci = [p for p in os.environ.get("PATH", "").split(":") if p]
    return ":".join(dict.fromkeys(czesci + extra))


# --------------------------------------------------------------------------- zdarzenia dostawców

def _tekst_wyniku(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(str(c.get("text", "")) for c in content if isinstance(c, dict) and c.get("type") == "text")
    return "" if content is None else json.dumps(content, ensure_ascii=False)


def _skrot_narzedzia(nazwa: str, dane: dict) -> str:
    if not isinstance(dane, dict):
        return ""
    for k in ("command", "file_path", "notebook_path", "pattern", "url", "query", "description", "path"):
        if dane.get(k):
            return str(dane[k])
    return json.dumps(dane, ensure_ascii=False)[:300]


def zdarzenia_claude(obj: dict) -> list[dict]:
    """Jedna linia `claude -p --output-format stream-json --verbose` → zdarzenia nakładki."""
    t = obj.get("type")
    out: list[dict] = []
    if t == "system" and obj.get("subtype") == "init":
        out.append({"kind": "start", "session_id": obj.get("session_id"), "model": obj.get("model"),
                    "cwd": obj.get("cwd")})
    elif t == "assistant":
        for b in (obj.get("message") or {}).get("content") or []:
            if not isinstance(b, dict):
                continue
            bt = b.get("type")
            if bt == "text" and b.get("text"):
                out.append({"kind": "text", "text": b["text"]})
            elif bt == "thinking" and b.get("thinking"):
                out.append({"kind": "thinking", "text": b["thinking"]})
            elif bt == "tool_use":
                nazwa, dane = b.get("name", "?"), b.get("input") or {}
                ev = {"kind": "tool", "id": b.get("id"), "name": nazwa, "summary": przytnij(_skrot_narzedzia(nazwa, dane), 2000)}
                if nazwa in straznik.NARZEDZIA_ZAPISU:
                    ev["file"] = dane.get("file_path") or dane.get("notebook_path")
                out.append(ev)
    elif t == "user":
        for b in (obj.get("message") or {}).get("content") or []:
            if isinstance(b, dict) and b.get("type") == "tool_result":
                tekst = _tekst_wyniku(b.get("content"))
                out.append({"kind": "tool_result", "id": b.get("tool_use_id"), "output": przytnij(tekst),
                            "error": bool(b.get("is_error"))})
                m = re.search(rf"\[{straznik.ZNACZNIK}:([0-9a-f]{{16}})\]", tekst)
                if m:
                    out.append({"kind": "approval_needed", "id": m.group(1)})
    elif t == "result":
        out.append({"kind": "done", "session_id": obj.get("session_id"), "error": bool(obj.get("is_error")),
                    "text": przytnij(obj.get("result") or "", 2000) if obj.get("is_error") else "",
                    "cost_usd": obj.get("total_cost_usd"), "turns": obj.get("num_turns"),
                    "ms": obj.get("duration_ms")})
    return out


def zdarzenia_codex(obj: dict) -> list[dict]:
    """Jedna linia `codex exec --json` → zdarzenia nakładki."""
    t = obj.get("type", "")
    out: list[dict] = []
    if t == "thread.started":
        out.append({"kind": "start", "session_id": obj.get("thread_id")})
    elif t.startswith("item."):
        it = obj.get("item") or {}
        typ, ident = it.get("type"), it.get("id")
        if typ == "command_execution":
            if t == "item.started":
                out.append({"kind": "tool", "id": ident, "name": "Polecenie", "summary": przytnij(it.get("command", ""), 2000)})
            elif t == "item.completed":
                kod = it.get("exit_code")
                out.append({"kind": "tool_result", "id": ident, "output": przytnij(it.get("aggregated_output", "")),
                            "exit_code": kod, "error": kod not in (0, None) or it.get("status") == "failed"})
                powod = straznik.ocen_polecenie(it.get("command", ""))
                if powod:
                    out.append({"kind": "warning", "text": f"Codex wykonał polecenie, które w SharkOS wymaga zgody ({powod}). "
                                                           "Piaskownica ogranicza je do katalogu roboczego."})
        elif t != "item.completed":
            pass
        elif typ == "agent_message" and it.get("text"):
            out.append({"kind": "text", "text": it["text"]})
        elif typ == "reasoning" and it.get("text"):
            out.append({"kind": "thinking", "text": it["text"]})
        elif typ == "file_change":
            for z in it.get("changes") or []:
                out.append({"kind": "file", "path": z.get("path"), "change": z.get("kind")})
        elif typ == "mcp_tool_call":
            out.append({"kind": "tool", "id": ident, "name": f"{it.get('server', '')}.{it.get('tool', '')}", "summary": ""})
        elif typ == "web_search":
            out.append({"kind": "tool", "id": ident, "name": "Szukanie w sieci", "summary": it.get("query", "")})
        elif typ == "todo_list":
            out.append({"kind": "plan", "items": [{"text": x.get("text", ""), "done": bool(x.get("completed"))}
                                                   for x in it.get("items") or []]})
        elif typ == "error":
            out.append({"kind": "error", "text": it.get("message", "błąd")})
    elif t == "turn.completed":
        out.append({"kind": "done", "error": False, "usage": obj.get("usage")})
    elif t == "turn.failed":
        out.append({"kind": "done", "error": True, "text": ((obj.get("error") or {}).get("message") or "Codex przerwał turę")})
    elif t == "error":
        out.append({"kind": "error", "text": obj.get("message", "błąd Codexa")})
    return out


PARSERY = {"claude": zdarzenia_claude, "openai": zdarzenia_codex}


# --------------------------------------------------------------------------- przebiegi

class Run:
    def __init__(self, kind: str, provider: str):
        self.id = uuid.uuid4().hex[:12]
        self.kind = kind            # agent | login | install
        self.provider = provider
        self.events: list[dict] = []
        self.state = "running"
        self.session_id: str | None = None
        self.rc: int | None = None
        self.proc: subprocess.Popen | None = None
        self.master: int | None = None
        self.lock = threading.Lock()
        self.started = time.time()
        self.dropped = 0

    def add(self, ev: dict) -> None:
        with self.lock:
            ev = dict(ev, n=len(self.events) + self.dropped, t=round(time.time() - self.started, 2))
            if ev.get("kind") in ("start", "done") and ev.get("session_id"):
                self.session_id = ev["session_id"]
            self.events.append(ev)
            if len(self.events) > MAX_EVENTS:
                self.events.pop(0)
                self.dropped += 1

    def view(self, after: int) -> dict:
        with self.lock:
            evs = [e for e in self.events if e["n"] >= after]
            return {"id": self.id, "kind": self.kind, "provider": self.provider, "state": self.state,
                    "session_id": self.session_id, "rc": self.rc, "events": evs,
                    "next": (self.events[-1]["n"] + 1) if self.events else after}


class Agent:
    def __init__(self, cfg: dict, runtime: Path, popen=subprocess.Popen):
        self.cfg = cfg
        self.runtime = runtime
        self.zgody = runtime / "agent-zgody"
        self.popen = popen
        self.runs: dict[str, Run] = {}
        self.lock = threading.Lock()
        self._status: tuple[float, dict] | None = None
        self.last_snapshot = 0.0
        self.settings_file = runtime / "claude-settings.json"
        self.powloki: dict[str, dict] = {}      # sesje terminala nakładki: katalog bieżący, zgody na zadanie

    # -- pomocnicze
    def binary(self, provider: str) -> str | None:
        cmd = str(self.cfg[provider].get("command") or "")
        if not cmd:
            return None
        if os.path.isabs(cmd):
            return cmd if os.access(cmd, os.X_OK) else None
        return shutil.which(cmd, path=sciezka_wyszukiwania())

    def env(self) -> dict:
        e = dict(os.environ)
        e.update({"PATH": sciezka_wyszukiwania(), "SHARK_AGENT_ZGODY": str(self.zgody), "NO_COLOR": "1",
                  "TERM": "dumb", "CI": "1"})
        return e

    def workdir(self, cwd: str | None) -> str:
        d = os.path.expanduser(cwd or str(self.cfg["general"].get("workdir") or "~"))
        if not os.path.isdir(d):
            raise ApiError(400, f"Nie ma katalogu {d}")
        return d

    def _register(self, run: Run) -> Run:
        with self.lock:
            self.runs[run.id] = run
            while len(self.runs) > MAX_RUNS:
                stary = next((k for k, r in self.runs.items() if r.state != "running"), None)
                if stary is None:
                    break
                del self.runs[stary]
        return run

    def get(self, run_id: str) -> Run:
        r = self.runs.get(run_id)
        if r is None:
            raise ApiError(404, "Nie ma takiego przebiegu")
        return r

    def _wyzwol(self, provider: str, args: list[str], timeout: float = 6.0) -> tuple[int | None, str]:
        b = self.binary(provider)
        if not b:
            return None, ""
        try:
            r = subprocess.run([b, *args], capture_output=True, text=True, timeout=timeout, env=self.env(),
                               stdin=subprocess.DEVNULL)
            return r.returncode, (r.stdout + r.stderr).strip()
        except (OSError, subprocess.TimeoutExpired) as e:
            return None, str(e)

    # -- stan dostawców
    def status(self, odswiez: bool = False) -> dict:
        if self._status and not odswiez and time.time() - self._status[0] < 20:
            return self._status[1]
        wynik = {}
        for p in PROVIDERS:
            c = self.cfg[p]
            b = self.binary(p)
            info = {"name": c.get("name", p), "installed": bool(b), "path": b, "models": list(c.get("models") or []),
                    "default_model": c.get("default_model") or "", "logged_in": None, "version": None,
                    "install_command": c.get("install") or ""}
            if b:
                rc, txt = self._wyzwol(p, ["--version"])
                info["version"] = txt.splitlines()[0][:80] if rc == 0 and txt else None
                if c.get("status"):
                    rc, txt = self._wyzwol(p, list(c["status"]))
                    if rc == 0:
                        info["logged_in"] = not re.search(r"not logged in|nie zalogowano|logged out", txt, re.I)
                    elif rc is not None:
                        info["logged_in"] = False if re.search(r"not logged|login|log in|unauth", txt, re.I) else None
            wynik[p] = info
        self._status = (time.time(), wynik)
        return wynik

    # -- migawka systemu przed nową rozmową
    def migawka(self, run: Run) -> None:
        g = self.cfg["general"]
        if not g.get("snapshot", True):
            return
        if time.time() - self.last_snapshot < float(g.get("snapshot_every_min", 30)) * 60:
            return
        prog = "/usr/sbin/sharkos-migawka"
        if not os.path.exists(prog) or not shutil.which("sudo"):
            run.add({"kind": "snapshot", "ok": False, "text": "Migawka systemu niedostępna na tym komputerze"})
            return
        try:
            r = subprocess.run(["sudo", "-n", prog, "utworz", "agent"], capture_output=True, text=True, timeout=90,
                               stdin=subprocess.DEVNULL)
            ok = r.returncode == 0
            tekst = (r.stdout or r.stderr).strip().splitlines()
            run.add({"kind": "snapshot", "ok": ok, "text": (tekst[-1] if tekst else "") or
                     ("Migawka systemu utworzona" if ok else "Migawka systemu nie powstała")})
            if ok:
                self.last_snapshot = time.time()
        except (OSError, subprocess.TimeoutExpired) as e:
            run.add({"kind": "snapshot", "ok": False, "text": f"Migawka systemu nie powstała: {e}"})

    def claude_settings(self) -> str:
        ustawienia = {
            "permissions": {"allow": ["Bash", "Read", "Edit", "Write", "MultiEdit", "Glob", "Grep", "LS", "WebFetch",
                                      "WebSearch", "TodoWrite", "NotebookEdit", "Task", "mcp__browzi"]},
            # strażnik także dla narzędzi Browzi (zmiany na GitHubie; repozytoria SharkOS tylko z rootem)
            "hooks": {"PreToolUse": [{"matcher": "Bash|Write|Edit|MultiEdit|NotebookEdit|mcp__browzi__.*", "hooks": [
                {"type": "command", "command": f"python3 {STRAZNIK}", "timeout": 10}]}]},
        }
        self.runtime.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.settings_file.write_text(json.dumps(ustawienia, ensure_ascii=False, indent=1))
        return str(self.settings_file)

    # -- Browzi: wtyczka MCP użytkownika (bramka Cloudflare, token Bearer w pliku 0600, nigdy w nakładce)
    def browzi_token_plik(self) -> Path:
        return Path(os.path.expanduser(str(self.cfg["general"].get("browzi_token_file") or "~/.config/sharkos/browzi-token")))

    def browzi_mcp(self) -> str | None:
        """Plik --mcp-config dla Claude Code z serwerem Browzi; None, gdy nie ma tokenu."""
        try:
            token = self.browzi_token_plik().read_text().strip()
        except OSError:
            return None
        if not re.fullmatch(r"[\x21-\x7e]{8,512}", token):
            return None
        url = str(self.cfg["general"].get("browzi_url") or BROWZI_URL)
        p = self.runtime / "mcp-browzi.json"
        self.runtime.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump({"mcpServers": {"browzi": {"type": "http", "url": url,
                                                 "headers": {"Authorization": f"Bearer {token}"}}}}, f)
        return str(p)

    def browzi_ustaw(self, token: str) -> dict:
        token = (token or "").strip()
        p = self.browzi_token_plik()
        if not token:
            p.unlink(missing_ok=True)
            return {"ok": True, "browzi": False}
        if not re.fullmatch(r"[\x21-\x7e]{8,512}", token):
            raise ApiError(400, "Token Browzi: 8–512 znaków bez spacji")
        p.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(token + "\n")
        os.chmod(p, 0o600)
        return {"ok": True, "browzi": True}

    def browzi_stan(self) -> dict:
        return {"browzi": self.browzi_token_plik().is_file(), "url": str(self.cfg["general"].get("browzi_url") or BROWZI_URL),
                "root": straznik.root_aktywny()}

    def argv(self, provider: str, prompt: str, model: str, session_id: str | None, cwd: str,
             rekin: bool = False) -> list[str]:
        b = self.binary(provider)
        if not b:
            raise ApiError(503, f"{self.cfg[provider].get('name', provider)}: program nie jest zainstalowany")
        system = SYSTEM_REKIN if rekin else SYSTEM_PROMPT
        if provider == "claude":
            a = [b, "-p", prompt, "--output-format", "stream-json", "--verbose",
                 "--permission-mode", "default" if rekin else "acceptEdits",
                 "--settings", self.claude_settings(), "--append-system-prompt", system]
            if rekin:
                a += ["--disallowedTools", *REKIN_ZAKAZANE, "--max-turns", "4"]
            else:
                mcp = self.browzi_mcp()
                if mcp:
                    a += ["--mcp-config", mcp]
            if model:
                a += ["--model", model]
            if session_id:
                a += ["--resume", session_id]
            return a
        if rekin:   # Codex: piaskownica tylko do odczytu
            a = [b, "exec", "--json", "--skip-git-repo-check", "-C", cwd, "-s", "read-only"]
        else:
            a = [b, "exec", "--json", "--skip-git-repo-check", "-C", cwd, "-s", "workspace-write",
                 "-c", "sandbox_workspace_write.network_access=true"]
        if model:
            a += ["-m", model]
        if session_id:
            return a + ["resume", session_id, prompt]
        return a + [f"[SharkOS] {system}\n\n{prompt}"]

    # -- start przebiegów
    def agent(self, provider: str, prompt: str, model: str = "", session_id: str | None = None,
              cwd: str | None = None, tryb: str = "agent") -> Run:
        """tryb „agent” — okno agenta (polecenia, pliki, migawka); „rekin” — bąbelek: sama rozmowa."""
        if tryb not in ("agent", "rekin"):
            raise ApiError(400, "tryb: agent albo rekin")
        if provider not in PROVIDERS:
            raise ApiError(400, "provider: claude albo openai")
        if not isinstance(prompt, str) or not prompt.strip():
            raise ApiError(400, "Pusta wiadomość")
        if len(prompt) > MAX_PROMPT:
            raise ApiError(413, "Za długa wiadomość")
        if session_id is not None and not re.fullmatch(r"[\w.-]{1,128}", str(session_id)):
            raise ApiError(400, "Zły identyfikator rozmowy")
        if model and not re.fullmatch(r"[\w.:\[\]-]{1,80}", model):
            raise ApiError(400, "Zła nazwa modelu")
        aktywne = sum(1 for r in self.runs.values() if r.kind == tryb and r.state == "running")
        if aktywne >= (1 if tryb == "rekin" else int(self.cfg["general"].get("max_parallel", 2))):
            raise ApiError(429, "Rekin jeszcze odpowiada na poprzednie pytanie" if tryb == "rekin"
                           else "Agent już pracuje — poczekaj albo zatrzymaj poprzednie zadanie")
        d = self.workdir(cwd)
        model = model or str(self.cfg[provider].get("default_model") or "")
        argv = self.argv(provider, prompt, model, session_id, d, rekin=tryb == "rekin")
        run = self._register(Run(tryb, provider))
        run.session_id = session_id

        def praca():
            if not session_id and tryb == "agent":
                self.migawka(run)
            self._uruchom(run, argv, d, PARSERY[provider])
        threading.Thread(target=praca, daemon=True).start()
        return run

    def _uruchom(self, run: Run, argv: list[str], cwd: str, parser) -> None:
        try:
            proc = self.popen(argv, cwd=cwd, env=self.env(), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, start_new_session=True)
        except OSError as e:
            run.add({"kind": "error", "text": f"Nie uruchomiłem programu: {e}"})
            run.state = "error"
            return
        run.proc = proc
        bledy: list[str] = []

        def czytaj_bledy():
            for linia in iter(proc.stderr.readline, b""):
                bledy.append(linia.decode(errors="replace"))
                del bledy[:-40]
        th = threading.Thread(target=czytaj_bledy, daemon=True)
        th.start()
        koniec = False
        for surowa in iter(proc.stdout.readline, b""):
            linia = surowa.decode(errors="replace").strip()
            if not linia:
                continue
            try:
                obj = json.loads(linia)
            except ValueError:
                run.add({"kind": "log", "text": przytnij(ANSI.sub("", linia), 2000)})
                continue
            if not isinstance(obj, dict):
                continue
            for ev in parser(obj):
                if ev["kind"] == "approval_needed":
                    ev = self._prosba(ev["id"])
                if ev["kind"] == "done":
                    koniec = True
                run.add(ev)
        rc = proc.wait()
        th.join(timeout=2)
        run.rc = rc
        if run.state == "stopped":
            run.add({"kind": "done", "error": True, "text": "Zatrzymano"})
            return
        if not koniec:
            run.add({"kind": "done", "error": rc != 0,
                     "text": przytnij(ANSI.sub("", "".join(bledy)).strip(), 3000) if rc != 0 else ""})
        run.state = "done" if rc == 0 else "error"

    def _prosba(self, ident: str) -> dict:
        try:
            d = json.loads((self.zgody / f"{ident}.json").read_text())
        except (OSError, ValueError):
            d = {}
        return {"kind": "approval", "id": ident, "what": przytnij(d.get("opis", ""), 2000), "why": d.get("powod", ""),
                "task": d.get("zadanie", ""), "root": bool(d.get("root"))}

    def pozwol(self, ident: str, provider: str, session_id: str, model: str = "", cwd: str | None = None,
               zakres: str = "raz") -> Run:
        if not re.fullmatch(r"[0-9a-f]{16}", ident or ""):
            raise ApiError(400, "Zły identyfikator zgody")
        if zakres not in ("raz", "zadanie"):
            raise ApiError(400, "zakres: raz albo zadanie")
        p = self.zgody / f"{ident}.json"
        try:
            d = json.loads(p.read_text())
        except (OSError, ValueError):
            raise ApiError(404, "Ta prośba o zgodę już wygasła")
        if d.get("root") and not straznik.root_aktywny():
            # repozytoria SharkOS: przycisk nie wystarcza — najpierw odblokowanie roota
            raise ApiError(403, "Wymaga roota: w terminalu SharkOS wpisz „sudo sharkos-root”, potem kliknij ponownie")
        self.zgody.mkdir(parents=True, exist_ok=True, mode=0o700)
        (self.zgody / f"{ident}.ok").write_text("ok")
        if zakres == "zadanie" and d.get("zadanie"):
            # ten sam rodzaj działania (np. wszystkie „sudo apt”) bez pytania do końca rozmowy, najdłużej 2 h
            straznik.daj_zgode_zadania(self.zgody, d["zadanie"])
        p.unlink(missing_ok=True)
        jak = "na całe zadanie (podobne kroki nie będą już blokowane)" if zakres == "zadanie" else "raz"
        return self.agent(provider, f"Użytkownik pozwolił {jak} na: {d.get('opis', '')}\nPowtórz dokładnie to samo i kontynuuj zadanie.",
                          model, session_id, cwd)

    def koniec_zadania(self) -> dict:
        """Nowa rozmowa: zgody „na zadanie” agenta wygasają."""
        return {"ok": True, "usunieto": straznik.zakoncz_zadanie(self.zgody) if self.zgody.is_dir() else 0}

    # -- terminal nakładki: prawdziwa powłoka; biała lista od razu, reszta po zgodzie (straznik.ocen_terminal)
    def _sesja(self, sesja: str) -> dict:
        if not re.fullmatch(r"[A-Za-z0-9_-]{4,64}", sesja or ""):
            raise ApiError(400, "Zły identyfikator sesji terminala")
        with self.lock:
            teraz = time.time()
            for k in [k for k, v in self.powloki.items() if teraz - v["czas"] > straznik.ZADANIE_WAZNE_S]:
                del self.powloki[k]
            s = self.powloki.setdefault(sesja, {"cwd": os.path.expanduser("~"), "zadania": set(), "czas": teraz})
            return s

    def powloka(self, sesja: str, polecenie: str, zgoda: str = "") -> dict:
        if not isinstance(polecenie, str) or not polecenie.strip() or len(polecenie) > 4000:
            raise ApiError(400, "Puste albo za długie polecenie")
        s = self._sesja(sesja)
        o = straznik.ocen_terminal(polecenie)
        if o["pelny_ekran"]:
            raise ApiError(400, f"„{o['klucz']}” działa na pełnym ekranie — otwórz konsolę Ctrl+Alt+F3 (powrót: Ctrl+Alt+F1)")
        m = re.fullmatch(r"\s*cd(?:\s+(\S+))?\s*", polecenie)
        if m and not o["zgoda"]:
            cel = Path(os.path.expanduser(m.group(1) or "~"))
            cel = (Path(s["cwd"]) / cel).resolve() if not cel.is_absolute() else cel.resolve()
            if not cel.is_dir():
                raise ApiError(404, f"Nie ma katalogu {m.group(1)}")
            s["cwd"] = str(cel)
            return {"cwd": s["cwd"]}
        if straznik.dotyczy_repo_sharkos("Bash", {"command": polecenie}, s["cwd"]):
            if not straznik.root_aktywny():
                return {"zgoda_wymagana": True, "root": True, "powod": straznik.KOMUNIKAT_ROOT, "niebezpieczne": True,
                        "klucz": o["klucz"], "polecenie": polecenie}
            o["zgoda"] = False          # root odblokowany: bez dodatkowego pytania
        if o["zgoda"] and zgoda not in ("raz", "zadanie") and o["klucz"] not in s["zadania"]:
            return {"zgoda_wymagana": True, "powod": o["powod"], "niebezpieczne": o["niebezpieczne"], "klucz": o["klucz"],
                    "polecenie": polecenie}
        if o["zgoda"] and zgoda == "zadanie":
            s["zadania"].add(o["klucz"])
        s["czas"] = time.time()
        run = self._pty(["/bin/bash", "-c", polecenie + "\n__k=$?; printf '\\036%s\\036' \"$PWD\"; exit $__k"],
                        "shell", "", s["cwd"], sesja=s)
        return {"run_id": run.id, "cwd": s["cwd"]}

    def koniec_zadania_powloki(self, sesja: str) -> dict:
        s = self._sesja(sesja)
        n = len(s["zadania"])
        s["zadania"].clear()
        return {"ok": True, "usunieto": n}

    def odmow(self, ident: str) -> dict:
        if not re.fullmatch(r"[0-9a-f]{16}", ident or ""):
            raise ApiError(400, "Zły identyfikator zgody")
        (self.zgody / f"{ident}.json").unlink(missing_ok=True)
        return {"ok": True}

    def terminal(self, kind: str, provider: str) -> Run:
        """Logowanie i instalacja: program w pseudoterminalu, wyjście na żywo, można wpisać kod."""
        if provider not in PROVIDERS:
            raise ApiError(400, "provider: claude albo openai")
        c = self.cfg[provider]
        if kind == "login":
            b = self.binary(provider)
            if not b:
                raise ApiError(503, f"{c.get('name', provider)}: najpierw zainstaluj program")
            argv = [b, *list(c.get("login") or [])]
        else:
            if not c.get("install"):
                raise ApiError(400, "Brak polecenia instalacji w ustawieniach")
            argv = ["/bin/sh", "-c", str(c["install"])]
        return self._pty(argv, kind, provider, os.path.expanduser("~"),
                         naglowek="$ " + " ".join(argv[-1:] if kind == "install" else argv))

    def _pty(self, argv: list[str], kind: str, provider: str, cwd: str, naglowek: str = "",
             sesja: dict | None = None) -> Run:
        """Program w pseudoterminalu: wyjście na żywo (zdarzenia output), wejście przez wpisz().
        Dla powłoki terminala (sesja) znacznik \\036katalog\\036 na końcu ustawia katalog bieżący sesji."""
        run = self._register(Run(kind, provider))
        if naglowek:
            run.add({"kind": "log", "text": naglowek})
        master, slave = pty.openpty()
        env = self.env()
        env["TERM"] = "xterm"
        env.pop("CI", None)
        if sesja is not None:
            env.update({"PAGER": "cat", "GIT_PAGER": "cat", "SYSTEMD_PAGER": "cat", "MANPAGER": "cat",
                        "COLUMNS": "120", "LINES": "40"})
        try:
            proc = self.popen(argv, cwd=cwd, env=env, stdin=slave, stdout=slave, stderr=slave,
                              start_new_session=True)
        except OSError as e:
            os.close(master)
            os.close(slave)
            run.add({"kind": "error", "text": f"Nie uruchomiłem programu: {e}"})
            run.state = "error"
            return run
        os.close(slave)
        run.proc, run.master = proc, master

        def czytaj():
            widziane: set[str] = set()
            bufor = ""
            reszta = ""          # niedokończony znacznik katalogu z poprzedniego kawałka
            dekoder = codecs.getincrementaldecoder("utf-8")(errors="replace")   # „ł” bywa przecięte między odczytami
            while True:
                try:
                    dane = os.read(master, 4096)
                except OSError:
                    break
                if not dane:
                    break
                tekst = ANSI.sub("", reszta + dekoder.decode(dane)).replace("\r\n", "\n").replace("\r", "\n")
                reszta = ""
                if sesja is not None:
                    for k in ZNACZNIK_CWD.findall(tekst):
                        sesja["cwd"] = k
                    tekst = ZNACZNIK_CWD.sub("", tekst)
                    if "\x1e" in tekst:
                        i = tekst.index("\x1e")
                        tekst, reszta = tekst[:i], tekst[i:]
                if not tekst:
                    continue
                bufor = (bufor + tekst)[-4000:]
                run.add({"kind": "output", "text": tekst})
                for u in URL.findall(bufor):
                    u = u.rstrip(".,)")
                    if u not in widziane and len(u) > 12:
                        widziane.add(u)
                        run.add({"kind": "link", "url": u})
            rc = proc.wait()
            run.rc = rc
            try:
                os.close(master)
            except OSError:
                pass
            if run.state != "stopped":
                run.state = "done" if rc == 0 else "error"
            run.add({"kind": "done", "error": rc != 0, "rc": rc, "cwd": sesja["cwd"] if sesja else None,
                     "text": "" if rc == 0 else f"Program zakończył się kodem {rc}"})
            self._status = None
        threading.Thread(target=czytaj, daemon=True).start()
        return run

    def wpisz(self, run_id: str, tekst: str) -> dict:
        run = self.get(run_id)
        if run.master is None or run.state != "running":
            raise ApiError(409, "Ten przebieg nie przyjmuje tekstu")
        if not isinstance(tekst, str) or len(tekst) > 4000:
            raise ApiError(400, "Zły tekst")
        os.write(run.master, (tekst.rstrip("\r\n") + "\r").encode())
        return {"ok": True}

    def przerwij(self, run_id: str) -> dict:
        """Ctrl+C: SIGINT do grupy procesów polecenia."""
        run = self.get(run_id)
        if run.proc and run.proc.poll() is None:
            try:
                os.killpg(run.proc.pid, signal.SIGINT)
            except OSError:
                pass
        return {"ok": True, "state": run.state}

    def zatrzymaj(self, run_id: str) -> dict:
        run = self.get(run_id)
        if run.proc and run.proc.poll() is None:
            run.state = "stopped"
            try:
                os.killpg(run.proc.pid, signal.SIGTERM)
            except OSError:
                pass

            def dobij(p=run.proc):
                time.sleep(4)
                if p.poll() is None:
                    try:
                        os.killpg(p.pid, signal.SIGKILL)
                    except OSError:
                        pass
            threading.Thread(target=dobij, daemon=True).start()
        return {"ok": True, "state": run.state}

    def zamknij(self) -> None:
        for r in list(self.runs.values()):
            if r.proc and r.proc.poll() is None:
                try:
                    os.killpg(r.proc.pid, signal.SIGTERM)
                except OSError:
                    pass


# --------------------------------------------------------------------------- HTTP

class App:
    def __init__(self, agent: Agent, token: str, origins=DEFAULT_ORIGINS):
        self.agent = agent
        self.token = token
        self.origins = set(origins)

    def check_token(self, value: str | None) -> bool:
        return bool(value) and hmac.compare_digest(value.encode(), self.token.encode())


def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        server_version = f"shark-agentd/{VERSION}"
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            if os.environ.get("SHARK_AGENTD_DEBUG"):
                sys.stderr.write("shark-agentd: " + (fmt % args) + "\n")

        def _origin_ok(self):
            origin = self.headers.get("Origin")
            return (origin is None or origin in app.origins), origin

        def _send(self, status: int, payload: dict | None, extra: dict | None = None):
            body = b"" if payload is None else json.dumps(payload, ensure_ascii=False).encode()
            self.send_response(status)
            ok, origin = self._origin_ok()
            if origin is not None and ok:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if payload is not None:
                self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if body:
                self.wfile.write(body)

        def _guard(self, token: bool = True) -> bool:
            port = self.server.server_address[1]
            host = (self.headers.get("Host") or "").lower()
            if host not in {f"127.0.0.1:{port}", f"localhost:{port}", f"[::1]:{port}"}:
                self._send(403, {"error": "Niedozwolony nagłówek Host"})
                return False
            if not self._origin_ok()[0]:
                self._send(403, {"error": "Niedozwolone pochodzenie (Origin)"})
                return False
            if token and not app.check_token(self.headers.get("X-Shark-Token")):
                self._send(401, {"error": "Brak lub zły token sesji agenta"})
                return False
            return True

        def _body(self) -> dict:
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                raise ApiError(400, "Zły Content-Length")
            if n > MAX_BODY:
                raise ApiError(413, "Za duże zapytanie")
            try:
                d = json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                raise ApiError(400, "Treść musi być obiektem JSON")
            if not isinstance(d, dict):
                raise ApiError(400, "Treść musi być obiektem JSON")
            return d

        def _run(self, fn):
            try:
                self._send(200, fn())
            except ApiError as e:
                self._send(e.status, {"error": e.message})
            except Exception as e:  # jeden błąd nie wywraca usługi
                self._send(500, {"error": f"Błąd wewnętrzny: {type(e).__name__}: {e}"})

        def do_OPTIONS(self):
            if not self._guard(token=False):
                return
            self._send(204, None, {"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                                   "Access-Control-Allow-Headers": "Content-Type, X-Shark-Token",
                                   "Access-Control-Allow-Private-Network": "true",
                                   "Access-Control-Max-Age": "600"})

        def do_GET(self):
            url = urlparse(self.path)
            sciezka = url.path.rstrip("/")
            if sciezka == "/v1/health":
                if self._guard(token=False):
                    self._send(200, {"ok": True, "service": "shark-agentd", "version": VERSION})
                return
            if not self._guard():
                return
            q = parse_qs(url.query)
            if sciezka == "/v1/status":
                return self._run(lambda: {"providers": app.agent.status(q.get("odswiez", ["0"])[0] == "1")})
            if sciezka == "/v1/browzi":
                return self._run(app.agent.browzi_stan)
            m = re.fullmatch(r"/v1/runs/([0-9a-f]{12})", sciezka)
            if m:
                def widok():
                    try:
                        po = int(q.get("after", ["0"])[0])
                    except ValueError:
                        raise ApiError(400, "after musi być liczbą")
                    return app.agent.get(m.group(1)).view(po)
                return self._run(widok)
            self._send(404, {"error": "Nie ma takiego adresu"})

        def do_POST(self):
            if not self._guard():
                return
            sciezka = urlparse(self.path).path.rstrip("/")
            a = app.agent

            def obsluz():
                b = self._body()
                if sciezka == "/v1/agent":
                    r = a.agent(str(b.get("provider", "")), b.get("prompt", ""), str(b.get("model") or ""),
                                b.get("session_id") or None, b.get("cwd") or None, str(b.get("mode") or "agent"))
                    return {"run_id": r.id}
                if sciezka == "/v1/approve":
                    r = a.pozwol(str(b.get("id", "")), str(b.get("provider", "")), str(b.get("session_id") or "") or None,
                                 str(b.get("model") or ""), b.get("cwd") or None, str(b.get("scope") or "raz"))
                    return {"run_id": r.id}
                if sciezka == "/v1/deny":
                    return a.odmow(str(b.get("id", "")))
                if sciezka == "/v1/task/end":
                    return a.koniec_zadania()
                if sciezka == "/v1/browzi/token":
                    return a.browzi_ustaw(str(b.get("token") or ""))
                if sciezka == "/v1/shell":
                    return a.powloka(str(b.get("session", "")), b.get("command", ""), str(b.get("consent") or ""))
                if sciezka == "/v1/shell/task-end":
                    return a.koniec_zadania_powloki(str(b.get("session", "")))
                m = re.fullmatch(r"/v1/(login|install)/(claude|openai)", sciezka)
                if m:
                    return {"run_id": a.terminal(m.group(1), m.group(2)).id}
                m = re.fullmatch(r"/v1/runs/([0-9a-f]{12})/(stop|input|interrupt)", sciezka)
                if m:
                    if m.group(2) == "interrupt":
                        return a.przerwij(m.group(1))
                    return a.zatrzymaj(m.group(1)) if m.group(2) == "stop" else a.wpisz(m.group(1), b.get("text", ""))
                raise ApiError(404, "Nie ma takiego adresu")
            self._run(obsluz)

    return Handler


# --------------------------------------------------------------------------- start

def runtime_dir() -> Path:
    base = os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}"
    return Path(base) / "shark-agentd"


def write_token(path: Path, token: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(path.parent, 0o700)
    tmp = path.with_suffix(".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(token + "\n")
    os.replace(tmp, path)


def serve(host: str, port: int, cfg_path: Path, rt: Path, origins) -> None:
    if host not in LOOPBACK:
        raise SystemExit(f"shark-agentd: odmawiam nasłuchu na {host} — tylko pętla zwrotna (127.0.0.1, ::1)")
    token = secrets.token_urlsafe(32)
    write_token(rt / "token", token)
    agent = Agent(wczytaj_konfig(cfg_path), rt)
    ThreadingHTTPServer.allow_reuse_address = True
    if ":" in host:
        import socket
        ThreadingHTTPServer.address_family = socket.AF_INET6
    httpd = ThreadingHTTPServer((host, port), make_handler(App(agent, token, origins)))
    httpd.daemon_threads = True
    print(f"shark-agentd {VERSION}: nasłuch na {host}:{httpd.server_address[1]}, ustawienia {cfg_path}", flush=True)

    def stop(*_):
        threading.Thread(target=httpd.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        agent.zamknij()
        httpd.server_close()
        try:
            (rt / "token").unlink()
        except OSError:
            pass


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="shark-agentd", description="Agent SharkOS: Claude Code i Codex dla nakładki (127.0.0.1)")
    sub = ap.add_subparsers(dest="cmd")
    s = sub.add_parser("serve", help="uruchom usługę (domyślnie)")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=DEFAULT_PORT)
    s.add_argument("--config", type=Path, default=None)
    s.add_argument("--allow-origin", action="append", default=None)
    sub.add_parser("token", help="wypisz token bieżącej sesji (dla sharkos-kiosk-session)")
    st = sub.add_parser("status", help="pokaż, czy Claude Code i Codex są zainstalowane i zalogowane")
    st.add_argument("--config", type=Path, default=None)
    a = ap.parse_args(argv)
    cmd = a.cmd or "serve"
    rt = runtime_dir()
    if cmd == "serve":
        serve(getattr(a, "host", "127.0.0.1"), getattr(a, "port", DEFAULT_PORT),
              getattr(a, "config", None) or domyslny_konfig(), rt,
              list(DEFAULT_ORIGINS) + (getattr(a, "allow_origin", None) or []))
        return 0
    if cmd == "status":
        print(json.dumps(Agent(wczytaj_konfig(a.config or domyslny_konfig()), rt).status(True), ensure_ascii=False, indent=1))
        return 0
    try:
        print((rt / "token").read_text().strip())
    except OSError:
        print(f"shark-agentd: brak pliku tokenu {rt / 'token'} — czy usługa działa?", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
