#!/usr/bin/python3
"""shark-sysd — lokalna usługa z prawdziwymi danymi systemu dla nakładki SharkOS.

Nasłuchuje wyłącznie na pętli zwrotnej (domyślnie 127.0.0.1:7378) i podaje:

  GET  /v1/health                 → {"ok": true, "version": ...}
  GET  /v1/sys                    → CPU, RAM, swap, dysk (miejsce + obciążenie), sieć, uptime
  GET  /v1/processes?limit=&sort=&mine=&kernel= → procesy z /proc (CPU %, pamięć, właściciel, nice)
  GET  /v1/services?scope=system|user → jednostki systemd (usługi i timery)
  POST /v1/processes/<pid>/signal {"signal": "TERM|KILL|STOP|CONT", "start_time": N}
  POST /v1/processes/<pid>/renice {"nice": 0..19, "start_time": N}
  GET  /v1/dyski                  → dyski i partycje (lsblk): pendrive'y, dyski Windowsa, inne   [token]
  POST /v1/dyski/montuj {"sciezka": "/dev/sdb1", "zapis": bool}  (wewnętrzne domyślnie tylko odczyt)
  POST /v1/dyski/odmontuj {"sciezka": …}   POST /v1/dyski/wysun {"sciezka": …} (tylko USB)
  GET  /v1/pliki?sciezka=&ukryte= → zawartość katalogu (dom, /media, /run/media, /mnt)          [token]
  GET  /v1/zdarzenia?od=N         → podłączenie / zamontowanie / odłączenie pendrive'ów         [token]
  GET  /v1/aktualizacja           → stan aktualizacji pakietu sharkos (sharkos-aktualizuj)        [token]
  POST /v1/aktualizacja/sprawdz | /instaluj → uruchamia stałą jednostkę systemd (polkit)        [token]
  Pendrive'y montują się same (udisksctl, co 3 s; wyłączenie: SHARK_SYSD_AUTOMOUNT=0).

Akcje (POST) wymagają nagłówka ``X-Shark-Token`` z tokenem sesji. Token powstaje przy
starcie usługi i leży w pliku 0600 (domyślnie ``$XDG_RUNTIME_DIR/shark-sysd/token``).
Akcje dotyczą tylko procesów tego samego użytkownika, pod którym działa usługa
(usługa działa jako jednostka użytkownika systemd, bez uprawnień roota).

Tylko biblioteka standardowa Pythona 3.9+.
"""
from __future__ import annotations

import argparse
import hmac
import json
import os
import pwd
import re
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

VERSION = "0.1.0"
DEFAULT_PORT = 7378
LOOPBACK = {"127.0.0.1", "::1", "localhost"}
DEFAULT_ORIGINS = ("null", "file://")
MAX_BODY = 4096
ALLOWED_SIGNALS = {"TERM": signal.SIGTERM, "KILL": signal.SIGKILL, "STOP": signal.SIGSTOP, "CONT": signal.SIGCONT}
WHOLE_DISK = re.compile(r"^(sd[a-z]+|vd[a-z]+|xvd[a-z]+|hd[a-z]+|nvme\d+n\d+|mmcblk\d+)$")
CLK_TCK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
PAGE = os.sysconf("SC_PAGE_SIZE") if hasattr(os, "sysconf") else 4096


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


# --------------------------------------------------------------------------- odczyt /proc

class ProcReader:
    """Czyta surowe liczniki z /proc. ``root`` pozwala podstawić sztuczne /proc w testach."""

    def __init__(self, root: str | Path = "/proc"):
        self.root = Path(root)

    def _read(self, rel: str) -> str:
        return (self.root / rel).read_text(encoding="utf-8", errors="replace")

    def cpu_times(self) -> dict:
        """Zwraca {"all": (busy, total), "cpu0": (...), ...} w jednostkach USER_HZ."""
        out = {}
        for line in self._read("stat").splitlines():
            if not line.startswith("cpu"):
                continue
            parts = line.split()
            vals = [int(x) for x in parts[1:]]
            # user nice system idle iowait irq softirq steal guest guest_nice
            vals += [0] * (8 - len(vals)) if len(vals) < 8 else []
            idle = vals[3] + vals[4]
            total = sum(vals[:8])  # guest jest już wliczony w user
            out["all" if parts[0] == "cpu" else parts[0]] = (total - idle, total)
        return out

    def cpu_model(self) -> str:
        try:
            for line in self._read("cpuinfo").splitlines():
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
        except OSError:
            pass
        return ""

    def cpu_cores(self) -> int:
        """Liczba rdzeni fizycznych (unikalne pary physical id + core id); 0 gdy brak danych."""
        try:
            text = self._read("cpuinfo")
        except OSError:
            return 0
        cores, phys = set(), "0"
        for line in text.splitlines():
            if ":" not in line:
                continue
            k, v = (s.strip() for s in line.split(":", 1))
            if k == "physical id":
                phys = v
            elif k == "core id":
                cores.add((phys, v))
        return len(cores)

    def meminfo(self) -> dict:
        info = {}
        for line in self._read("meminfo").splitlines():
            k, _, rest = line.partition(":")
            fields = rest.split()
            if fields:
                info[k.strip()] = int(fields[0]) * (1024 if len(fields) > 1 else 1)
        return info

    def loadavg(self) -> list[float]:
        return [float(x) for x in self._read("loadavg").split()[:3]]

    def uptime(self) -> float:
        return float(self._read("uptime").split()[0])

    def diskstats(self) -> dict:
        """{dysk: (sektory_czytane, sektory_pisane, io_ticks_ms)} tylko dla całych dysków."""
        out = {}
        for line in self._read("diskstats").splitlines():
            p = line.split()
            if len(p) < 13 or not WHOLE_DISK.match(p[2]):
                continue
            out[p[2]] = (int(p[5]), int(p[9]), int(p[12]))
        return out

    def netdev(self) -> dict:
        """{interfejs: (bajty_odebrane, bajty_wysłane)} bez pętli zwrotnej."""
        out = {}
        for line in self._read("net/dev").splitlines()[2:]:
            name, _, rest = line.partition(":")
            name = name.strip()
            p = rest.split()
            if not name or name == "lo" or len(p) < 9:
                continue
            out[name] = (int(p[0]), int(p[8]))
        return out

    def pids(self) -> list[int]:
        return sorted(int(d.name) for d in self.root.iterdir() if d.name.isdigit())

    def process(self, pid: int) -> dict | None:
        """Dane jednego procesu; None, jeśli proces zniknął w trakcie odczytu."""
        base = f"{pid}"
        try:
            stat = self._read(f"{base}/stat")
            status = self._read(f"{base}/status")
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            return None
        # nazwa w nawiasach może zawierać spacje i nawiasy — szukamy ostatniego ')'
        lp, rp = stat.find("("), stat.rfind(")")
        comm = stat[lp + 1:rp]
        f = stat[rp + 2:].split()
        # f[0]=state (pole 3), utime=pole14 → f[11], stime → f[12], nice → f[16], threads f[17], starttime f[19], rss f[21]
        uid = 0
        for line in status.splitlines():
            if line.startswith("Uid:"):
                uid = int(line.split()[1])  # rzeczywisty UID
                break
        try:
            raw = (self.root / base / "cmdline").read_bytes()
            cmdline = raw.replace(b"\0", b" ").decode("utf-8", "replace").strip()
        except OSError:
            cmdline = ""
        return {
            "pid": pid,
            "ppid": int(f[1]),
            "name": comm,
            "cmdline": cmdline[:300],
            "state": f[0],
            "ticks": int(f[11]) + int(f[12]),
            "nice": int(f[16]),
            "threads": int(f[17]),
            "start_time": int(f[19]),
            "rss_bytes": int(f[21]) * PAGE,
            "uid": uid,
            "kernel": pid == 2 or int(f[1]) == 2,  # wątki jądra (kthreadd i jego dzieci)
        }


# --------------------------------------------------------------------------- próbkowanie

def _pct(delta_busy: float, delta_total: float) -> float:
    return round(100.0 * delta_busy / delta_total, 1) if delta_total > 0 else 0.0


class Sampler:
    """Liczy wartości chwilowe (CPU %, MB/s) jako różnicę między dwoma odczytami.

    Pierwsze zapytanie robi dwa odczyty w odstępie ``warmup`` sekund; kolejne liczą
    różnicę względem poprzedniego zapytania (nie częściej niż co ``min_interval``).
    """

    def __init__(self, reader: ProcReader, clock=time.monotonic, sleep=time.sleep,
                 warmup: float = 0.25, min_interval: float = 0.4, disk_paths=("/", "/home")):
        self.r = reader
        self.clock, self.sleep = clock, sleep
        self.warmup, self.min_interval = warmup, min_interval
        self.disk_paths = disk_paths
        self.lock = threading.Lock()
        self._sys_prev = None
        self._sys_cache = None
        self._proc_prev = None
        self._proc_cache = None
        self._static = None

    # ---- system
    def _sys_raw(self) -> dict:
        return {"t": self.clock(), "cpu": self.r.cpu_times(), "disk": self.r.diskstats(), "net": self.r.netdev()}

    def _static_info(self) -> dict:
        if self._static is None:
            threads = max(0, len(self.r.cpu_times()) - 1) or (os.cpu_count() or 1)
            self._static = {"model": self.r.cpu_model(), "cores": self.r.cpu_cores() or threads, "threads": threads}
        return self._static

    def sys(self) -> dict:
        with self.lock:
            now = self.clock()
            if self._sys_cache and now - self._sys_cache[0] < self.min_interval:
                return self._sys_cache[1]
            if self._sys_prev is None:
                self._sys_prev = self._sys_raw()
                self.sleep(self.warmup)
            cur = self._sys_raw()
            prev, self._sys_prev = self._sys_prev, cur
            data = self._compute_sys(prev, cur)
            self._sys_cache = (cur["t"], data)
            return data

    def _compute_sys(self, prev: dict, cur: dict) -> dict:
        dt = max(cur["t"] - prev["t"], 1e-6)
        per = []
        for name, (busy, total) in sorted(cur["cpu"].items(), key=lambda kv: (len(kv[0]), kv[0])):
            if name == "all":
                continue
            pb, pt = prev["cpu"].get(name, (busy, total))
            per.append(_pct(busy - pb, total - pt))
        b, t = cur["cpu"]["all"]
        pb, pt = prev["cpu"].get("all", (b, t))

        mem = self.r.meminfo()
        total = mem.get("MemTotal", 0)
        avail = mem.get("MemAvailable", mem.get("MemFree", 0))
        swap_t, swap_f = mem.get("SwapTotal", 0), mem.get("SwapFree", 0)

        disks, busy_max, rd, wr = [], 0.0, 0.0, 0.0
        for name, (sr, sw, ticks) in cur["disk"].items():
            psr, psw, pticks = prev["disk"].get(name, (sr, sw, ticks))
            r_bps, w_bps = (sr - psr) * 512 / dt, (sw - psw) * 512 / dt
            busy = min(100.0, round((ticks - pticks) / (dt * 1000) * 100, 1))
            busy_max, rd, wr = max(busy_max, busy), rd + r_bps, wr + w_bps
            disks.append({"name": name, "busy_pct": busy, "read_bps": round(r_bps), "write_bps": round(w_bps)})

        rx = tx = 0.0
        ifaces = []
        for name, (r, s) in cur["net"].items():
            pr, ps = prev["net"].get(name, (r, s))
            ifaces.append({"name": name, "rx_bps": round((r - pr) / dt), "tx_bps": round((s - ps) / dt)})
            rx, tx = rx + (r - pr) / dt, tx + (s - ps) / dt

        space, seen = [], set()
        for p in self.disk_paths:
            try:
                st = os.stat(p)
                if st.st_dev in seen:
                    continue
                seen.add(st.st_dev)
                du = shutil.disk_usage(p)
                space.append({"path": p, "total_bytes": du.total, "used_bytes": du.used, "free_bytes": du.free})
            except OSError:
                continue

        return {
            "time": time.time(),
            "interval_s": round(dt, 3),
            "cpu": {**self._static_info(), "percent": _pct(b - pb, t - pt), "per_cpu": per, "load": self.r.loadavg()},
            "memory": {"total_bytes": total, "available_bytes": avail, "used_bytes": total - avail,
                       "percent": round(100.0 * (total - avail) / total, 1) if total else 0.0,
                       "swap_total_bytes": swap_t, "swap_used_bytes": swap_t - swap_f},
            "disk": {"busy_pct": busy_max, "read_bps": round(rd), "write_bps": round(wr), "devices": disks, "space": space},
            "net": {"rx_bps": round(rx), "tx_bps": round(tx), "interfaces": ifaces},
            "uptime_s": self.r.uptime(),
        }

    # ---- procesy
    def _proc_raw(self) -> dict:
        procs = {}
        for pid in self.r.pids():
            p = self.r.process(pid)
            if p:
                procs[(pid, p["start_time"])] = p
        return {"t": self.clock(), "cpu_total": self.r.cpu_times()["all"][1], "procs": procs}

    def processes(self) -> list[dict]:
        with self.lock:
            now = self.clock()
            if self._proc_cache and now - self._proc_cache[0] < self.min_interval:
                return self._proc_cache[1]
            if self._proc_prev is None:
                self._proc_prev = self._proc_raw()
                self.sleep(self.warmup)
            cur = self._proc_raw()
            prev, self._proc_prev = self._proc_prev, cur
            d_total = cur["cpu_total"] - prev["cpu_total"]
            names: dict[int, str] = {}
            out = []
            for key, p in cur["procs"].items():
                old = prev["procs"].get(key)
                d = p["ticks"] - old["ticks"] if old else 0
                # procent całej maszyny (jak w Menedżerze zadań Windows), nie jednego rdzenia
                p = dict(p, cpu_pct=_pct(d, d_total))
                uid = p["uid"]
                if uid not in names:
                    try:
                        names[uid] = pwd.getpwuid(uid).pw_name
                    except KeyError:
                        names[uid] = str(uid)
                p["user"] = names[uid]
                del p["ticks"]
                out.append(p)
            self._proc_cache = (cur["t"], out)
            return out


# --------------------------------------------------------------------------- systemd

def _systemctl_units(systemctl: str, scope: str, timeout: float = 3.0) -> list[dict]:
    cmd = [systemctl] + (["--user"] if scope == "user" else []) + [
        "list-units", "--type=service,timer", "--all", "--plain", "--no-legend", "--no-pager"]
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                         env={**os.environ, "LC_ALL": "C.UTF-8", "SYSTEMD_COLORS": "0"})
    if res.returncode != 0 and not res.stdout.strip():
        raise RuntimeError((res.stderr or "systemctl zwrócił błąd").strip().splitlines()[0])
    return parse_units(res.stdout)


def parse_units(text: str) -> list[dict]:
    """Parsuje wyjście ``systemctl list-units --plain --no-legend``."""
    units = []
    for line in text.splitlines():
        line = line.strip().lstrip("●* ").strip()
        p = line.split(None, 4)
        if len(p) < 4 or "." not in p[0]:
            continue
        units.append({"name": p[0], "load": p[1], "active": p[2], "sub": p[3],
                      "description": p[4] if len(p) > 4 else "",
                      "running": p[2] == "active", "sharkos": p[0].startswith("shark-")})
    return units


class Services:
    def __init__(self, systemctl: str | None = None, ttl: float = 5.0, clock=time.monotonic):
        self.systemctl = systemctl if systemctl is not None else (shutil.which("systemctl") or "")
        self.ttl, self.clock = ttl, clock
        self.cache: dict[str, tuple[float, dict]] = {}
        self.lock = threading.Lock()

    def list(self, scope: str = "system") -> dict:
        if scope not in ("system", "user"):
            raise ApiError(400, "Parametr scope musi mieć wartość system albo user")
        with self.lock:
            hit = self.cache.get(scope)
            if hit and self.clock() - hit[0] < self.ttl:
                return hit[1]
            if not self.systemctl:
                data = {"available": False, "scope": scope, "error": "Brak systemctl w systemie", "units": []}
            else:
                try:
                    data = {"available": True, "scope": scope, "units": _systemctl_units(self.systemctl, scope)}
                except (OSError, RuntimeError, subprocess.TimeoutExpired) as e:
                    data = {"available": False, "scope": scope, "error": f"systemd niedostępny: {e}", "units": []}
            self.cache[scope] = (self.clock(), data)
            return data


# --------------------------------------------------------------------------- akcje

class Actions:
    """Sygnały i renice — tylko dla procesów właściciela usługi."""

    def __init__(self, reader: ProcReader, uid: int | None = None, self_pid: int | None = None,
                 kill=os.kill, setpriority=os.setpriority):
        self.r = reader
        self.uid = os.getuid() if uid is None else uid
        self.self_pid = os.getpid() if self_pid is None else self_pid
        self._kill, self._setprio = kill, setpriority

    def _target(self, pid: int, start_time) -> dict:
        if pid <= 1:
            raise ApiError(403, "Tego procesu nie wolno ruszać")
        if pid == self.self_pid:
            raise ApiError(403, "shark-sysd nie zakończy samego siebie")
        p = self.r.process(pid)
        if p is None:
            raise ApiError(404, f"Nie ma procesu {pid}")
        if p["uid"] != self.uid:
            raise ApiError(403, f"Proces {pid} należy do innego użytkownika — tu można zarządzać tylko własnymi procesami")
        if start_time is not None:
            if not isinstance(start_time, int) or isinstance(start_time, bool):
                raise ApiError(400, "start_time musi być liczbą całkowitą")
            if p["start_time"] != start_time:
                raise ApiError(409, f"Proces {pid} już się zakończył, a numer dostał inny program — odśwież listę")
        return p

    def signal(self, pid: int, body: dict) -> dict:
        name = str(body.get("signal", "TERM")).upper().removeprefix("SIG")
        if name not in ALLOWED_SIGNALS:
            raise ApiError(400, f"Niedozwolony sygnał. Dozwolone: {', '.join(ALLOWED_SIGNALS)}")
        p = self._target(pid, body.get("start_time"))
        try:
            self._kill(pid, ALLOWED_SIGNALS[name])
        except ProcessLookupError:
            raise ApiError(404, f"Proces {pid} już nie istnieje")
        except PermissionError:
            raise ApiError(403, f"System nie pozwolił wysłać sygnału do procesu {pid}")
        return {"ok": True, "pid": pid, "name": p["name"], "signal": name}

    def renice(self, pid: int, body: dict) -> dict:
        nice = body.get("nice")
        if not isinstance(nice, int) or isinstance(nice, bool) or not -20 <= nice <= 19:
            raise ApiError(400, "nice musi być liczbą całkowitą od -20 do 19")
        p = self._target(pid, body.get("start_time"))
        try:
            self._setprio(os.PRIO_PROCESS, pid, nice)
        except ProcessLookupError:
            raise ApiError(404, f"Proces {pid} już nie istnieje")
        except PermissionError:
            raise ApiError(403, "Podniesienie priorytetu (nice niższe niż obecne) wymaga uprawnień administratora")
        return {"ok": True, "pid": pid, "name": p["name"], "nice": nice, "previous_nice": p["nice"]}


# --------------------------------------------------------------------------- stan instalacji

SHARKOS_STATE = Path("/var/lib/sharkos")


def _ostatnia_zmiana_hasla(user: str, chage=None):
    """Data ostatniej zmiany hasła z `chage -l` (własne konto — bez roota). None, gdy nie wiadomo.
    Uwaga: pod jednostką z NoNewPrivileges=yes setgid `chage` nie czyta /etc/shadow → None; nakładka
    przypomina wtedy zachowawczo, a użytkownik wyłącza przypomnienie przyciskiem „Już zmieniłem”."""
    from datetime import datetime
    try:
        if chage is not None:
            out = chage(user)
        else:
            out = subprocess.run(["chage", "-l", user], capture_output=True, text=True, timeout=5,
                                 env={"LC_ALL": "C", "PATH": "/usr/bin:/bin"}).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    for line in out.splitlines():
        if line.lower().startswith("last password change"):
            val = line.split(":", 1)[1].strip()
            try:
                return datetime.strptime(val, "%b %d, %Y").date()
            except ValueError:
                return None
    return None


def install_info(state_dir: Path = SHARKOS_STATE, user: str | None = None, chage=None) -> dict:
    """Znaczniki instalatora (preseed late_command) — do ekranu „Instalacja zakończona” w nakładce.
    Nie czyta żadnych sekretów: tylko daty, wersję i istnienie plików."""
    from datetime import date

    def czytaj(nazwa):
        try:
            return (state_dir / nazwa).read_text(errors="replace").strip()
        except OSError:
            return None

    stamp = czytaj("install-stamp") or ""
    integ = (czytaj("integration-done") or "").split()
    btrfs = "ok" if (state_dir / "btrfs-ok").exists() else "problem" if (state_dir / "btrfs-problem").exists() else None
    marker = state_dir / "default-password"
    znacznik = marker.exists()          # plik jest 0600 root, ale stat/exists działa (katalog jest czytelny)
    zmienione = None
    if znacznik:
        user = user or pwd.getpwuid(os.getuid()).pw_name
        ostatnia = _ostatnia_zmiana_hasla(user, chage)
        if ostatnia is not None:
            # late_command cofa datę zmiany hasła na dzień przed znacznikiem, więc każda zmiana od dnia
            # instalacji (także tego samego dnia — shadow liczy w dniach) daje datę >= dacie znacznika.
            zmienione = ostatnia >= date.fromtimestamp(marker.stat().st_mtime)
    return {
        "installed": stamp.startswith("installed "),
        "installed_at": stamp.split(" ", 1)[1] if stamp.startswith("installed ") else None,
        "sharkos_version": integ[1] if len(integ) > 1 and integ[0] == "sharkos" else None,
        "integration": "done" if integ else ("pending" if (state_dir / "integration-pending").exists() else None),
        "btrfs": btrfs,
        "default_password": znacznik and zmienione is not True,
        "password_changed_since_install": zmienione,
    }


# --------------------------------------------------------------------------- dyski, pendrive'y, pliki
# Wykrywanie: lsblk (JSON). Montowanie: udisksctl (udisks2) jako zwykły użytkownik — uprawnienia daje reguła
# polkit z pakietu (packaging/files/50-sharkos-dyski.rules: aktywna lokalna sesja + grupa sudo).
# Nigdy nie formatujemy ani nie zmieniamy partycji. Dyski Windowsa (NTFS) domyślnie tylko do odczytu —
# zapis wyłącznie na wyraźne żądanie (zapis=true) z nakładki, po zgodzie użytkownika.

LSBLK_COLS = "NAME,PATH,SIZE,TYPE,FSTYPE,LABEL,UUID,MOUNTPOINTS,RM,HOTPLUG,TRAN,MODEL,PARTTYPE,PKNAME,RO"
MONTOWALNE = {"vfat", "exfat", "ntfs", "ntfs3", "ext4", "ext3", "ext2", "btrfs", "xfs", "iso9660", "udf", "f2fs"}
SYSTEMOWE_PUNKTY = {"/", "/boot", "/boot/efi", "/home", "/var/log", "/usr", "/var", "[SWAP]"}
TYP_EFI = {"c12a7328-f81f-11d2-ba4b-00a0c93ec93b", "0xef"}
TYP_MSR = {"e3c9e316-0b5c-4db8-817d-f92df00215ae"}
TYP_WINRE = {"de94bba4-06d1-4d40-a16a-bfd50179d6ac", "0x27"}


def _rozmiar_ludzki(b: int) -> str:
    for jedn, dz in (("TB", 1 << 40), ("GB", 1 << 30), ("MB", 1 << 20)):
        if b >= dz:
            return f"{b / dz:.0f} {jedn}" if b / dz >= 10 else f"{b / dz:.1f} {jedn}".replace(".", ",")
    return f"{b} B"


class Disks:
    """Lista dysków z lsblk + montowanie/odmontowanie/wysunięcie przez udisksctl."""

    def __init__(self, lsblk: str | None = None, udisksctl: str | None = None, run=subprocess.run):
        self.lsblk = lsblk or shutil.which("lsblk") or "lsblk"
        self.udisksctl = udisksctl or shutil.which("udisksctl") or "udisksctl"
        self.run = run
        self._lock = threading.Lock()

    def raw(self) -> list[dict]:
        r = self.run([self.lsblk, "-J", "-b", "-o", LSBLK_COLS], capture_output=True, text=True, timeout=10)
        if r.returncode != 0:
            raise ApiError(500, f"lsblk: {r.stderr.strip() or r.returncode}")
        out: list[dict] = []

        def plaski(dev: dict, rodzic: dict | None):
            d = dict(dev)
            d["_dzieci"] = bool(dev.get("children"))
            for k in ("tran", "model", "rm", "hotplug"):     # partycje dziedziczą po dysku
                if rodzic and not d.get(k):
                    d[k] = rodzic.get(k)
            d["_dysk"] = (rodzic or {}).get("path") if rodzic else d.get("path")
            out.append(d)
            for c in dev.get("children") or []:
                plaski(c, d if d.get("type") == "disk" else rodzic)
        for dev in json.loads(r.stdout or "{}").get("blockdevices", []):
            plaski(dev, None)
        return out

    @staticmethod
    def _bool(v) -> bool:
        return v in (True, 1, "1", "true")

    def opisz(self, d: dict) -> dict | None:
        """Wpis dla nakładki albo None (partycje techniczne, swap, loop, zram, pusty czytnik)."""
        typ, fs = d.get("type"), (d.get("fstype") or "").lower()
        if typ not in ("part", "disk", "crypt", "rom") or (typ == "disk" and d.get("_dzieci")):
            return None
        if not fs or fs == "swap" or (d.get("name") or "").startswith(("zram", "loop")):
            return None
        pt = (d.get("parttype") or "").lower()
        punkty = sorted((p for p in (d.get("mountpoints") or []) if p), key=len)   # btrfs: „/” przed „/home”
        usb = d.get("tran") == "usb" or self._bool(d.get("rm")) or self._bool(d.get("hotplug"))
        if pt in TYP_MSR | TYP_WINRE:
            return None
        if pt in TYP_EFI and not usb:
            return None                       # partycje EFI systemów — nie dla ludzi
        systemowy = any(p in SYSTEMOWE_PUNKTY for p in punkty)
        if systemowy:
            rodzaj = "systemowy"
        elif usb:
            rodzaj = "usb"
        elif fs in ("ntfs", "ntfs3"):
            rodzaj = "windows"
        else:
            rodzaj = "inny"
        rozmiar = int(d.get("size") or 0)
        etykieta = d.get("label") or ""
        nazwa = etykieta or (("Windows" if rodzaj == "windows" else (d.get("model") or "Dysk").strip())
                             + f" ({_rozmiar_ludzki(rozmiar)})")
        if fs == "bitlocker" or fs == "crypto_luks":
            mozna, powod = False, "zaszyfrowany — odblokowanie jeszcze nieobsługiwane"
        elif fs not in MONTOWALNE:
            mozna, powod = False, f"system plików {fs} nieobsługiwany"
        else:
            mozna, powod = not punkty and not systemowy, ""
        return {"sciezka": d.get("path"), "dysk": d.get("_dysk"), "nazwa": nazwa, "etykieta": etykieta,
                "rozmiar": rozmiar, "rozmiar_tekst": _rozmiar_ludzki(rozmiar), "fs": fs, "uuid": d.get("uuid") or "",
                "model": (d.get("model") or "").strip(), "rodzaj": rodzaj, "usb": usb,
                "zamontowany": punkty[0] if punkty else None, "tylko_odczyt": self._bool(d.get("ro")),
                "mozna_montowac": mozna, "powod": powod}

    def lista(self) -> list[dict]:
        return [w for w in (self.opisz(d) for d in self.raw()) if w]

    def znajdz(self, sciezka: str) -> dict:
        if not isinstance(sciezka, str) or not re.fullmatch(r"/dev/[A-Za-z0-9/_.-]{1,64}", sciezka):
            raise ApiError(400, "sciezka: urządzenie /dev/…")
        for w in self.lista():
            if w["sciezka"] == sciezka:
                return w
        raise ApiError(404, f"Nie ma dysku {sciezka}")

    def _udisks(self, *args) -> str:
        # Brak udisks2 (aktualizacja z pendrive'a instaluje sam pakiet, bez Recommends — komputer docelowy
        # 11.11.2026): czytelny komunikat zamiast „Błąd wewnętrzny: FileNotFoundError”. Brak doinstaluje
        # automatyczna aktualizacja (sharkos-aktualizuj uzupełnia zależności).
        try:
            r = self.run([self.udisksctl, *args, "--no-user-interaction"], capture_output=True, text=True, timeout=60)
        except FileNotFoundError:
            raise ApiError(503, "Brak programu do montowania dysków (udisks2). Doinstaluje go automatyczna "
                                "aktualizacja; od razu: sudo apt install udisks2")
        except subprocess.TimeoutExpired:
            raise ApiError(504, "udisksctl nie odpowiedział w 60 s")
        if r.returncode != 0:
            msg = (r.stderr or r.stdout).strip().splitlines()[-1:] or [str(r.returncode)]
            raise ApiError(409, f"udisksctl: {msg[0]}")
        return r.stdout.strip()

    def montuj(self, body: dict) -> dict:
        w = self.znajdz(body.get("sciezka"))
        if w["rodzaj"] == "systemowy":
            raise ApiError(403, "To partycja systemu SharkOS — już jest zamontowana")
        if w["zamontowany"]:
            return {"ok": True, "zamontowany": w["zamontowany"], "juz": True}
        if not w["mozna_montowac"]:
            raise ApiError(409, w["powod"] or "Tego dysku nie da się zamontować")
        # dyski wewnętrzne (Windows i inne) tylko do odczytu, chyba że użytkownik wyraźnie zgodził się na zapis;
        # pendrive'y z zapisem, chyba że nakładka poprosi o sam odczyt
        if w["usb"]:
            tylko_odczyt = body.get("zapis") is False
        else:
            tylko_odczyt = body.get("zapis") is not True
        args = ["mount", "-b", w["sciezka"]] + (["-o", "ro"] if tylko_odczyt else [])
        with self._lock:
            try:
                out = self._udisks(*args)
            except ApiError as e:
                if "hibernat" in e.message.lower() or "unclean" in e.message.lower() or "dirty" in e.message.lower():
                    raise ApiError(409, "Windows nie został zamknięty do końca (szybkie uruchamianie / hibernacja) — "
                                        "dysk można otworzyć tylko do odczytu. Wyłącz w Windowsie szybkie uruchamianie.")
                raise
        m = re.search(r" at (/\S.*?)\.?$", out)
        return {"ok": True, "zamontowany": m.group(1) if m else None, "tylko_odczyt": tylko_odczyt}

    def odmontuj(self, body: dict) -> dict:
        w = self.znajdz(body.get("sciezka"))
        if w["rodzaj"] == "systemowy":
            raise ApiError(403, "Partycji systemu SharkOS nie odmontowuję")
        if w["zamontowany"]:
            with self._lock:
                self._udisks("unmount", "-b", w["sciezka"])
        return {"ok": True}

    def wysun(self, body: dict) -> dict:
        w = self.znajdz(body.get("sciezka"))
        if not w["usb"]:
            raise ApiError(403, "Wysunąć można tylko pendrive / dysk USB")
        for p in self.lista():
            if p["dysk"] == w["dysk"] and p["zamontowany"]:
                self.odmontuj({"sciezka": p["sciezka"]})
        with self._lock:
            self._udisks("power-off", "-b", w["dysk"] or w["sciezka"])
        return {"ok": True}


class AutoMount:
    """Co kilka sekund: nowe pendrive'y montuje sam (zapis włączony), zapisuje zdarzenia dla nakładki."""

    def __init__(self, disks: Disks, co: float = 3.0, clock=time.time):
        self.disks, self.co, self.clock = disks, co, clock
        self.znane: dict[str, dict] = {}
        self.nieudane: set[str] = set()
        self.zdarzenia: list[dict] = []
        self.nr = 0
        self._lock = threading.Lock()
        self.pierwszy = True

    def _zdarzenie(self, typ: str, w: dict, **extra):
        with self._lock:
            self.nr += 1
            self.zdarzenia.append({"nr": self.nr, "czas": self.clock(), "typ": typ, "nazwa": w["nazwa"],
                                   "sciezka": w["sciezka"], **extra})
            del self.zdarzenia[:-50]

    def krok(self) -> None:
        try:
            teraz = {w["sciezka"]: w for w in self.disks.lista() if w["usb"]}
        except Exception:
            return
        for s, w in teraz.items():
            if s not in self.znane and not self.pierwszy:
                self._zdarzenie("podlaczono", w)
            if not w["zamontowany"] and w["mozna_montowac"] and s not in self.nieudane:
                try:
                    r = self.disks.montuj({"sciezka": s, "zapis": True})
                    self._zdarzenie("zamontowano", w, zamontowany=r.get("zamontowany"))
                except ApiError as e:
                    self.nieudane.add(s)
                    self._zdarzenie("blad", w, blad=e.message)
        for s, w in self.znane.items():
            if s not in teraz:
                self._zdarzenie("odlaczono", w)
                self.nieudane.discard(s)
        self.znane, self.pierwszy = teraz, False

    def od(self, nr: int) -> dict:
        with self._lock:
            return {"nr": self.nr, "zdarzenia": [z for z in self.zdarzenia if z["nr"] > nr]}

    def start(self) -> None:
        def petla():
            while True:
                self.krok()
                time.sleep(self.co)
        threading.Thread(target=petla, daemon=True, name="automontowanie").start()


class Files:
    """Lista plików tylko w katalogu domowym i na zamontowanych dyskach (/media, /run/media, /mnt)."""

    def __init__(self, home: Path | None = None, extra_roots=("/media", "/run/media", "/mnt")):
        self.home = Path(home or Path.home()).resolve()
        self.roots = [self.home] + [Path(r) for r in extra_roots]

    def dozwolona(self, p: Path) -> bool:
        return any(p == r or r in p.parents for r in self.roots)

    def lista(self, query: dict) -> dict:
        s = query.get("sciezka", [str(self.home)])[0] or str(self.home)
        p = Path(os.path.expanduser(s))
        try:
            p = p.resolve(strict=True)
        except (OSError, RuntimeError):
            raise ApiError(404, f"Nie ma {s}")
        if not self.dozwolona(p):
            raise ApiError(403, "Poza katalogiem domowym i zamontowanymi dyskami")
        if not p.is_dir():
            raise ApiError(400, "To nie jest katalog")
        ukryte = query.get("ukryte", ["0"])[0] in ("1", "true")
        wpisy = []
        try:
            it = list(os.scandir(p))
        except PermissionError:
            raise ApiError(403, "Brak dostępu do tego katalogu")
        for e in it:
            if not ukryte and e.name.startswith("."):
                continue
            try:
                st = e.stat(follow_symlinks=True)
                katalog = e.is_dir(follow_symlinks=True)
            except OSError:
                continue
            wpisy.append({"nazwa": e.name, "katalog": katalog, "rozmiar": 0 if katalog else st.st_size,
                          "zmieniony": st.st_mtime, "link": e.is_symlink()})
        wpisy.sort(key=lambda w: (not w["katalog"], w["nazwa"].lower()))
        rodzic = str(p.parent) if p != p.parent and self.dozwolona(p.parent) else None
        return {"sciezka": str(p), "rodzic": rodzic, "dom": str(self.home), "ile": len(wpisy), "wpisy": wpisy[:2000]}


class Updates:
    """Aktualizacje pakietu sharkos: stan z sharkos-aktualizuj, przyciski uruchamiają stałe jednostki systemd
    (bez hasła tylko w aktywnej lokalnej sesji — reguła polkit 51-sharkos-aktualizacje.rules)."""

    JEDNOSTKI = {"sprawdz": "sharkos-aktualizacja-sprawdz.service", "instaluj": "sharkos-aktualizacja-instaluj.service"}
    POLA = ("stan", "tryb", "zainstalowana", "dostepna", "sprawdzono", "komunikat")

    def __init__(self, plik: Path | None = None, systemctl: str | None = None, run=subprocess.run):
        self.plik = Path(plik or SHARKOS_STATE / "aktualizacja.json")
        self.systemctl = systemctl or shutil.which("systemctl") or "systemctl"
        self.run = run

    def stan(self) -> dict:
        try:
            d = json.loads(self.plik.read_text(encoding="utf-8"))
            if not isinstance(d, dict):
                raise ValueError
        except FileNotFoundError:
            return {"stan": "nieznany", "komunikat": "jeszcze nie sprawdzano aktualizacji"}
        except (OSError, ValueError):
            return {"stan": "blad", "komunikat": "nieczytelny plik stanu aktualizacji"}
        return {k: str(d.get(k, "")) for k in self.POLA}

    def uruchom(self, co: str) -> dict:
        jednostka = self.JEDNOSTKI[co]
        try:
            r = self.run([self.systemctl, "start", "--no-block", "--no-ask-password", jednostka],
                         capture_output=True, text=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired) as e:
            raise ApiError(500, f"Nie udało się uruchomić {jednostka}: {e}")
        if r.returncode != 0:
            msg = (r.stderr or r.stdout or "").strip()
            if "denied" in msg.lower() or "authentication" in msg.lower() or "interactive" in msg.lower():
                raise ApiError(403, "Brak uprawnień — aktualizację może uruchomić tylko osoba przy komputerze")
            raise ApiError(500, f"systemctl: {msg or r.returncode}")
        return {"ok": True, "uruchomiono": jednostka}


# --------------------------------------------------------------------------- HTTP

class App:
    def __init__(self, token: str, reader: ProcReader | None = None, sampler: Sampler | None = None,
                 services: Services | None = None, actions: Actions | None = None,
                 origins=DEFAULT_ORIGINS, port: int = DEFAULT_PORT, disks: Disks | None = None,
                 automount: AutoMount | None = None, files: Files | None = None, updates: Updates | None = None):
        self.reader = reader or ProcReader()
        self.sampler = sampler or Sampler(self.reader)
        self.services = services or Services()
        self.actions = actions or Actions(self.reader)
        self.disks = disks or Disks()
        self.automount = automount or AutoMount(self.disks)
        self.files = files or Files()
        self.updates = updates or Updates()
        self.token = token
        self.origins = set(origins)
        self.port = port

    def allowed_hosts(self, port: int) -> set[str]:
        return {f"127.0.0.1:{port}", f"localhost:{port}", f"[::1]:{port}"}

    def check_token(self, value: str | None) -> bool:
        return bool(value) and hmac.compare_digest(value.encode(), self.token.encode())

    def processes(self, query: dict) -> dict:
        procs = self.sampler.processes()
        sort = query.get("sort", ["cpu"])[0]
        keys = {"cpu": lambda p: (p["cpu_pct"], p["rss_bytes"]), "mem": lambda p: (p["rss_bytes"], p["cpu_pct"]),
                "pid": lambda p: -p["pid"], "name": lambda p: p["name"].lower()}
        if sort not in keys:
            raise ApiError(400, "sort: cpu, mem, pid albo name")
        try:
            limit = int(query.get("limit", ["0"])[0])
        except ValueError:
            raise ApiError(400, "limit musi być liczbą")
        flag = lambda k, d: query.get(k, [d])[0] in ("1", "true")
        mine, kernel = flag("mine", "0"), flag("kernel", "1")
        rows = [dict(p, own=p["uid"] == self.actions.uid) for p in procs
                if (not mine or p["uid"] == self.actions.uid) and (kernel or not p["kernel"])]
        rows.sort(key=keys[sort], reverse=sort != "name")
        total = len(rows)
        if limit > 0:
            rows = rows[:limit]
        return {"time": time.time(), "count": total, "uid": self.actions.uid, "processes": rows}


def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        server_version = f"shark-sysd/{VERSION}"
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):  # cisza w dzienniku przy zwykłych zapytaniach
            if os.environ.get("SHARK_SYSD_DEBUG"):
                sys.stderr.write("shark-sysd: " + (fmt % args) + "\n")

        # -- pomocnicze
        def _origin_ok(self) -> tuple[bool, str | None]:
            origin = self.headers.get("Origin")
            return (origin is None or origin in app.origins), origin

        def _send(self, status: int, payload: dict | None, extra: dict | None = None):
            body = b"" if payload is None else json.dumps(payload, ensure_ascii=False).encode()
            self.send_response(status)
            ok, origin = self._origin_ok()
            if origin is not None and ok:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if payload is not None:
                self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if body and self.command != "HEAD":
                self.wfile.write(body)

        def _guard(self) -> bool:
            host = (self.headers.get("Host") or "").lower()
            if host not in app.allowed_hosts(self.server.server_address[1]):
                self._send(403, {"error": "Niedozwolony nagłówek Host (ochrona przed DNS rebinding)"})
                return False
            ok, _ = self._origin_ok()
            if not ok:
                self._send(403, {"error": "Niedozwolone pochodzenie (Origin)"})
                return False
            return True

        def _run(self, fn):
            try:
                self._send(200, fn())
            except ApiError as e:
                self._send(e.status, {"error": e.message})
            except Exception as e:  # nie wysypujemy serwera przez jeden błąd
                self._send(500, {"error": f"Błąd wewnętrzny: {type(e).__name__}: {e}"})

        # -- metody
        def do_OPTIONS(self):
            if not self._guard():
                return
            self._send(204, None, {"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                                   "Access-Control-Allow-Headers": "Content-Type, X-Shark-Token",
                                   "Access-Control-Allow-Private-Network": "true",
                                   "Access-Control-Max-Age": "600"})

        def do_GET(self):
            if not self._guard():
                return
            url = urlparse(self.path)
            q = parse_qs(url.query)
            routes = {
                "/v1/health": lambda: {"ok": True, "service": "shark-sysd", "version": VERSION},
                "/v1/sys": app.sampler.sys,
                "/v1/processes": lambda: app.processes(q),
                "/v1/services": lambda: app.services.list(q.get("scope", ["system"])[0]),
                "/v1/install": lambda: install_info(),
            }
            # dyski, pliki i zdarzenia USB: tylko z tokenem sesji (zawartość katalogów to prywatne dane)
            chronione = {
                "/v1/dyski": lambda: {"dyski": app.disks.lista()},
                "/v1/pliki": lambda: app.files.lista(q),
                "/v1/zdarzenia": lambda: app.automount.od(int(q.get("od", ["0"])[0]) if q.get("od", ["0"])[0].isdigit() else 0),
                "/v1/aktualizacja": app.updates.stan,
            }
            sciezka = url.path.rstrip("/") or "/"
            if sciezka in chronione:
                if not app.check_token(self.headers.get("X-Shark-Token")):
                    return self._send(401, {"error": "Brak lub zły token sesji (X-Shark-Token)"})
                return self._run(chronione[sciezka])
            fn = routes.get(sciezka)
            if fn is None:
                return self._send(404, {"error": "Nie ma takiego adresu"})
            self._run(fn)

        def do_POST(self):
            if not self._guard():
                return
            sciezka = urlparse(self.path).path
            m = re.fullmatch(r"/v1/processes/(\d{1,9})/(signal|renice)", sciezka)
            d = re.fullmatch(r"/v1/dyski/(montuj|odmontuj|wysun)", sciezka)
            a = re.fullmatch(r"/v1/aktualizacja/(sprawdz|instaluj)", sciezka)
            if not m and not d and not a:
                return self._send(404, {"error": "Nie ma takiego adresu"})
            if not app.check_token(self.headers.get("X-Shark-Token")):
                return self._send(401, {"error": "Brak lub zły token sesji (X-Shark-Token)"})
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                return self._send(400, {"error": "Zły Content-Length"})
            if length > MAX_BODY:
                return self._send(413, {"error": "Za duże zapytanie"})
            try:
                body = json.loads(self.rfile.read(length) or b"{}")
                if not isinstance(body, dict):
                    raise ValueError
            except ValueError:
                return self._send(400, {"error": "Treść musi być obiektem JSON"})
            if d:
                return self._run(lambda: getattr(app.disks, d.group(1))(body))
            if a:
                return self._run(lambda: app.updates.uruchom(a.group(1)))
            pid, action = int(m.group(1)), m.group(2)
            self._run(lambda: getattr(app.actions, action)(pid, body))

    return Handler


# --------------------------------------------------------------------------- token i start

def default_token_file() -> Path:
    base = os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}"
    return Path(base) / "shark-sysd" / "token"


def write_token(path: Path, token: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(path.parent, 0o700)
    tmp = path.with_suffix(".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(token + "\n")
    os.replace(tmp, path)


def serve(host: str, port: int, token_file: Path, origins, proc_root: str = "/proc") -> None:
    if host not in LOOPBACK:
        raise SystemExit(f"shark-sysd: odmawiam nasłuchu na {host} — dozwolona jest tylko pętla zwrotna (127.0.0.1, ::1)")
    token = secrets.token_urlsafe(32)
    write_token(token_file, token)
    reader = ProcReader(proc_root)
    app = App(token, reader=reader, origins=origins, port=port)
    if os.environ.get("SHARK_SYSD_AUTOMOUNT", "1") != "0" and shutil.which("udisksctl"):
        app.automount.start()          # pendrive'y montują się same (zdarzenia: GET /v1/zdarzenia)
    ThreadingHTTPServer.allow_reuse_address = True
    if ":" in host:
        import socket
        ThreadingHTTPServer.address_family = socket.AF_INET6
    httpd = ThreadingHTTPServer((host, port), make_handler(app))
    httpd.daemon_threads = True
    print(f"shark-sysd {VERSION}: nasłuch na {host}:{httpd.server_address[1]}, token w {token_file}", flush=True)

    def stop(*_):
        threading.Thread(target=httpd.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        try:
            token_file.unlink()
        except OSError:
            pass


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="shark-sysd", description="Prawdziwe dane systemu dla nakładki SharkOS (tylko 127.0.0.1)")
    sub = ap.add_subparsers(dest="cmd")
    s = sub.add_parser("serve", help="uruchom usługę (domyślnie)")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=DEFAULT_PORT)
    s.add_argument("--token-file", type=Path, default=None)
    s.add_argument("--allow-origin", action="append", default=None,
                   help="dodatkowe dozwolone Origin (domyślnie: null i file://)")
    s.add_argument("--proc", default="/proc", help=argparse.SUPPRESS)
    t = sub.add_parser("token", help="wypisz token bieżącej sesji (dla programu uruchamiającego nakładkę)")
    t.add_argument("--token-file", type=Path, default=None)
    u = sub.add_parser("shell-url", help="wypisz adres nakładki z tokenem w części #")
    u.add_argument("--token-file", type=Path, default=None)
    u.add_argument("--shell", default="/usr/share/sharkos/shell/index.html")
    a = ap.parse_args(argv)
    cmd = a.cmd or "serve"
    tf = getattr(a, "token_file", None) or default_token_file()
    if cmd == "serve":
        origins = list(DEFAULT_ORIGINS) + (getattr(a, "allow_origin", None) or [])
        serve(getattr(a, "host", "127.0.0.1"), getattr(a, "port", DEFAULT_PORT), tf, origins, getattr(a, "proc", "/proc"))
        return 0
    try:
        token = tf.read_text().strip()
    except OSError:
        print(f"shark-sysd: brak pliku tokenu {tf} — czy usługa działa?", file=sys.stderr)
        return 1
    print(token if cmd == "token" else f"file://{Path(a.shell).resolve()}#sysd-token={token}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
